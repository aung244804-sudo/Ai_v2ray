package com.example.data

import com.example.model.VpnNode
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import java.security.MessageDigest

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String? = null,
    val photoUrl: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CloudVpnNode(
    @DocumentId val id: String = "",
    val userId: String = "",
    val nodeKey: String = "",
    val name: String = "",
    val protocol: String = "",
    val address: String = "",
    val port: Long = 443L,
    val rawLink: String = "",
    val security: String = "tls",
    val network: String = "tcp",
    val sni: String = "",
    val region: String = "Global",
    val flag: String = "🌐",
    val latencyMs: Long = -1L,
    val isHealthy: Boolean = true,
    val score: Double = 0.0,
    val failureCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toVpnNode(): VpnNode = VpnNode(
        id = nodeKey.ifBlank { id },
        name = name,
        protocol = protocol,
        address = address,
        port = port.toInt().coerceIn(1, 65535),
        rawLink = rawLink,
        security = security,
        network = network,
        sni = sni,
        region = region,
        flag = flag,
        latencyMs = latencyMs,
        isHealthy = isHealthy,
        score = score,
        failureCount = failureCount.toInt().coerceAtLeast(0)
    )
}

@IgnoreExtraProperties
data class CloudVpnSettings(
    @DocumentId val id: String = "",
    val userId: String = "",
    val dnsProviderName: String = "Cloudflare DoH",
    val dnsIp: String = "1.1.1.1",
    val routingMode: String = "Bypass Myanmar LAN & Direct",
    val mtu: Long = 1280L,
    val ipv6LeakProtection: Boolean = true,
    val autoReconnectSelfHeal: Boolean = true,
    val preferredLanguage: String = "en",
    val activeNodeId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AiSessionRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val mode: String = "routing",
    val query: String = "",
    val summary: String = "",
    val recommendedProtocol: String = "",
    val recommendedDns: String = "",
    val recommendedMtu: Long = 1280L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

fun sanitizeFirestoreDocId(raw: String): String {
    val safe = raw.replace(Regex("[^a-zA-Z0-9_-]"), "_")
    if (safe.isNotBlank() && safe.length <= 96) return safe
    val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
    return digest.joinToString("") { "%02x".format(it) }.take(32)
}
