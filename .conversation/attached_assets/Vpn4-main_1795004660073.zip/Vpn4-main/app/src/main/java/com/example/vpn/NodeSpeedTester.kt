package com.example.vpn

import com.example.model.VpnNode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Parallel TCP socket latency prober for V2Ray/Xray node endpoints.
 */
object NodeSpeedTester {

    suspend fun testNode(node: VpnNode, timeoutMs: Int = 1800): Long = withContext(Dispatchers.IO) {
        var socket: Socket? = null
        val start = System.currentTimeMillis()
        try {
            socket = Socket()
            socket.connect(InetSocketAddress(node.address, node.port), timeoutMs)
            val duration = (System.currentTimeMillis() - start).coerceAtLeast(1L)
            node.latencyMs = duration
            node.isHealthy = true
            duration
        } catch (_: Exception) {
            node.latencyMs = -1L
            node.isHealthy = false
            -1L
        } finally {
            runCatching { socket?.close() }
        }
    }

    suspend fun testAll(nodes: List<VpnNode>, timeoutMs: Int = 1800): List<VpnNode> =
        withContext(Dispatchers.IO) {
            nodes.map { node ->
                async {
                    testNode(node, timeoutMs)
                    node
                }
            }.awaitAll()
        }
}
