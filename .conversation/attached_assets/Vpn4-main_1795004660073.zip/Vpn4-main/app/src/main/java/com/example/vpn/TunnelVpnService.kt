package com.example.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import com.example.R
import com.example.data.ConfigRepository
import com.example.model.Telemetry
import com.example.model.TunnelState
import com.example.model.VpnNode
import com.example.telemetry.AiLogLevel
import com.example.telemetry.LiveLogBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean

class TunnelVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var scope: CoroutineScope? = null
    private var telemetry: TelemetryCollector? = null
    private var xray: LibXrayRuntime? = null
    private lateinit var repository: ConfigRepository
    private val orchestrator = AiTunnelOrchestrator()
    private var activeNode: VpnNode? = null
    private var physicalInterface: String = ""
    private var consecutiveFailures: Int = 0
    private var sessionStartElapsedMs: Long = 0L
    private var usingLibXrayCore: Boolean = false
    private val isSwitching = AtomicBoolean(false)

    override fun onCreate() {
        super.onCreate()
        repository = ConfigRepository(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startTunnel(intent.getStringExtra(EXTRA_NODE_ID))
            ACTION_SWITCH_NODE -> switchActiveNode(intent.getStringExtra(EXTRA_NODE_ID))
            ACTION_STOP -> stopTunnel()
        }
        return START_STICKY
    }

    private fun startTunnel(requestedNodeId: String?) {
        if (scope != null) return
        createChannel()
        startForeground(NOTIFICATION_ID, notification(getString(R.string.vpn_notification_starting)))
        scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope?.launch {
            try {
                val nodes = repository.getNodes().ifEmpty { repository.refreshNodePings() }
                require(nodes.isNotEmpty()) { getString(R.string.error_no_node_selected) }

                val settings = repository.getSettings()
                val targetPlatform = repository.getTargetPlatform()
                val selected = requestedNodeId?.let { id -> nodes.firstOrNull { it.id == id } }
                    ?: repository.getActiveNode()
                    ?: orchestrator.autoSelectBestNode(nodes, targetPlatform)
                    ?: nodes.first()

                activeNode = selected
                repository.setActiveNodeId(selected.id)

                val detectedInterface = underlyingInterfaceName() ?: "wlan0"
                physicalInterface = detectedInterface

                val runtime = LibXrayRuntime(this@TunnelVpnService, this@TunnelVpnService)
                val libXrayPresent = runtime.isAvailable()

                val builder = Builder()
                    .setSession("AI V2Ray Client")
                    .setMtu(settings.mtu)
                    .addAddress("10.8.0.2", 30)

                if (libXrayPresent) {
                    builder
                        .addRoute("0.0.0.0", 0)
                        .addDnsServer(settings.dnsIp)
                    if (settings.ipv6LeakProtection) {
                        runCatching { builder.addAddress("fd00:10:8::2", 126) }
                    }
                } else {
                    // Standby TUN mode (without libXray.aar): isolate virtual subnet so GMS/Firebase AI keeps full connectivity.
                    builder.addRoute("10.8.0.0", 30)
                    runCatching { builder.addDisallowedApplication(packageName) }
                }

                tun = builder.establish() ?: error("VPN interface could not be established")

                if (libXrayPresent) {
                    xray = runtime
                    runtime.registerProtection().getOrThrow()
                    runtime.setDns("${settings.dnsIp}:53").getOrThrow()
                    val outbound = runtime.convertShareLink(selected.rawLink)
                    val xrayJson = XrayConfigFactory.build(
                        outboundJson = outbound,
                        tunFd = tun!!.fd,
                        physicalInterfaceName = physicalInterface,
                        dnsServer = settings.dnsIp,
                        mtu = settings.mtu
                    )
                    runtime.startXray(xrayJson).getOrThrow()
                    usingLibXrayCore = true
                    LiveLogBus.log(
                        "XRAY-CORE",
                        "TUN active via $physicalInterface -> ${selected.name} (${selected.protocol.uppercase()})",
                        AiLogLevel.SUCCESS
                    )
                    sendState(
                        TunnelState.RUNNING,
                        "Xray Core Active: ${selected.name} (${selected.protocol.uppercase()})"
                    )
                    updateNotification("AI Tunnel: ${selected.name} • ${runtime.version().ifBlank { "libXray" }}")
                } else {
                    usingLibXrayCore = false
                    LiveLogBus.log(
                        "XRAY-TUN",
                        "Standby TUN active (10.8.0.2/30) • Node: ${selected.name}",
                        AiLogLevel.INFO
                    )
                    sendState(
                        TunnelState.RUNNING,
                        "TUN Active (Core Standby): ${selected.name} (${selected.protocol.uppercase()})"
                    )
                    updateNotification("TUN Standby: ${selected.name} • Add libXray.aar for full proxy")
                }

                sessionStartElapsedMs = SystemClock.elapsedRealtime()
                consecutiveFailures = 0
                startTelemetryLoop()
            } catch (t: Throwable) {
                val message = t.message ?: "Tunnel startup failed"
                LiveLogBus.log("XRAY-TUN", "Startup error: $message", AiLogLevel.ERROR)
                stopTunnel(publishStopped = false)
                sendState(TunnelState.ERROR, message)
            }
        }
    }

    private fun switchActiveNode(nodeId: String?) {
        val currentScope = scope ?: return
        if (nodeId.isNullOrBlank()) return
        currentScope.launch {
            val node = repository.getNodes().firstOrNull { it.id == nodeId } ?: return@launch
            if (usingLibXrayCore) {
                performNodeSwitch(node, isSelfHeal = false)
            } else {
                activeNode = node
                repository.setActiveNodeId(node.id)
                consecutiveFailures = 0
                sendState(
                    TunnelState.RUNNING,
                    "TUN Active (Core Standby): ${node.name} (${node.protocol.uppercase()})"
                )
                updateNotification("TUN Standby: ${node.name}")
            }
        }
    }

    private fun startTelemetryLoop() {
        val currentScope = scope ?: return
        telemetry = TelemetryCollector(
            uid = applicationInfo.uid,
            probeHostProvider = { activeNode?.let { it.address to it.port } }
        ) { latency, rx, tx, downKbps, upKbps ->
            val sessionSec = ((SystemClock.elapsedRealtime() - sessionStartElapsedMs) / 1000L).coerceAtLeast(0L)
            sendBroadcast(
                Intent(ACTION_TELEMETRY)
                    .setPackage(packageName)
                    .putExtra(EXTRA_LATENCY, latency)
                    .putExtra(EXTRA_RX, rx)
                    .putExtra(EXTRA_TX, tx)
                    .putExtra(EXTRA_DOWN_KBPS, downKbps)
                    .putExtra(EXTRA_UP_KBPS, upKbps)
                    .putExtra(EXTRA_SESSION_SEC, sessionSec)
                    .putExtra(EXTRA_NODE_ID, activeNode?.id.orEmpty())
                    .putExtra(EXTRA_NODE_NAME, activeNode?.name.orEmpty())
                    .putExtra(EXTRA_CORE_ACTIVE, usingLibXrayCore)
            )

            val settings = repository.getSettings()
            val allNodes = repository.getNodes()
            if (settings.autoReconnectSelfHeal && allNodes.size > 1) {
                checkSelfHealCondition(
                    Telemetry(
                        latencyMs = latency,
                        rxBytes = rx,
                        txBytes = tx,
                        downloadKbps = downKbps,
                        uploadKbps = upKbps,
                        sessionSeconds = sessionSec
                    )
                )
            }
        }.also { it.start(currentScope) }
    }

    private fun checkSelfHealCondition(currentTelemetry: Telemetry) {
        val currentScope = scope ?: return
        if (isSwitching.get()) return
        val decision = orchestrator.evaluateLocalNanoFallback(currentTelemetry)
        if (currentTelemetry.latencyMs < 0 || currentTelemetry.latencyMs > 450) {
            consecutiveFailures++
            LiveLogBus.log(
                "AI-NANO",
                "Spike #${consecutiveFailures}: ${decision.reason}",
                AiLogLevel.WARN
            )
        } else {
            consecutiveFailures = 0
        }
        if (consecutiveFailures >= 2 && isSwitching.compareAndSet(false, true)) {
            currentScope.launch {
                try {
                    val allNodes = repository.getNodes()
                    val backupNode = orchestrator.checkAndSelfHeal(
                        activeNode = activeNode,
                        currentTelemetry = currentTelemetry,
                        consecutiveFailures = consecutiveFailures,
                        nodePool = allNodes,
                        targetPlatform = repository.getTargetPlatform()
                    )
                    if (backupNode != null && backupNode.id != activeNode?.id) {
                        LiveLogBus.log(
                            "SELF-HEAL",
                            "Failover triggered -> ${backupNode.name} (${backupNode.latencyMs}ms)",
                            AiLogLevel.AI
                        )
                        performNodeSwitch(backupNode, isSelfHeal = true)
                    }
                } finally {
                    isSwitching.set(false)
                }
            }
        }
    }

    private suspend fun performNodeSwitch(newNode: VpnNode, isSelfHeal: Boolean) = withContext(Dispatchers.IO) {
        val label = if (isSelfHeal) "AI Self-Healing" else "Switching Node"
        sendState(TunnelState.HEALING, "$label: Routing to ${newNode.name}…")
        updateNotification("$label: ${newNode.name}…")

        if (!usingLibXrayCore) {
            activeNode = newNode
            repository.setActiveNodeId(newNode.id)
            consecutiveFailures = 0
            sendState(TunnelState.RUNNING, "AI Self-Healed (Standby): ${newNode.name}")
            updateNotification("TUN Standby: ${newNode.name}")
            return@withContext
        }

        val runtime = xray ?: return@withContext
        val tunFd = tun?.fd ?: return@withContext
        val settings = repository.getSettings()
        runCatching {
            runtime.stopXray()
            val outbound = runtime.convertShareLink(newNode.rawLink)
            runtime.startXray(
                XrayConfigFactory.build(
                    outboundJson = outbound,
                    tunFd = tunFd,
                    physicalInterfaceName = physicalInterface,
                    dnsServer = settings.dnsIp,
                    mtu = settings.mtu
                )
            ).getOrThrow()
            activeNode = newNode
            repository.setActiveNodeId(newNode.id)
            consecutiveFailures = 0
            sendState(TunnelState.RUNNING, "AI Self-Healed: Online via ${newNode.name}")
            updateNotification("AI Tunnel: ${newNode.name}")
        }.onFailure { err ->
            sendState(TunnelState.ERROR, "Node switch failed: ${err.message}")
        }
    }

    private fun stopTunnel(publishStopped: Boolean = true) {
        val old = scope
        scope = null
        isSwitching.set(false)
        telemetry?.stop()
        telemetry = null
        old?.cancel()
        runBlocking(Dispatchers.IO) {
            withTimeoutOrNull(1500L) {
                xray?.stopXray()
            }
        }
        xray?.resetDns()
        xray = null
        usingLibXrayCore = false
        runCatching { tun?.close() }
        tun = null
        if (publishStopped) {
            LiveLogBus.log("XRAY-TUN", "Tunnel stopped cleanly", AiLogLevel.INFO)
            sendState(TunnelState.STOPPED, getString(R.string.vpn_notification_stopped))
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    private fun underlyingInterfaceName(): String? {
        val connectivity = getSystemService(ConnectivityManager::class.java) ?: return null
        val network = connectivity.activeNetwork ?: return null
        val interfaceName = connectivity.getLinkProperties(network)?.interfaceName ?: return null
        return interfaceName.takeUnless {
            it == "tun0" || it.startsWith("tun") || it.startsWith("aiv2ray")
        }
    }

    private fun sendState(state: TunnelState, message: String) {
        val nodeId = activeNode?.id.orEmpty()
        _liveStatus.value = TunnelLiveStatus(
            state = state,
            message = message,
            nodeId = nodeId,
            coreActive = usingLibXrayCore
        )
        sendBroadcast(
            Intent(ACTION_STATE)
                .setPackage(packageName)
                .putExtra(EXTRA_STATE, state.name)
                .putExtra(EXTRA_MESSAGE, message)
                .putExtra(EXTRA_NODE_ID, nodeId)
                .putExtra(EXTRA_NODE_NAME, activeNode?.name.orEmpty())
                .putExtra(EXTRA_CORE_ACTIVE, usingLibXrayCore)
        )
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.vpn_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.vpn_channel_description)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(text: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.app_full_title))
            .setContentText(text)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }

    data class TunnelLiveStatus(
        val state: TunnelState = TunnelState.STOPPED,
        val message: String = "",
        val nodeId: String = "",
        val coreActive: Boolean = false
    )

    companion object {
        private val _liveStatus = MutableStateFlow(TunnelLiveStatus())
        val liveStatus: StateFlow<TunnelLiveStatus> = _liveStatus.asStateFlow()

        const val ACTION_START = "com.example.vpn.START"
        const val ACTION_STOP = "com.example.vpn.STOP"
        const val ACTION_SWITCH_NODE = "com.example.vpn.SWITCH_NODE"
        const val ACTION_STATE = "com.example.vpn.STATE"
        const val ACTION_TELEMETRY = "com.example.vpn.TELEMETRY"

        const val EXTRA_STATE = "state"
        const val EXTRA_MESSAGE = "message"
        const val EXTRA_NODE_ID = "nodeId"
        const val EXTRA_NODE_NAME = "nodeName"
        const val EXTRA_LATENCY = "latency"
        const val EXTRA_RX = "rx"
        const val EXTRA_TX = "tx"
        const val EXTRA_DOWN_KBPS = "downKbps"
        const val EXTRA_UP_KBPS = "upKbps"
        const val EXTRA_SESSION_SEC = "sessionSec"
        const val EXTRA_CORE_ACTIVE = "coreActive"

        private const val CHANNEL_ID = "ai_vpn_tunnel"
        private const val NOTIFICATION_ID = 7001
    }
}
