package com.example.ui.theme

import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val IndustrialColorScheme = lightColorScheme(
    primary = IndustrialColors.CopperFront,
    onPrimary = IndustrialColors.DeepRecess,
    primaryContainer = IndustrialColors.CopperSideBevel,
    onPrimaryContainer = IndustrialColors.CopperHighlightCap,
    secondary = IndustrialColors.CyanTelemetry,
    onSecondary = IndustrialColors.DeepRecess,
    secondaryContainer = IndustrialColors.RecessedTrayBackground,
    onSecondaryContainer = IndustrialColors.CopperHighlightCap,
    tertiary = IndustrialColors.EmeraldSafe,
    onTertiary = IndustrialColors.DeepRecess,
    background = IndustrialColors.BrushedSteelBackground,
    onBackground = IndustrialColors.TextOnAluminum,
    surface = IndustrialColors.BrushedSteelLight,
    onSurface = IndustrialColors.TextOnAluminum,
    surfaceVariant = IndustrialColors.RecessedTrayBackground,
    onSurfaceVariant = IndustrialColors.TextSecondary,
    outline = IndustrialColors.MachinedBorder,
    outlineVariant = IndustrialColors.MachinedHighlight,
    error = IndustrialColors.RubyError,
    onError = IndustrialColors.DeepRecess
)

private val IndustrialShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(9.dp),
    large = RoundedCornerShape(12.dp),
    extraLarge = RoundedCornerShape(16.dp)
)

/**
 * 9dp Chamfered Bevel Shape for Machined-Recess Trays.
 */
val ChamferShape9dp = GenericShape { size, _ ->
    val c = (size.minDimension * 0.04f).coerceIn(8f, 18f)
    moveTo(c, 0f)
    lineTo(size.width - c, 0f)
    lineTo(size.width, c)
    lineTo(size.width, size.height - c)
    lineTo(size.width - c, size.height)
    lineTo(c, size.height)
    lineTo(0f, size.height - c)
    lineTo(0f, c)
    close()
}

@Composable
fun AiV2RayTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = IndustrialColorScheme,
        typography = IndustrialTypography,
        shapes = IndustrialShapes,
        content = content
    )
}
