package com.example

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.ai.VoiceConsoleState
import com.example.ai.configureAppCheck
import com.example.auth.authStateFlow
import com.example.auth.signOutUser
import com.example.data.CloudSyncRepository
import com.example.data.ConfigRepository
import com.example.model.NetworkDiagSnapshot
import com.example.model.Telemetry
import com.example.model.TunnelState
import com.example.model.VpnNode
import com.example.model.VpnSettings
import com.example.telemetry.AiLogEntry
import com.example.ui.MainUiState
import com.example.ui.MainViewModel
import com.example.ui.StringsCatalog
import com.example.ui.components.AiLiveTerminalPanel
import com.example.ui.components.IndustrialFooter
import com.example.ui.components.IndustrialHeader
import com.example.ui.components.IndustrialNavTabs
import com.example.ui.modals.DiagnosticsModal
import com.example.ui.modals.ImportConfigModal
import com.example.ui.modals.QrShareModal
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DeveloperScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TunnelDashboardScreen
import com.example.ui.theme.AiV2RayTheme
import com.example.ui.theme.IndustrialColors
import com.example.vpn.LibXrayRuntime
import com.example.vpn.TunnelVpnService
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class MainActivity : ComponentActivity(), SensorEventListener {

    private var activeViewModel: MainViewModel? = null

    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null

    private var batteryPercent by mutableIntStateOf(-1)
    private var isCharging by mutableStateOf(false)
    private var tiltXDeg by mutableIntStateOf(0)
    private var tiltYDeg by mutableIntStateOf(0)
    private var gyroAvailable by mutableStateOf(false)

    private val tunnelReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                TunnelVpnService.ACTION_TELEMETRY -> {
                    val lat = intent.getLongExtra(TunnelVpnService.EXTRA_LATENCY, -1L)
                    val rx = intent.getLongExtra(TunnelVpnService.EXTRA_RX, 0L)
                    val tx = intent.getLongExtra(TunnelVpnService.EXTRA_TX, 0L)
                    val downKbps = intent.getFloatExtra(TunnelVpnService.EXTRA_DOWN_KBPS, 0f)
                    val upKbps = intent.getFloatExtra(TunnelVpnService.EXTRA_UP_KBPS, 0f)
                    val sec = intent.getLongExtra(TunnelVpnService.EXTRA_SESSION_SEC, 0L)
                    val nodeId = intent.getStringExtra(TunnelVpnService.EXTRA_NODE_ID).orEmpty()
                    val coreActive = intent.getBooleanExtra(TunnelVpnService.EXTRA_CORE_ACTIVE, false)
                    activeViewModel?.setTelemetry(
                        Telemetry(
                            latencyMs = lat,
                            rxBytes = rx,
                            txBytes = tx,
                            downloadKbps = downKbps,
                            uploadKbps = upKbps,
                            sessionSeconds = sec
                        ),
                        activeNodeId = nodeId,
                        coreActive = coreActive
                    )
                }

                TunnelVpnService.ACTION_STATE -> {
                    val state = runCatching {
                        TunnelState.valueOf(
                            intent.getStringExtra(TunnelVpnService.EXTRA_STATE) ?: TunnelState.STOPPED.name
                        )
                    }.getOrDefault(TunnelState.ERROR)
                    val msg = intent.getStringExtra(TunnelVpnService.EXTRA_MESSAGE).orEmpty()
                    val nodeId = intent.getStringExtra(TunnelVpnService.EXTRA_NODE_ID).orEmpty()
                    val coreActive = intent.getBooleanExtra(TunnelVpnService.EXTRA_CORE_ACTIVE, false)
                    activeViewModel?.setTunnelState(state, msg, nodeId, coreActive)
                }

                Intent.ACTION_BATTERY_CHANGED -> {
                    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    if (level >= 0 && scale > 0) {
                        batteryPercent = ((level * 100f) / scale).roundToInt().coerceIn(0, 100)
                    }
                    isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL
                }
            }
        }
    }

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val vm = activeViewModel ?: return@registerForActivityResult
        if (result.resultCode == RESULT_OK) {
            startTunnelService(vm, vm.uiState.value.activeNode?.id)
        } else {
            vm.setTunnelState(
                TunnelState.ERROR,
                getString(R.string.error_vpn_permission_denied)
            )
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure Firebase App Check BEFORE UI, ViewModels, or AI calls
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        sensorManager = getSystemService(SENSOR_SERVICE) as? SensorManager
        accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        gyroAvailable = accelerometer != null

        val filter = IntentFilter().apply {
            addAction(TunnelVpnService.ACTION_STATE)
            addAction(TunnelVpnService.ACTION_TELEMETRY)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(tunnelReceiver, filter, RECEIVER_NOT_EXPORTED)
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(tunnelReceiver, filter)
        }

        setContent {
            AiV2RayTheme {
                val auth = remember { Firebase.auth }
                val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)

                val user = currentUser
                if (user == null) {
                    activeViewModel = null
                    AuthScreen(onAuthSuccess = { })
                } else {
                    // Key by uid so signing out or switching accounts creates a clean ViewModel + listeners
                    key(user.uid) {
                        MainAuthenticatedFeature(
                            user = user,
                            batteryPercent = batteryPercent,
                            isCharging = isCharging,
                            tiltXDeg = tiltXDeg,
                            tiltYDeg = tiltYDeg,
                            gyroAvailable = gyroAvailable,
                            onBindViewModel = { vm -> activeViewModel = vm },
                            onUnbindViewModel = { vm -> if (activeViewModel === vm) activeViewModel = null },
                            onToggleTunnel = { vm, onNoNodes -> handleToggleTunnel(vm, onNoNodes) },
                            onSwitchActiveNode = { vm, node -> handleSwitchActiveNode(vm, node) }
                        )
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val live = TunnelVpnService.liveStatus.value
        val vm = activeViewModel ?: return
        if (live.state != TunnelState.STOPPED || vm.uiState.value.tunnelState != TunnelState.STOPPED) {
            vm.setTunnelState(live.state, live.message, live.nodeId, live.coreActive)
        }
    }

    override fun onResume() {
        super.onResume()
        accelerometer?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        sensorManager?.unregisterListener(this)
        super.onPause()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {
            tiltXDeg = (event.values[0] * 3.0f).roundToInt().coerceIn(-45, 45)
            tiltYDeg = (event.values[1] * 3.0f).roundToInt().coerceIn(-45, 45)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun handleToggleTunnel(vm: MainViewModel, onNoNodes: () -> Unit) {
        val current = vm.uiState.value
        val isRunning = current.tunnelState == TunnelState.RUNNING ||
            current.tunnelState == TunnelState.HEALING ||
            current.tunnelState == TunnelState.STARTING
        if (isRunning) {
            stopTunnelService()
            return
        }
        val active = current.activeNode ?: vm.autoPickBestNode()
        if (active == null) {
            vm.setTunnelState(TunnelState.ERROR, getString(R.string.error_no_node_selected))
            onNoNodes()
            return
        }
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            startTunnelService(vm, active.id)
        }
    }

    private fun handleSwitchActiveNode(vm: MainViewModel, node: VpnNode) {
        vm.selectNode(node.id)
        val current = vm.uiState.value
        if (current.tunnelState == TunnelState.RUNNING || current.tunnelState == TunnelState.HEALING) {
            val intent = Intent(this, TunnelVpnService::class.java)
                .setAction(TunnelVpnService.ACTION_SWITCH_NODE)
                .putExtra(TunnelVpnService.EXTRA_NODE_ID, node.id)
            startService(intent)
        }
    }

    private fun startTunnelService(vm: MainViewModel, nodeId: String?) {
        vm.setTunnelState(TunnelState.STARTING, "AI Precision Engine: Optimizing routes…")
        val intent = Intent(this, TunnelVpnService::class.java)
            .setAction(TunnelVpnService.ACTION_START)
            .putExtra(TunnelVpnService.EXTRA_NODE_ID, nodeId)
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopTunnelService() {
        startService(Intent(this, TunnelVpnService::class.java).setAction(TunnelVpnService.ACTION_STOP))
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(tunnelReceiver) }
        super.onDestroy()
    }
}

@Composable
private fun MainAuthenticatedFeature(
    user: FirebaseUser,
    batteryPercent: Int,
    isCharging: Boolean,
    tiltXDeg: Int,
    tiltYDeg: Int,
    gyroAvailable: Boolean,
    onBindViewModel: (MainViewModel) -> Unit,
    onUnbindViewModel: (MainViewModel) -> Unit,
    onToggleTunnel: (MainViewModel, () -> Unit) -> Unit,
    onSwitchActiveNode: (MainViewModel, VpnNode) -> Unit
) {
    val context = LocalContext.current
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val signOutScope = rememberCoroutineScope()

    val viewModel: MainViewModel = viewModel(
        key = user.uid,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                val cloudRepo = CloudSyncRepository(db = db)
                val configRepo = ConfigRepository(app)
                MainViewModel(
                    repository = configRepo,
                    cloudSyncRepository = cloudRepo,
                    currentUserId = user.uid,
                    operatorDisplayName = user.displayName.orEmpty(),
                    operatorEmail = user.email,
                    operatorPhotoUrl = user.photoUrl?.toString(),
                    diagSnapshotProvider = { settings -> collectNetworkDiagnostics(app, settings) }
                )
            }
        }
    )

    DisposableEffect(viewModel) {
        onBindViewModel(viewModel)
        onDispose { onUnbindViewModel(viewModel) }
    }

    LaunchedEffect(viewModel) {
        val live = TunnelVpnService.liveStatus.value
        if (live.state != TunnelState.STOPPED) {
            viewModel.setTunnelState(live.state, live.message, live.nodeId, live.coreActive)
        }
    }

    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val liveLogs by viewModel.liveLogs.collectAsStateWithLifecycle()

    AiV2RayRootScreen(
        state = state,
        voiceState = voiceState,
        liveLogs = liveLogs,
        batteryPercent = batteryPercent,
        isCharging = isCharging,
        tiltXDeg = tiltXDeg,
        tiltYDeg = tiltYDeg,
        gyroAvailable = gyroAvailable,
        viewModel = viewModel,
        onToggleTunnel = { onNoNodes -> onToggleTunnel(viewModel, onNoNodes) },
        onSwitchActiveNode = { node -> onSwitchActiveNode(viewModel, node) },
        onSignOut = {
            viewModel.stopVoiceConversation()
            signOutUser(credentialManager, signOutScope)
        }
    )
}

private suspend fun collectNetworkDiagnostics(
    appCtx: Context,
    settings: VpnSettings
): NetworkDiagSnapshot = withContext(Dispatchers.IO) {
    val cm = appCtx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    val activeNetwork = cm?.activeNetwork
    val caps = activeNetwork?.let { cm.getNetworkCapabilities(it) }
    val lp = activeNetwork?.let { cm.getLinkProperties(it) }
    val netType = when {
        caps == null -> "Disconnected"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular (4G/5G)"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN Tunnel Active"
        else -> "Active Network"
    }
    val runtime = LibXrayRuntime(appCtx, null)
    val bundled = runtime.isAvailable()
    val version = if (bundled) runtime.version().ifBlank { "Detected" } else "Standby (AAR not bundled)"
    NetworkDiagSnapshot(
        networkType = netType,
        interfaceName = lp?.interfaceName ?: "unavailable",
        activeDns = settings.dnsIp,
        libXrayBundled = bundled,
        xrayVersion = version,
        mtu = settings.mtu,
        ipv6Guard = settings.ipv6LeakProtection
    )
}

@Composable
private fun AiV2RayRootScreen(
    state: MainUiState,
    voiceState: VoiceConsoleState,
    liveLogs: List<AiLogEntry>,
    batteryPercent: Int,
    isCharging: Boolean,
    tiltXDeg: Int,
    tiltYDeg: Int,
    gyroAvailable: Boolean,
    viewModel: MainViewModel,
    onToggleTunnel: (() -> Unit) -> Unit,
    onSwitchActiveNode: (VpnNode) -> Unit,
    onSignOut: () -> Unit
) {
    val strings = StringsCatalog.get(state.language)
    val clipboard = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val uiScope = rememberCoroutineScope()

    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var showImportModal by remember { mutableStateOf(false) }
    var showDiagModal by remember { mutableStateOf(false) }
    var qrNode by remember { mutableStateOf<VpnNode?>(null) }

    Scaffold(
        containerColor = IndustrialColors.BrushedSteelBackground,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            IndustrialColors.BrushedSteelMid,
                            IndustrialColors.BrushedSteelLight,
                            IndustrialColors.BrushedSteelBackground,
                            IndustrialColors.BrushedSteelMid
                        )
                    )
                )
                .drawBehind {
                    val grooveSpacing = 3.dp.toPx()
                    var x = 0f
                    var idx = 0
                    while (x < size.width) {
                        val tint = if (idx % 2 == 0) {
                            Color.White.copy(alpha = 0.08f)
                        } else {
                            Color.Black.copy(alpha = 0.035f)
                        }
                        drawLine(
                            color = tint,
                            start = Offset(x, 0f),
                            end = Offset(x, size.height),
                            strokeWidth = 1.2f
                        )
                        x += grooveSpacing
                        idx++
                    }
                }
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            val isWide = maxWidth >= 680.dp
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = if (isWide) 760.dp else 600.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IndustrialHeader(
                    tunnelState = state.tunnelState,
                    xrayCoreLabel = state.diagSnapshot.xrayVersion,
                    batteryPercent = batteryPercent,
                    isCharging = isCharging,
                    tiltXDeg = tiltXDeg,
                    tiltYDeg = tiltYDeg,
                    gyroAvailable = gyroAvailable,
                    language = state.language,
                    strings = strings,
                    onOpenDiag = {
                        viewModel.refreshDiagnosticsSnapshot()
                        showDiagModal = true
                    }
                )

                IndustrialNavTabs(
                    selectedTab = selectedTab,
                    language = state.language,
                    strings = strings,
                    onSelectTab = { selectedTab = it }
                )

                when (selectedTab) {
                    0 -> TunnelDashboardScreen(
                        state = state,
                        voiceState = voiceState,
                        strings = strings,
                        onSelectTarget = { viewModel.selectTargetPlatform(it) },
                        onAskGemini = { query -> viewModel.askGeminiRouter(query) },
                        onApplyAiAdvice = { advice ->
                            viewModel.applyAiAdvice(advice)
                            uiScope.launch {
                                snackbarHostState.showSnackbar("AI tuning applied & synced")
                            }
                        },
                        onToggleTunnel = {
                            onToggleTunnel {
                                viewModel.clearImportFeedback()
                                showImportModal = true
                            }
                        },
                        onOpenImport = {
                            viewModel.clearImportFeedback()
                            showImportModal = true
                        },
                        onPingAll = { viewModel.refreshPings() },
                        onAiPickBest = {
                            val best = viewModel.autoPickBestNode()
                            if (best != null) {
                                uiScope.launch {
                                    snackbarHostState.showSnackbar("AI Pick: ${best.name}")
                                }
                            } else {
                                showImportModal = true
                            }
                        },
                        onSelectProtocolFilter = { viewModel.setProtocolFilter(it) },
                        onToggleUnder100Ms = { viewModel.toggleUnder100MsOnly() },
                        onSelectNode = onSwitchActiveNode,
                        onCopyNodeLink = { node ->
                            clipboard.setText(AnnotatedString(node.rawLink))
                            uiScope.launch { snackbarHostState.showSnackbar(strings.copiedToast) }
                        },
                        onShowNodeQr = { qrNode = it },
                        onRemoveNode = { viewModel.removeNode(it.id) },
                        onStartVoice = { viewModel.startVoiceConversation() },
                        onStopVoice = { viewModel.stopVoiceConversation() },
                        onDismissVoiceError = { viewModel.clearVoiceError() }
                    )

                    1 -> SettingsScreen(
                        settings = state.settings,
                        language = state.language,
                        strings = strings,
                        onSaveSettings = { updated ->
                            viewModel.updateSettings(updated)
                            uiScope.launch { snackbarHostState.showSnackbar(strings.settingsSavedMsg) }
                        },
                        onBackToTunnel = { selectedTab = 0 }
                    )

                    else -> DeveloperScreen(
                        diagSnapshot = state.diagSnapshot,
                        operatorName = state.operatorName,
                        operatorEmail = state.operatorEmail,
                        cloudSynced = state.cloudSynced,
                        aiSessions = state.aiSessions,
                        language = state.language,
                        strings = strings,
                        onSignOut = onSignOut,
                        onBackToTunnel = { selectedTab = 0 }
                    )
                }

                AiLiveTerminalPanel(
                    logs = liveLogs,
                    isTunnelOnline = state.tunnelState == TunnelState.RUNNING || state.tunnelState == TunnelState.HEALING,
                    language = state.language,
                    strings = strings,
                    onClearLogs = { viewModel.clearLiveLogs() }
                )

                IndustrialFooter(
                    language = state.language,
                    onToggleLang = { viewModel.toggleLanguage() }
                )
            }
        }
    }

    if (showImportModal) {
        ImportConfigModal(
            language = state.language,
            strings = strings,
            isImporting = state.isImporting,
            feedback = state.importFeedback,
            onImportDirect = { raw ->
                viewModel.importNodes(raw) {
                    showImportModal = false
                }
            },
            onAiExtract = { raw ->
                viewModel.extractAndImportWithAi(raw) {
                    showImportModal = false
                }
            },
            onDismiss = { showImportModal = false }
        )
    }

    if (showDiagModal) {
        DiagnosticsModal(
            snapshot = state.diagSnapshot,
            diagAiState = state.diagAiState,
            language = state.language,
            strings = strings,
            onRunAiDiag = { viewModel.runAiNetworkDiagnostics() },
            onApplyAiTuning = { advice ->
                viewModel.applyAiAdvice(advice)
                showDiagModal = false
                uiScope.launch { snackbarHostState.showSnackbar("Applied AI DNS & MTU tuning") }
            },
            onDismiss = { showDiagModal = false }
        )
    }

    qrNode?.let { node ->
        QrShareModal(
            node = node,
            language = state.language,
            strings = strings,
            onCopyLink = {
                clipboard.setText(AnnotatedString(node.rawLink))
                uiScope.launch { snackbarHostState.showSnackbar(strings.copiedToast) }
            },
            onDismiss = { qrNode = null }
        )
    }
}
