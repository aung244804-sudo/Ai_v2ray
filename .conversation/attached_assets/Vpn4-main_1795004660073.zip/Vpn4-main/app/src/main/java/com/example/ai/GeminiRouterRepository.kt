package com.example.ai

import android.util.Log
import com.example.model.AiRoutingAdvice
import com.example.model.AppLanguage
import com.example.model.NetworkDiagSnapshot
import com.example.model.TargetPlatform
import com.example.model.VpnNode
import com.example.model.VpnSettings
import com.example.telemetry.AiLogLevel
import com.example.telemetry.LiveLogBus
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "GeminiRouterRepo"

/**
 * Firebase AI Logic integration for V2Ray smart routing, config extraction,
 * and network diagnostics tuning using gemini-3.8-flash.
 */
class GeminiRouterRepository {

    private val routingSchema = Schema.obj(
        properties = mapOf(
            "summary" to Schema.string(description = "Concise tactical recommendation in requested language"),
            "recommendedProtocol" to Schema.string(description = "Best protocol e.g. VLESS Reality, Hysteria2, Trojan"),
            "recommendedDns" to Schema.string(description = "Optimal DNS IP such as 1.1.1.1 or 94.140.14.14"),
            "recommendedMtu" to Schema.integer(description = "Recommended MTU integer between 1200 and 1500"),
            "routingTip" to Schema.string(description = "Specific split-routing or anti-throttling advice"),
            "targetNodeId" to Schema.string(description = "Matching node ID from the pool, or 'none' if none"),
            "confidence" to Schema.integer(description = "Confidence score 0-100")
        )
    )

    private val routingModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                temperature = 0.2f
                maxOutputTokens = 512
                responseMimeType = "application/json"
                responseSchema = routingSchema
            }
        )
    }

    private val extractionSchema = Schema.obj(
        properties = mapOf(
            "links" to Schema.array(
                items = Schema.string(),
                description = "Extracted raw vless://, vmess://, trojan://, ss://, or hysteria2:// URIs"
            )
        )
    )

    private val extractionModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                temperature = 0.1f
                maxOutputTokens = 1024
                responseMimeType = "application/json"
                responseSchema = extractionSchema
            }
        )
    }

    suspend fun recommendRoutingForTarget(
        targetPlatform: TargetPlatform,
        customQuery: String,
        nodes: List<VpnNode>,
        settings: VpnSettings,
        language: AppLanguage
    ): Result<AiRoutingAdvice> {
        val langInstruction = if (language == AppLanguage.MM) {
            "Write summary and routingTip in clear, natural Burmese (Myanmar) language."
        } else {
            "Write summary and routingTip in concise technical English."
        }
        val poolSummary = if (nodes.isEmpty()) {
            "No nodes imported yet."
        } else {
            nodes.take(10).joinToString("\n") { n ->
                "id=${n.id} | name=${n.name} | proto=${n.protocol} | region=${n.region} | pingMs=${n.latencyMs}"
            }
        }
        val prompt = """
            You are the AI Tunnel Orchestrator for AI V2Ray Client.
            Target: ${targetPlatform.labelEn} (${targetPlatform.cdnHint}).
            Request: ${customQuery.ifBlank { "Optimize latency <100ms and stability" }}.
            Settings: DNS=${settings.dnsIp}, MTU=${settings.mtu}, Routing=${settings.routingMode}.
            Nodes:
            $poolSummary

            Pick the best targetNodeId from Nodes (prefer pingMs 1..100ms, VLESS/Hysteria2, lowest ping), or "none" if empty.
            $langInstruction
        """.trimIndent()

        return try {
            LiveLogBus.log(
                "AI-LEADER",
                "Dispatching ${targetPlatform.labelEn} query to gemini-3.8-flash (pool=${nodes.size})…",
                AiLogLevel.AI
            )
            val response = withTimeout(60_000L) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    routingModel.generateContent(prompt)
                }
            }
            val raw = response.text ?: error("Gemini returned an empty response.")
            val json = JSONObject(raw)
            val suggestedId = json.optString("targetNodeId", "")
                .takeIf { it.isNotBlank() && it != "null" && it != "none" }
            val advice = AiRoutingAdvice(
                summary = json.getString("summary"),
                recommendedProtocol = json.getString("recommendedProtocol"),
                recommendedDns = json.getString("recommendedDns"),
                recommendedMtu = json.optInt("recommendedMtu", settings.mtu).coerceIn(1200, 1500),
                routingTip = json.getString("routingTip"),
                targetNodeId = suggestedId,
                confidence = json.optInt("confidence", 92).coerceIn(0, 100)
            )
            LiveLogBus.log(
                "GEMINI-AI",
                "Plan: ${advice.recommendedProtocol} | DNS ${advice.recommendedDns} | MTU ${advice.recommendedMtu} (${advice.confidence}%)",
                AiLogLevel.SUCCESS
            )
            Result.success(advice)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI routing recommendation timed out", e)
            LiveLogBus.log("GEMINI-AI", "Routing request timed out (60s)", AiLogLevel.ERROR)
            Result.failure(IllegalStateException("Gemini AI timed out after 60s. Please check network connectivity and retry."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI routing recommendation failed", e)
            LiveLogBus.log("GEMINI-AI", "Routing error: ${e.message}", AiLogLevel.ERROR)
            Result.failure(e)
        }
    }

    suspend fun extractV2RayLinksFromText(rawText: String): Result<List<String>> {
        val prompt = """
            Extract all valid V2Ray / Xray share URI links (starting with vless://, vmess://, trojan://, ss://, hysteria2://, or hy2://) from the text below.
            Do not invent or fabricate links that are not present in the input.

            Input text:
            $rawText
        """.trimIndent()

        return try {
            LiveLogBus.log("GEMINI-AI", "Scanning raw text (${rawText.length} chars) for V2Ray URIs…", AiLogLevel.AI)
            val response = withTimeout(60_000L) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    extractionModel.generateContent(prompt)
                }
            }
            val raw = response.text ?: error("Gemini returned an empty response.")
            val json = JSONObject(raw)
            val arr = json.getJSONArray("links")
            val links = (0 until arr.length())
                .map { arr.getString(it).trim() }
                .filter { it.contains("://") }
            LiveLogBus.log("GEMINI-AI", "Extracted ${links.size} valid V2Ray link(s)", AiLogLevel.SUCCESS)
            Result.success(links)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI link extraction timed out", e)
            LiveLogBus.log("GEMINI-AI", "Link extraction timed out (60s)", AiLogLevel.ERROR)
            Result.failure(IllegalStateException("AI link extraction timed out after 60s."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI link extraction failed", e)
            LiveLogBus.log("GEMINI-AI", "Extraction error: ${e.message}", AiLogLevel.ERROR)
            Result.failure(e)
        }
    }

    suspend fun analyzeNetworkDiagnostics(
        snapshot: NetworkDiagSnapshot,
        language: AppLanguage
    ): Result<AiRoutingAdvice> {
        val langInstruction = if (language == AppLanguage.MM) {
            "Write summary and routingTip in clear, natural Burmese (Myanmar) language."
        } else {
            "Write summary and routingTip in concise technical English."
        }
        val prompt = """
            Analyze this Android device network diagnostics snapshot for an Xray/V2Ray VPN client:
            - Network Type: ${snapshot.networkType}
            - Physical Interface: ${snapshot.interfaceName}
            - Active DNS: ${snapshot.activeDns}
            - MTU: ${snapshot.mtu}
            - IPv6 Leak Guard: ${snapshot.ipv6Guard}
            - libXray Native Core Bundled: ${snapshot.libXrayBundled} (${snapshot.xrayVersion})

            Provide tailored DNS, MTU, and split-routing recommendations to minimize packet loss and prevent routing loops.
            Set targetNodeId to "none".
            $langInstruction
        """.trimIndent()

        return try {
            LiveLogBus.log(
                "AI-DIAG",
                "Analyzing ${snapshot.networkType} (${snapshot.interfaceName}) DNS=${snapshot.activeDns} MTU=${snapshot.mtu}…",
                AiLogLevel.AI
            )
            val response = withTimeout(60_000L) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    routingModel.generateContent(prompt)
                }
            }
            val raw = response.text ?: error("Gemini returned an empty response.")
            val json = JSONObject(raw)
            val advice = AiRoutingAdvice(
                summary = json.getString("summary"),
                recommendedProtocol = json.getString("recommendedProtocol"),
                recommendedDns = json.getString("recommendedDns"),
                recommendedMtu = json.optInt("recommendedMtu", snapshot.mtu).coerceIn(1200, 1500),
                routingTip = json.getString("routingTip"),
                targetNodeId = null,
                confidence = json.optInt("confidence", 94).coerceIn(0, 100)
            )
            LiveLogBus.log(
                "AI-DIAG",
                "Calibration ready: DNS ${advice.recommendedDns} • MTU ${advice.recommendedMtu}",
                AiLogLevel.SUCCESS
            )
            Result.success(advice)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI diagnostics analysis timed out", e)
            LiveLogBus.log("AI-DIAG", "Diagnostics timed out (60s)", AiLogLevel.ERROR)
            Result.failure(IllegalStateException("AI diagnostics analysis timed out after 60s."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI diagnostics analysis failed", e)
            LiveLogBus.log("AI-DIAG", "Diagnostics error: ${e.message}", AiLogLevel.ERROR)
            Result.failure(e)
        }
    }
}
