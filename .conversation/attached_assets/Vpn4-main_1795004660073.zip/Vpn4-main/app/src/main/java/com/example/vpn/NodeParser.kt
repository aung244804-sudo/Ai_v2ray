package com.example.vpn

import android.net.Uri
import android.util.Base64
import com.example.model.VpnNode
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder
import java.util.UUID

/**
 * Parses single V2Ray/Xray share links (vless, vmess, trojan, ss, hysteria2/hy2)
 * as well as Base64-encoded subscription payloads.
 */
object NodeParser {

    fun parseNodes(rawInput: String): List<VpnNode> {
        val trimmed = rawInput.trim()
        if (trimmed.isBlank()) return emptyList()

        val decodedContent = if (!trimmed.contains("://")) {
            decodeBase64Safe(trimmed)
        } else {
            trimmed
        }

        val lines = decodedContent.lineSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .toList()

        val nodes = mutableListOf<VpnNode>()
        for (line in lines) {
            val node = parseSingleLink(line)
            if (node != null) {
                nodes.add(node)
            } else if (!line.contains("://")) {
                val subDecoded = decodeBase64Safe(line)
                subDecoded.lineSequence()
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
                    .forEach { subLine ->
                        parseSingleLink(subLine)?.let { nodes.add(it) }
                    }
            }
        }
        return nodes.distinctBy { it.id }
    }

    fun parseSingleLink(link: String): VpnNode? {
        val trimmed = link.trim()
        if (!trimmed.contains("://")) return null
        return runCatching {
            val scheme = trimmed.substringBefore("://").lowercase()
            when (scheme) {
                "vless", "trojan", "hysteria2", "hy2" -> parseStandardUri(trimmed, scheme)
                "vmess" -> parseVmess(trimmed)
                "ss" -> parseShadowsocks(trimmed)
                else -> null
            }
        }.getOrNull()
    }

    private fun parseStandardUri(link: String, scheme: String): VpnNode? {
        val beforeHash = link.substringBefore("#")
        val rawFragment = if (link.contains("#")) link.substringAfter("#") else null
        val sanitizedUriStr = beforeHash.replace(" ", "%20")
        val uri = URI(sanitizedUriStr)
        val host = uri.host?.removeSurrounding("[", "]") ?: return null
        val port = if (uri.port > 0) uri.port else 443
        val rawName = rawFragment?.let {
            runCatching { URLDecoder.decode(it, "UTF-8") }.getOrDefault(it)
        }?.takeIf { it.isNotBlank() } ?: "${scheme.uppercase()}-$host"

        val queryParams = parseQueryParams(uri.rawQuery)
        val security = queryParams["security"] ?: if (scheme == "hysteria2" || scheme == "hy2") "tls" else "none"
        val network = queryParams["type"] ?: if (scheme == "hysteria2" || scheme == "hy2") "udp" else "tcp"
        val sni = queryParams["sni"] ?: queryParams["peer"] ?: ""
        val (region, flag) = detectRegion(rawName)

        return VpnNode(
            id = UUID.nameUUIDFromBytes(link.toByteArray()).toString(),
            name = rawName,
            protocol = if (scheme == "hy2") "hysteria2" else scheme,
            address = host,
            port = port,
            rawLink = link,
            security = security,
            network = network,
            sni = sni,
            region = region,
            flag = flag
        )
    }

    private fun parseVmess(link: String): VpnNode? {
        val b64 = link.removePrefix("vmess://").trim()
        val jsonStr = decodeBase64Safe(b64)
        if (!jsonStr.startsWith("{")) return null
        val json = JSONObject(jsonStr)
        val add = json.optString("add")
        val port = json.optInt("port", 443)
        val ps = json.optString("ps", "VMess-$add").ifBlank { "VMess-$add" }
        if (add.isBlank() || port !in 1..65535) return null

        val security = json.optString("tls", "none").ifBlank { "none" }
        val network = json.optString("net", "tcp").ifBlank { "tcp" }
        val sni = json.optString("sni", json.optString("host", ""))
        val (region, flag) = detectRegion(ps)

        return VpnNode(
            id = UUID.nameUUIDFromBytes(link.toByteArray()).toString(),
            name = ps,
            protocol = "vmess",
            address = add,
            port = port,
            rawLink = link,
            security = security,
            network = network,
            sni = sni,
            region = region,
            flag = flag
        )
    }

    private fun parseShadowsocks(link: String): VpnNode? {
        val afterScheme = link.substringAfter("://")
        val rawFragment = if (afterScheme.contains("#")) afterScheme.substringAfter("#") else null
        val mainAndQuery = afterScheme.substringBefore("#")
        val mainPart = mainAndQuery.substringBefore("?").trim()
        if (mainPart.isBlank()) return null

        val hostPort = if (mainPart.contains("@")) {
            mainPart.substringAfterLast("@")
        } else {
            val decoded = decodeBase64Safe(mainPart)
            if (!decoded.contains("@")) return null
            decoded.substringAfterLast("@")
        }

        val (host, port) = parseHostPort(hostPort, defaultPort = 8388) ?: return null
        val rawName = rawFragment?.let {
            runCatching { URLDecoder.decode(it, "UTF-8") }.getOrDefault(it)
        }?.takeIf { it.isNotBlank() } ?: "SS-$host"
        val (region, flag) = detectRegion(rawName)

        return VpnNode(
            id = UUID.nameUUIDFromBytes(link.toByteArray()).toString(),
            name = rawName,
            protocol = "shadowsocks",
            address = host,
            port = port,
            rawLink = link,
            security = "aead",
            network = "tcp",
            region = region,
            flag = flag
        )
    }

    private fun parseHostPort(hostPort: String, defaultPort: Int): Pair<String, Int>? {
        val trimmed = hostPort.trim().trimEnd('/')
        if (trimmed.isBlank()) return null
        return if (trimmed.startsWith("[")) {
            val closing = trimmed.indexOf(']')
            if (closing <= 1) return null
            val host = trimmed.substring(1, closing)
            val portPart = trimmed.substring(closing + 1).removePrefix(":")
            val port = portPart.toIntOrNull()?.takeIf { it in 1..65535 } ?: defaultPort
            host to port
        } else {
            val colonIdx = trimmed.lastIndexOf(':')
            if (colonIdx > 0) {
                val host = trimmed.substring(0, colonIdx).trim()
                val port = trimmed.substring(colonIdx + 1).toIntOrNull()?.takeIf { it in 1..65535 }
                    ?: return null
                if (host.isBlank()) return null
                host to port
            } else {
                trimmed to defaultPort
            }
        }
    }

    private fun parseQueryParams(rawQuery: String?): Map<String, String> {
        if (rawQuery.isNullOrBlank()) return emptyMap()
        return rawQuery.split("&")
            .mapNotNull { pair ->
                val idx = pair.indexOf('=')
                if (idx <= 0) null
                else {
                    val key = pair.substring(0, idx).lowercase()
                    val value = runCatching {
                        URLDecoder.decode(pair.substring(idx + 1), "UTF-8")
                    }.getOrDefault(pair.substring(idx + 1))
                    key to value
                }
            }
            .toMap()
    }

    private fun detectRegion(name: String): Pair<String, String> {
        val upper = name.uppercase()
        return when {
            upper.contains("SG") || upper.contains("SINGAPORE") || upper.contains("🇸🇬") -> "Singapore" to "🇸🇬"
            upper.contains("JP") || upper.contains("JAPAN") || upper.contains("TOKYO") || upper.contains("🇯🇵") -> "Japan" to "🇯🇵"
            upper.contains("HK") || upper.contains("HONG KONG") || upper.contains("🇭🇰") -> "Hong Kong" to "🇭🇰"
            upper.contains("TH") || upper.contains("THAILAND") || upper.contains("BANGKOK") || upper.contains("🇹🇭") -> "Thailand" to "🇹🇭"
            upper.contains("US") || upper.contains("AMERICA") || upper.contains("🇺🇸") -> "United States" to "🇺🇸"
            upper.contains("DE") || upper.contains("GERMANY") || upper.contains("FRANKFURT") || upper.contains("🇩🇪") -> "Germany" to "🇩🇪"
            upper.contains("UK") || upper.contains("LONDON") || upper.contains("🇬🇧") -> "United Kingdom" to "🇬🇧"
            upper.contains("KR") || upper.contains("KOREA") || upper.contains("🇰🇷") -> "South Korea" to "🇰🇷"
            upper.contains("TW") || upper.contains("TAIWAN") || upper.contains("🇹🇼") -> "Taiwan" to "🇹🇼"
            else -> "Global" to "🌐"
        }
    }

    private fun decodeBase64Safe(input: String): String {
        val clean = input.replace("\r", "").replace("\n", "").trim()
        val fromAndroid = runCatching {
            val bytes = Base64.decode(clean, Base64.DEFAULT or Base64.URL_SAFE or Base64.NO_PADDING)
            String(bytes, Charsets.UTF_8)
        }.getOrNull()
        if (fromAndroid != null && fromAndroid.any { it.isLetterOrDigit() }) return fromAndroid

        val fromJava = runCatching {
            val padded = when (clean.length % 4) {
                2 -> "$clean=="
                3 -> "$clean="
                else -> clean
            }.replace('-', '+').replace('_', '/')
            String(java.util.Base64.getDecoder().decode(padded), Charsets.UTF_8)
        }.getOrNull()
        return fromJava ?: input
    }
}
