package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.AiSessionRecord
import com.example.model.AppLanguage
import com.example.model.NetworkDiagSnapshot
import com.example.model.VpnSettings
import com.example.ui.UiStrings
import com.example.ui.components.BrushedSteelKeyCap
import com.example.ui.components.MachinedAluminumPlate
import com.example.ui.theme.IndustrialColors
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.MyanmarFontFamily
import com.example.ui.theme.RobotoMonoFontFamily

@Composable
fun SettingsScreen(
    settings: VpnSettings,
    language: AppLanguage,
    strings: UiStrings,
    onSaveSettings: (VpnSettings) -> Unit,
    onBackToTunnel: () -> Unit
) {
    BackHandler(onBack = onBackToTunnel)

    val activeFont = if (language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily
    var dnsName by remember(settings) { mutableStateOf(settings.dnsProviderName) }
    var dnsIp by remember(settings) { mutableStateOf(settings.dnsIp) }
    var routingMode by remember(settings) { mutableStateOf(settings.routingMode) }
    var mtu by remember(settings) { mutableIntStateOf(settings.mtu) }
    var ipv6Guard by remember(settings) { mutableStateOf(settings.ipv6LeakProtection) }
    var selfHeal by remember(settings) { mutableStateOf(settings.autoReconnectSelfHeal) }

    val dnsChoices = listOf(
        "Cloudflare DoH" to "1.1.1.1",
        "Google DNS" to "8.8.8.8",
        "AdGuard Anti-Filter" to "94.140.14.14",
        "NextDNS Secure" to "45.90.28.0"
    )
    val routingChoices = listOf(
        "Bypass Myanmar LAN & Direct",
        "Global Proxy Tunnel",
        "Gaming Low-Latency Split"
    )
    val mtuChoices = listOf(1280, 1400, 1420, 1500)

    MachinedAluminumPlate(cornerRadius = 11.dp, innerPadding = 10.dp) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(IndustrialColors.RecessedTrayBackground)
                .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = strings.settingsTitle,
                color = IndustrialColors.AmberGlow,
                fontSize = 11.sp,
                fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                fontWeight = FontWeight.Bold
            )

            // DNS Provider Selection
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = strings.dnsLabel,
                    color = IndustrialColors.CyanTelemetry,
                    fontSize = 10.sp,
                    fontFamily = activeFont,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    dnsChoices.forEach { (name, ip) ->
                        val selected = dnsIp == ip
                        BrushedSteelKeyCap(
                            modifier = Modifier.testTag("dns_option_$ip"),
                            isHighlighted = selected,
                            darkSurface = true,
                            onClick = {
                                dnsName = name
                                dnsIp = ip
                            }
                        ) {
                            Text(
                                text = "$name ($ip)",
                                fontSize = 10.sp,
                                fontFamily = RobotoMonoFontFamily,
                                color = if (selected) IndustrialColors.AmberGlow else IndustrialColors.TextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Split Routing Mode
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = strings.routingLabel,
                    color = IndustrialColors.CyanTelemetry,
                    fontSize = 10.sp,
                    fontFamily = activeFont,
                    fontWeight = FontWeight.Bold
                )
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    routingChoices.forEach { mode ->
                        val selected = routingMode == mode
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(if (selected) Color(0xFF211A12) else IndustrialColors.DeepRecess)
                                .border(
                                    1.dp,
                                    if (selected) IndustrialColors.CopperFront else IndustrialColors.MachinedBorder,
                                    RoundedCornerShape(5.dp)
                                )
                                .clickable { routingMode = mode }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = mode,
                                color = if (selected) IndustrialColors.AmberGlow else IndustrialColors.TextSecondary,
                                fontSize = 12.sp,
                                fontFamily = RobotoMonoFontFamily,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (selected) IndustrialColors.EmeraldSafe else IndustrialColors.MachinedHighlight)
                            )
                        }
                    }
                }
            }

            // MTU Calibration
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = strings.mtuLabel,
                    color = IndustrialColors.CyanTelemetry,
                    fontSize = 10.sp,
                    fontFamily = activeFont,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    mtuChoices.forEach { value ->
                        val selected = mtu == value
                        BrushedSteelKeyCap(
                            modifier = Modifier
                                .weight(1f)
                                .testTag("mtu_option_$value"),
                            isHighlighted = selected,
                            darkSurface = true,
                            onClick = { mtu = value }
                        ) {
                            Text(
                                text = "$value",
                                fontSize = 11.sp,
                                fontFamily = RobotoMonoFontFamily,
                                color = if (selected) IndustrialColors.AmberGlow else IndustrialColors.TextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Toggles
            SettingSwitchRow(
                label = strings.ipv6GuardLabel,
                checked = ipv6Guard,
                language = language,
                testTag = "switch_ipv6_guard",
                onCheckedChange = { ipv6Guard = it }
            )
            SettingSwitchRow(
                label = strings.selfHealLabel,
                checked = selfHeal,
                language = language,
                testTag = "switch_self_heal",
                onCheckedChange = { selfHeal = it }
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                IndustrialColors.CopperHighlightCap,
                                IndustrialColors.CopperFront,
                                IndustrialColors.CopperSideBevel
                            )
                        )
                    )
                    .border(1.dp, IndustrialColors.CopperHighlightCap, RoundedCornerShape(6.dp))
                    .clickable {
                        onSaveSettings(
                            VpnSettings(
                                dnsProviderName = dnsName,
                                dnsIp = dnsIp,
                                routingMode = routingMode,
                                mtu = mtu,
                                ipv6LeakProtection = ipv6Guard,
                                autoReconnectSelfHeal = selfHeal
                            )
                        )
                    }
                    .testTag("save_settings_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = strings.saveSettingsBtn,
                    color = IndustrialColors.DeepRecess,
                    fontSize = 12.sp,
                    fontFamily = activeFont,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    label: String,
    checked: Boolean,
    language: AppLanguage,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    val activeFont = if (language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 48.dp)
            .clip(RoundedCornerShape(5.dp))
            .background(IndustrialColors.DeepRecess)
            .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(5.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = IndustrialColors.TextPrimary,
            fontSize = 12.sp,
            fontFamily = activeFont,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = IndustrialColors.AmberGlow,
                checkedTrackColor = IndustrialColors.CopperSideBevel,
                uncheckedThumbColor = IndustrialColors.TextMuted,
                uncheckedTrackColor = IndustrialColors.GunmetalChassis
            )
        )
    }
}

@Composable
fun DeveloperScreen(
    diagSnapshot: NetworkDiagSnapshot,
    operatorName: String,
    operatorEmail: String?,
    cloudSynced: Boolean,
    aiSessions: List<AiSessionRecord>,
    language: AppLanguage,
    strings: UiStrings,
    onSignOut: () -> Unit,
    onBackToTunnel: () -> Unit
) {
    BackHandler(onBack = onBackToTunnel)
    val activeFont = if (language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Cloud Operator & Sign-Out Panel
        MachinedAluminumPlate(cornerRadius = 11.dp, innerPadding = 10.dp) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(IndustrialColors.RecessedTrayBackground)
                    .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.operatorAccountLabel,
                        color = IndustrialColors.CyanTelemetry,
                        fontSize = 10.sp,
                        fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (cloudSynced) Color(0xFF0E2920) else Color(0xFF281D0F))
                            .border(
                                1.dp,
                                if (cloudSynced) IndustrialColors.EmeraldSafe else IndustrialColors.AmberGlow,
                                RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (cloudSynced) strings.cloudSyncActive else "SYNCING…",
                            color = if (cloudSynced) IndustrialColors.EmeraldSafe else IndustrialColors.AmberGlow,
                            fontSize = 8.sp,
                            fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(IndustrialColors.DeepRecess)
                        .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(6.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = operatorName.ifBlank { "Operator" },
                        color = IndustrialColors.TextPrimary,
                        fontSize = 13.sp,
                        fontFamily = InterFontFamily,
                        fontWeight = FontWeight.Bold
                    )
                    if (!operatorEmail.isNullOrBlank()) {
                        Text(
                            text = operatorEmail,
                            color = IndustrialColors.TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = RobotoMonoFontFamily
                        )
                    }
                }

                BrushedSteelKeyCap(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sign_out_button"),
                    darkSurface = true,
                    onClick = onSignOut
                ) {
                    Text(
                        text = strings.cloudSignOutBtn,
                        color = IndustrialColors.RubyError,
                        fontSize = 11.sp,
                        fontFamily = activeFont,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        MachinedAluminumPlate(cornerRadius = 11.dp, innerPadding = 10.dp) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(IndustrialColors.RecessedTrayBackground)
                    .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_victor_geek_avatar),
                        contentDescription = stringResource(id = R.string.cd_developer_avatar),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(2.dp, IndustrialColors.CopperFront, RoundedCornerShape(10.dp))
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.devRole,
                            color = IndustrialColors.AmberGlow,
                            fontSize = 12.sp,
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = strings.devBio,
                            color = IndustrialColors.TextSecondary,
                            fontSize = 12.sp,
                            fontFamily = activeFont
                        )
                    }
                }
            }
        }

        MachinedAluminumPlate(cornerRadius = 11.dp, innerPadding = 10.dp) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(IndustrialColors.RecessedTrayBackground)
                    .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = strings.systemSpecsTitle,
                    color = IndustrialColors.AmberGlow,
                    fontSize = 11.sp,
                    fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold
                )
                SpecLine("TUN ENGINE", "Android VpnService + XrayConfigFactory")
                SpecLine("XRAY CORE", diagSnapshot.xrayVersion)
                SpecLine("AI LEADER", "Firebase AI Logic (gemini-3.8-flash)")
                SpecLine("AI VOICE", "Gemini 3.8 Live (gemini-3.8-live)")
                SpecLine("CLOUD SYNC", "Firestore Enterprise (User-Isolated)")
                SpecLine("PROTOCOLS", "VLESS (Reality/WS), VMess, Trojan, SS, Hysteria2")
            }
        }

        // Cloud AI & Live Voice Session Logs
        MachinedAluminumPlate(cornerRadius = 11.dp, innerPadding = 10.dp) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(IndustrialColors.RecessedTrayBackground)
                    .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "${strings.aiHistoryTitle} (${aiSessions.size})",
                    color = IndustrialColors.AmberGlow,
                    fontSize = 11.sp,
                    fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold
                )
                if (aiSessions.isEmpty()) {
                    Text(
                        text = strings.aiHistoryEmpty,
                        color = IndustrialColors.TextMuted,
                        fontSize = 11.sp,
                        fontFamily = activeFont
                    )
                } else {
                    aiSessions.take(6).forEach { rec ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(IndustrialColors.DeepRecess)
                                .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = rec.mode.uppercase(),
                                    color = IndustrialColors.CyanTelemetry,
                                    fontSize = 9.sp,
                                    fontFamily = RobotoMonoFontFamily,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${rec.recommendedProtocol} • DNS ${rec.recommendedDns}",
                                    color = IndustrialColors.EmeraldSafe,
                                    fontSize = 9.sp,
                                    fontFamily = RobotoMonoFontFamily
                                )
                            }
                            Text(
                                text = rec.query,
                                color = IndustrialColors.TextSecondary,
                                fontSize = 10.sp,
                                fontFamily = activeFont,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = rec.summary,
                                color = IndustrialColors.TextPrimary,
                                fontSize = 11.sp,
                                fontFamily = activeFont,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        MachinedAluminumPlate(cornerRadius = 11.dp, innerPadding = 10.dp) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(IndustrialColors.RecessedTrayBackground)
                    .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = strings.complianceTitle,
                    color = IndustrialColors.EmeraldSafe,
                    fontSize = 11.sp,
                    fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = strings.complianceDesc,
                    color = IndustrialColors.TextSecondary,
                    fontSize = 12.sp,
                    fontFamily = activeFont
                )
            }
        }
    }
}

@Composable
private fun SpecLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(IndustrialColors.DeepRecess)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = IndustrialColors.CyanTelemetry,
            fontSize = 10.sp,
            fontFamily = RobotoMonoFontFamily,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            color = IndustrialColors.TextPrimary,
            fontSize = 10.sp,
            fontFamily = RobotoMonoFontFamily
        )
    }
}
