package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiLiveVoiceController
import com.example.ai.GeminiRouterRepository
import com.example.ai.LiveVoiceToolBridge
import com.example.ai.VoiceConsoleState
import com.example.data.AiSessionRecord
import com.example.data.CloudSyncRepository
import com.example.data.ConfigRepository
import com.example.model.AiAdvisorState
import com.example.model.AiRoutingAdvice
import com.example.model.AppLanguage
import com.example.model.NetworkDiagSnapshot
import com.example.model.TargetPlatform
import com.example.model.Telemetry
import com.example.model.TunnelState
import com.example.model.VpnNode
import com.example.model.VpnSettings
import com.example.telemetry.AiLogEntry
import com.example.telemetry.AiLogLevel
import com.example.telemetry.LiveLogBus
import com.example.vpn.AiTunnelOrchestrator
import com.example.vpn.NodeParser
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

private const val TAG = "MainViewModel"

data class MainUiState(
    val tunnelState: TunnelState = TunnelState.STOPPED,
    val statusMessage: String = "Ready",
    val coreActive: Boolean = false,
    val telemetry: Telemetry = Telemetry(),
    val nodes: List<VpnNode> = emptyList(),
    val activeNodeId: String = "",
    val selectedTarget: TargetPlatform = TargetPlatform.GENERAL,
    val protocolFilter: String = "ALL",
    val under100MsOnly: Boolean = false,
    val language: AppLanguage = AppLanguage.EN,
    val settings: VpnSettings = VpnSettings(),
    val aiAdvisorState: AiAdvisorState = AiAdvisorState.Idle,
    val diagAiState: AiAdvisorState = AiAdvisorState.Idle,
    val diagSnapshot: NetworkDiagSnapshot = NetworkDiagSnapshot(),
    val isTestingPings: Boolean = false,
    val isImporting: Boolean = false,
    val importFeedback: String? = null,
    val cloudSynced: Boolean = false,
    val cloudError: String? = null,
    val aiSessions: List<AiSessionRecord> = emptyList(),
    val operatorName: String = "",
    val operatorEmail: String? = null
) {
    val activeNode: VpnNode?
        get() = nodes.firstOrNull { it.id == activeNodeId } ?: nodes.firstOrNull()

    val filteredNodes: List<VpnNode>
        get() = nodes.filter { node ->
            val protoOk = protocolFilter == "ALL" || node.protocol.equals(protocolFilter, ignoreCase = true)
            val pingOk = !under100MsOnly || (node.latencyMs in 1..100)
            protoOk && pingOk
        }
}

class MainViewModel(
    private val repository: ConfigRepository,
    private val cloudSyncRepository: CloudSyncRepository,
    private val currentUserId: String,
    private val operatorDisplayName: String,
    private val operatorEmail: String?,
    private val operatorPhotoUrl: String?,
    private val diagSnapshotProvider: suspend (VpnSettings) -> NetworkDiagSnapshot,
    private val voiceController: GeminiLiveVoiceController = GeminiLiveVoiceController()
) : ViewModel() {

    private val geminiRepo = GeminiRouterRepository()
    private val orchestrator = AiTunnelOrchestrator()

    private val _uiState = MutableStateFlow(
        MainUiState(
            nodes = repository.getNodes(),
            activeNodeId = repository.getActiveNodeId(),
            selectedTarget = repository.getTargetPlatform(),
            language = repository.getLanguage(),
            settings = repository.getSettings(),
            operatorName = operatorDisplayName.ifBlank { "Operator" },
            operatorEmail = operatorEmail
        )
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()
    val liveLogs: StateFlow<List<AiLogEntry>> = LiveLogBus.logs
    val voiceState: StateFlow<VoiceConsoleState> = voiceController.state

    private var seededNodesOnFirstLoad = false
    private var seededSettingsOnFirstLoad = false

    init {
        LiveLogBus.log("AI-LEADER", "Gemini 3.8 Flash + Live 3.8 Voice ready", AiLogLevel.AI)
        LiveLogBus.log("AI-NANO", "Rule-based autonomous failover engine armed", AiLogLevel.INFO)
        val count = _uiState.value.nodes.size
        LiveLogBus.log(
            "NODE-MATRIX",
            if (count > 0) "Loaded $count cached V2Ray node(s)" else "Waiting for V2Ray config import",
            if (count > 0) AiLogLevel.SUCCESS else AiLogLevel.INFO
        )
        refreshDiagnosticsSnapshot()
        bootstrapCloudSync()
    }

    private fun bootstrapCloudSync() {
        viewModelScope.launch {
            cloudSyncRepository.upsertUserProfile(
                displayName = operatorDisplayName,
                email = operatorEmail,
                photoUrl = operatorPhotoUrl
            ).onFailure { err ->
                Log.w(TAG, "Profile sync warning: ${err.message}")
            }
        }

        // Real-time node matrix observer with two-tier Flow error handling
        viewModelScope.launch {
            cloudSyncRepository.observeNodes(currentUserId)
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val rootError = firestoreError ?: error
                    Log.w(TAG, "Error observing cloud nodes", rootError)
                    _uiState.update { it.copy(cloudError = rootError.message ?: "Cloud node sync paused") }
                }
                .collect { cloudNodes ->
                    if (cloudNodes.isEmpty() && !seededNodesOnFirstLoad) {
                        seededNodesOnFirstLoad = true
                        val localNodes = repository.getNodes()
                        if (localNodes.isNotEmpty()) {
                            cloudSyncRepository.syncNodes(localNodes)
                        }
                        _uiState.update { it.copy(cloudSynced = true, cloudError = null) }
                    } else {
                        seededNodesOnFirstLoad = true
                        val sorted = cloudNodes.sortedWith(
                            compareBy<VpnNode> { if (it.latencyMs in 1..Int.MAX_VALUE) it.latencyMs else Long.MAX_VALUE }
                        )
                        repository.saveNodes(sorted)
                        val currentActive = repository.getActiveNodeId()
                        val resolvedActive = if (sorted.any { it.id == currentActive }) {
                            currentActive
                        } else {
                            sorted.firstOrNull()?.id.orEmpty().also { repository.setActiveNodeId(it) }
                        }
                        _uiState.update {
                            it.copy(
                                nodes = sorted,
                                activeNodeId = resolvedActive,
                                cloudSynced = true,
                                cloudError = null
                            )
                        }
                    }
                }
        }

        // Real-time tunnel settings & language observer
        viewModelScope.launch {
            cloudSyncRepository.observeSettings(currentUserId)
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val rootError = firestoreError ?: error
                    Log.w(TAG, "Error observing cloud settings", rootError)
                }
                .collect { cloudSettings ->
                    if (cloudSettings == null && !seededSettingsOnFirstLoad) {
                        seededSettingsOnFirstLoad = true
                        val snap = _uiState.value
                        cloudSyncRepository.saveSettings(
                            settings = snap.settings,
                            language = snap.language,
                            activeNodeId = snap.activeNodeId
                        )
                    } else if (cloudSettings != null) {
                        seededSettingsOnFirstLoad = true
                        val syncedSettings = VpnSettings(
                            dnsProviderName = cloudSettings.dnsProviderName.ifBlank { "Cloudflare DoH" },
                            dnsIp = cloudSettings.dnsIp.ifBlank { "1.1.1.1" },
                            routingMode = cloudSettings.routingMode.ifBlank { "Bypass Myanmar LAN & Direct" },
                            mtu = cloudSettings.mtu.toInt().coerceIn(1200, 1500),
                            ipv6LeakProtection = cloudSettings.ipv6LeakProtection,
                            autoReconnectSelfHeal = cloudSettings.autoReconnectSelfHeal
                        )
                        val syncedLang = AppLanguage.entries.firstOrNull {
                            it.code == cloudSettings.preferredLanguage
                        } ?: _uiState.value.language
                        repository.saveSettings(syncedSettings)
                        repository.saveLanguage(syncedLang)
                        if (cloudSettings.activeNodeId.isNotBlank() &&
                            _uiState.value.nodes.any { it.id == cloudSettings.activeNodeId }
                        ) {
                            repository.setActiveNodeId(cloudSettings.activeNodeId)
                        }
                        _uiState.update { prev ->
                            prev.copy(
                                settings = syncedSettings,
                                language = syncedLang,
                                activeNodeId = if (cloudSettings.activeNodeId.isNotBlank() &&
                                    prev.nodes.any { it.id == cloudSettings.activeNodeId }
                                ) {
                                    cloudSettings.activeNodeId
                                } else {
                                    prev.activeNodeId
                                },
                                cloudSynced = true
                            )
                        }
                    }
                }
        }

        // Real-time AI & Voice Session History observer
        viewModelScope.launch {
            cloudSyncRepository.observeAiSessions(currentUserId)
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    Log.w(TAG, "Error observing AI sessions", firestoreError ?: error)
                }
                .collect { sessions ->
                    _uiState.update { it.copy(aiSessions = sessions) }
                }
        }
    }

    fun clearLiveLogs() {
        LiveLogBus.clear()
    }

    fun toggleLanguage() {
        val next = if (_uiState.value.language == AppLanguage.EN) AppLanguage.MM else AppLanguage.EN
        repository.saveLanguage(next)
        _uiState.update { it.copy(language = next) }
        persistSettingsToCloud()
    }

    fun selectTargetPlatform(target: TargetPlatform) {
        repository.saveTargetPlatform(target)
        _uiState.update { it.copy(selectedTarget = target) }
    }

    fun setProtocolFilter(protocol: String) {
        _uiState.update { it.copy(protocolFilter = protocol) }
    }

    fun toggleUnder100MsOnly() {
        _uiState.update { it.copy(under100MsOnly = !it.under100MsOnly) }
    }

    fun selectNode(nodeId: String) {
        repository.setActiveNodeId(nodeId)
        _uiState.update { it.copy(activeNodeId = nodeId) }
        persistSettingsToCloud()
    }

    fun removeNode(nodeId: String) {
        val updated = repository.removeNode(nodeId)
        _uiState.update {
            it.copy(
                nodes = updated,
                activeNodeId = repository.getActiveNodeId()
            )
        }
        viewModelScope.launch {
            cloudSyncRepository.deleteNode(nodeId)
            persistSettingsSnapshot(_uiState.value)
        }
    }

    fun clearImportFeedback() {
        _uiState.update { it.copy(importFeedback = null) }
    }

    fun importNodes(rawInput: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _uiState.update { it.copy(isImporting = true, importFeedback = null) }
            val result = repository.importAndSync(rawInput)
            result.onSuccess { synced ->
                val activeId = repository.getActiveNodeId()
                _uiState.update {
                    it.copy(
                        isImporting = false,
                        nodes = synced,
                        activeNodeId = activeId,
                        importFeedback = "Imported & tested ${synced.size} node(s).",
                        statusMessage = "${synced.size} node(s) ready"
                    )
                }
                cloudSyncRepository.syncNodes(synced)
                persistSettingsSnapshot(_uiState.value)
                onSuccess()
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isImporting = false,
                        importFeedback = err.message ?: "Failed to parse configuration."
                    )
                }
            }
        }
    }

    fun extractAndImportWithAi(messyText: String, onSuccess: () -> Unit = {}) {
        if (messyText.isBlank()) {
            _uiState.update { it.copy(importFeedback = "Paste text containing V2Ray links first.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isImporting = true, importFeedback = null) }
            val direct = NodeParser.parseNodes(messyText)
            if (direct.isNotEmpty()) {
                importNodes(direct.joinToString("\n") { it.rawLink }, onSuccess)
                return@launch
            }
            val aiResult = geminiRepo.extractV2RayLinksFromText(messyText)
            aiResult.onSuccess { links ->
                if (links.isEmpty()) {
                    _uiState.update {
                        it.copy(
                            isImporting = false,
                            importFeedback = "Gemini AI found no V2Ray share links in the pasted text."
                        )
                    }
                } else {
                    importNodes(links.joinToString("\n"), onSuccess)
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isImporting = false,
                        importFeedback = err.message ?: "AI extraction failed."
                    )
                }
            }
        }
    }

    fun refreshPings() {
        if (_uiState.value.nodes.isEmpty() || _uiState.value.isTestingPings) return
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingPings = true) }
            val refreshed = repository.refreshNodePings()
            _uiState.update {
                it.copy(
                    isTestingPings = false,
                    nodes = refreshed,
                    statusMessage = "Ping calibration updated (${refreshed.size} nodes)"
                )
            }
            cloudSyncRepository.syncNodes(refreshed)
        }
    }

    fun autoPickBestNode(): VpnNode? {
        val state = _uiState.value
        val best = orchestrator.autoSelectBestNode(state.nodes, state.selectedTarget) ?: return null
        repository.setActiveNodeId(best.id)
        LiveLogBus.log(
            "AI-NANO",
            "Auto-selected ${best.name} (${best.protocol.uppercase()}, ping=${best.latencyMs}ms, score=${"%.1f".format(best.score)})",
            AiLogLevel.SUCCESS
        )
        _uiState.update {
            it.copy(
                activeNodeId = best.id,
                statusMessage = "AI Selected: ${best.name} (${best.latencyMs}ms)"
            )
        }
        persistSettingsToCloud()
        return best
    }

    fun askGeminiRouter(customQuery: String) {
        val state = _uiState.value
        viewModelScope.launch {
            _uiState.update { it.copy(aiAdvisorState = AiAdvisorState.Loading) }
            val result = geminiRepo.recommendRoutingForTarget(
                targetPlatform = state.selectedTarget,
                customQuery = customQuery,
                nodes = state.nodes,
                settings = state.settings,
                language = state.language
            )
            result.onSuccess { advice ->
                advice.targetNodeId?.let { suggestedId ->
                    if (state.nodes.any { it.id == suggestedId }) {
                        repository.setActiveNodeId(suggestedId)
                        _uiState.update { it.copy(activeNodeId = suggestedId) }
                        persistSettingsToCloud()
                    }
                }
                _uiState.update { it.copy(aiAdvisorState = AiAdvisorState.Success(advice)) }
                cloudSyncRepository.recordAiSession(
                    mode = "routing",
                    query = customQuery.ifBlank { state.selectedTarget.labelEn },
                    summary = advice.summary,
                    recommendedProtocol = advice.recommendedProtocol,
                    recommendedDns = advice.recommendedDns,
                    recommendedMtu = advice.recommendedMtu
                )
            }.onFailure { err ->
                _uiState.update {
                    it.copy(aiAdvisorState = AiAdvisorState.Error(err.message ?: "AI query failed"))
                }
            }
        }
    }

    fun runAiNetworkDiagnostics() {
        viewModelScope.launch {
            _uiState.update { it.copy(diagAiState = AiAdvisorState.Loading) }
            val freshSnap = diagSnapshotProvider(_uiState.value.settings)
            _uiState.update { it.copy(diagSnapshot = freshSnap) }
            val language = _uiState.value.language
            val result = geminiRepo.analyzeNetworkDiagnostics(freshSnap, language)
            result.onSuccess { advice ->
                _uiState.update { it.copy(diagAiState = AiAdvisorState.Success(advice)) }
                cloudSyncRepository.recordAiSession(
                    mode = "diagnostics",
                    query = "${freshSnap.networkType} DNS=${freshSnap.activeDns} MTU=${freshSnap.mtu}",
                    summary = advice.summary,
                    recommendedProtocol = advice.recommendedProtocol,
                    recommendedDns = advice.recommendedDns,
                    recommendedMtu = advice.recommendedMtu
                )
            }.onFailure { err ->
                _uiState.update {
                    it.copy(diagAiState = AiAdvisorState.Error(err.message ?: "Diagnostics AI failed"))
                }
            }
        }
    }

    fun applyAiAdvice(advice: AiRoutingAdvice) {
        val current = _uiState.value.settings
        val dnsName = dnsProviderLabelForIp(advice.recommendedDns)
        val updated = current.copy(
            dnsProviderName = dnsName,
            dnsIp = advice.recommendedDns.ifBlank { current.dnsIp },
            mtu = advice.recommendedMtu.coerceIn(1200, 1500)
        )
        repository.saveSettings(updated)
        advice.targetNodeId?.let { id ->
            if (_uiState.value.nodes.any { it.id == id }) {
                repository.setActiveNodeId(id)
                _uiState.update { it.copy(activeNodeId = id) }
            }
        }
        LiveLogBus.log(
            "CONFIG-SYNC",
            "Applied AI calibration -> DNS ${updated.dnsIp}, MTU ${updated.mtu}",
            AiLogLevel.SUCCESS
        )
        _uiState.update {
            it.copy(
                settings = updated,
                statusMessage = "Applied AI Calibration (${updated.dnsIp}, MTU ${updated.mtu})"
            )
        }
        persistSettingsToCloud()
    }

    fun updateSettings(settings: VpnSettings) {
        repository.saveSettings(settings)
        _uiState.update {
            it.copy(
                settings = settings,
                statusMessage = StringsCatalog.get(it.language).settingsSavedMsg
            )
        }
        persistSettingsToCloud()
    }

    fun startVoiceConversation() {
        val lang = _uiState.value.language
        val bridge = object : LiveVoiceToolBridge {
            override fun autoPickBestNode(): String {
                val picked = this@MainViewModel.autoPickBestNode()
                return if (picked != null) {
                    "Selected ${picked.name} (${picked.protocol}, ${picked.latencyMs}ms)"
                } else {
                    "No imported V2Ray nodes available."
                }
            }

            override fun applyDnsAndMtu(dnsIp: String, mtu: Int): String {
                val clampedMtu = mtu.coerceIn(1200, 1500)
                val cleanDns = dnsIp.ifBlank { _uiState.value.settings.dnsIp }
                val updated = _uiState.value.settings.copy(
                    dnsProviderName = dnsProviderLabelForIp(cleanDns),
                    dnsIp = cleanDns,
                    mtu = clampedMtu
                )
                updateSettings(updated)
                return "Updated DNS=$cleanDns, MTU=$clampedMtu and synced to Firestore."
            }

            override fun switchLanguage(languageCode: String): String {
                val target = if (languageCode.equals("mm", ignoreCase = true)) {
                    AppLanguage.MM
                } else {
                    AppLanguage.EN
                }
                repository.saveLanguage(target)
                _uiState.update { it.copy(language = target) }
                persistSettingsToCloud()
                return "Switched language to ${target.label}"
            }
        }

        voiceController.startSession(
            scope = viewModelScope,
            language = lang,
            toolBridge = bridge,
            onSessionSaved = { userText, aiText ->
                viewModelScope.launch {
                    val snap = _uiState.value
                    cloudSyncRepository.recordAiSession(
                        mode = "voice",
                        query = userText.ifBlank { "Live voice consultation" },
                        summary = aiText.ifBlank { "Gemini 3.8 Live audio session completed" },
                        recommendedProtocol = snap.activeNode?.protocol?.uppercase() ?: "VLESS",
                        recommendedDns = snap.settings.dnsIp,
                        recommendedMtu = snap.settings.mtu
                    )
                }
            }
        )
    }

    fun stopVoiceConversation() {
        voiceController.stopSession(viewModelScope)
    }

    fun clearVoiceError() {
        voiceController.clearError()
    }

    fun setTunnelState(state: TunnelState, message: String, activeNodeId: String = "", coreActive: Boolean = false) {
        _uiState.update { prev ->
            prev.copy(
                tunnelState = state,
                statusMessage = message.ifBlank { prev.statusMessage },
                activeNodeId = activeNodeId.ifBlank { prev.activeNodeId },
                coreActive = coreActive
            )
        }
    }

    fun setTelemetry(telemetry: Telemetry, activeNodeId: String = "", coreActive: Boolean = false) {
        _uiState.update { prev ->
            prev.copy(
                telemetry = telemetry,
                activeNodeId = activeNodeId.ifBlank { prev.activeNodeId },
                coreActive = coreActive
            )
        }
    }

    fun refreshDiagnosticsSnapshot() {
        viewModelScope.launch {
            val snap = diagSnapshotProvider(_uiState.value.settings)
            _uiState.update { it.copy(diagSnapshot = snap) }
        }
    }

    private fun persistSettingsToCloud() {
        val snap = _uiState.value
        viewModelScope.launch {
            persistSettingsSnapshot(snap)
        }
    }

    private suspend fun persistSettingsSnapshot(snap: MainUiState) {
        cloudSyncRepository.saveSettings(
            settings = snap.settings,
            language = snap.language,
            activeNodeId = snap.activeNodeId
        )
    }

    private fun dnsProviderLabelForIp(dnsIp: String): String = when (dnsIp) {
        "1.1.1.1" -> "Cloudflare DoH"
        "8.8.8.8" -> "Google DNS"
        "94.140.14.14" -> "AdGuard Anti-Filter"
        "45.90.28.0" -> "NextDNS Secure"
        else -> "AI Tuned DNS"
    }

    override fun onCleared() {
        voiceController.stopSession(viewModelScope)
        super.onCleared()
    }
}
