package com.example.ui.modals

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.model.AiAdvisorState
import com.example.model.AiRoutingAdvice
import com.example.model.AppLanguage
import com.example.model.NetworkDiagSnapshot
import com.example.model.VpnNode
import com.example.ui.UiStrings
import com.example.ui.components.BrushedSteelKeyCap
import com.example.ui.theme.IndustrialColors
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.MyanmarFontFamily
import com.example.ui.theme.RobotoMonoFontFamily
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter

@Composable
fun ImportConfigModal(
    language: AppLanguage,
    strings: UiStrings,
    isImporting: Boolean,
    feedback: String?,
    onImportDirect: (String) -> Unit,
    onAiExtract: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var text by rememberSaveable { mutableStateOf("") }
    val activeFont = if (language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily

    Dialog(onDismissRequest = onDismiss) {
        BackHandler(onBack = onDismiss)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            IndustrialColors.BrushedSteelLight,
                            IndustrialColors.BrushedSteelBackground
                        )
                    )
                )
                .border(1.5.dp, IndustrialColors.BevelHighlight, RoundedCornerShape(12.dp))
                .padding(10.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(IndustrialColors.RecessedTrayBackground)
                    .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.importModalTitle,
                        color = IndustrialColors.AmberGlow,
                        fontSize = 12.sp,
                        fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold
                    )
                    BrushedSteelKeyCap(
                        modifier = Modifier.testTag("import_paste_button"),
                        darkSurface = true,
                        onClick = {
                            val clipText = clipboard.getText()?.text.orEmpty()
                            if (clipText.isNotBlank()) text = clipText
                        }
                    ) {
                        Text(
                            text = strings.pasteClipboardBtn,
                            fontSize = 10.sp,
                            fontFamily = RobotoMonoFontFamily,
                            color = IndustrialColors.CyanTelemetry,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(IndustrialColors.DeepRecess)
                        .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it },
                        cursorBrush = SolidColor(IndustrialColors.AmberGlow),
                        textStyle = TextStyle(
                            color = IndustrialColors.AmberGlow,
                            fontFamily = RobotoMonoFontFamily,
                            fontSize = 11.sp
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("import_config_input")
                    )
                    if (text.isEmpty()) {
                        Text(
                            text = strings.importModalHint,
                            color = IndustrialColors.TextMuted,
                            fontSize = 11.sp,
                            fontFamily = activeFont
                        )
                    }
                }

                if (!feedback.isNullOrBlank()) {
                    Text(
                        text = feedback,
                        color = IndustrialColors.AmberGlow,
                        fontSize = 11.sp,
                        fontFamily = activeFont
                    )
                }

                if (isImporting) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = IndustrialColors.CopperFront,
                            strokeWidth = 2.dp
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 48.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        IndustrialColors.CopperHighlightCap,
                                        IndustrialColors.CopperFront,
                                        IndustrialColors.CopperSideBevel
                                    )
                                )
                            )
                            .clickable { onImportDirect(text) }
                            .testTag("import_submit_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strings.importActionBtn,
                            color = IndustrialColors.DeepRecess,
                            fontSize = 11.sp,
                            fontFamily = activeFont,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BrushedSteelKeyCap(
                            modifier = Modifier
                                .weight(1f)
                                .testTag("import_ai_extract_button"),
                            isHighlighted = true,
                            darkSurface = true,
                            onClick = { onAiExtract(text) }
                        ) {
                            Text(
                                text = strings.aiExtractBtn,
                                fontSize = 10.sp,
                                fontFamily = activeFont,
                                color = IndustrialColors.AmberGlow,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        BrushedSteelKeyCap(
                            modifier = Modifier.testTag("import_close_button"),
                            darkSurface = true,
                            onClick = onDismiss
                        ) {
                            Text(
                                text = strings.closeBtn,
                                fontSize = 10.sp,
                                fontFamily = activeFont,
                                color = IndustrialColors.TextSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DiagnosticsModal(
    snapshot: NetworkDiagSnapshot,
    diagAiState: AiAdvisorState,
    language: AppLanguage,
    strings: UiStrings,
    onRunAiDiag: () -> Unit,
    onApplyAiTuning: (AiRoutingAdvice) -> Unit,
    onDismiss: () -> Unit
) {
    val activeFont = if (language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily

    Dialog(onDismissRequest = onDismiss) {
        BackHandler(onBack = onDismiss)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            IndustrialColors.BrushedSteelLight,
                            IndustrialColors.BrushedSteelBackground
                        )
                    )
                )
                .border(1.5.dp, IndustrialColors.BevelHighlight, RoundedCornerShape(12.dp))
                .padding(10.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(IndustrialColors.RecessedTrayBackground)
                    .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = strings.diagModalTitle,
                    color = IndustrialColors.AmberGlow,
                    fontSize = 13.sp,
                    fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = strings.diagModalSubtitle,
                    color = IndustrialColors.TextSecondary,
                    fontSize = 11.sp,
                    fontFamily = activeFont
                )

                DiagRow("TRANSPORT", snapshot.networkType)
                DiagRow("INTERFACE", snapshot.interfaceName)
                DiagRow("DNS TARGET", snapshot.activeDns)
                DiagRow("MTU", "${snapshot.mtu} bytes")
                DiagRow("IPv6 GUARD", if (snapshot.ipv6Guard) "ENABLED" else "OFF")
                DiagRow("LIBXRAY AAR", snapshot.xrayVersion)

                when (diagAiState) {
                    is AiAdvisorState.Loading -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = IndustrialColors.CopperFront,
                                strokeWidth = 2.dp
                            )
                        }
                    }

                    is AiAdvisorState.Success -> {
                        val adv = diagAiState.advice
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(IndustrialColors.DeepRecess)
                                .border(1.dp, IndustrialColors.CopperFront, RoundedCornerShape(6.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = adv.summary,
                                color = IndustrialColors.TextPrimary,
                                fontSize = 12.sp,
                                fontFamily = activeFont
                            )
                            Text(
                                text = "DNS: ${adv.recommendedDns} • MTU: ${adv.recommendedMtu} • ${adv.routingTip}",
                                color = IndustrialColors.AmberGlow,
                                fontSize = 11.sp,
                                fontFamily = activeFont
                            )
                            BrushedSteelKeyCap(
                                modifier = Modifier.testTag("diag_apply_button"),
                                isHighlighted = true,
                                darkSurface = true,
                                onClick = { onApplyAiTuning(adv) }
                            ) {
                                Text(
                                    text = strings.applyAiTuningBtn,
                                    fontSize = 10.sp,
                                    fontFamily = activeFont,
                                    color = IndustrialColors.AmberGlow,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    is AiAdvisorState.Error -> {
                        Text(
                            text = diagAiState.message,
                            color = IndustrialColors.RubyError,
                            fontSize = 11.sp,
                            fontFamily = activeFont
                        )
                    }

                    AiAdvisorState.Idle -> Unit
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BrushedSteelKeyCap(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("diag_run_ai_button"),
                        isHighlighted = true,
                        darkSurface = true,
                        onClick = onRunAiDiag
                    ) {
                        Text(
                            text = strings.runAiDiagBtn,
                            fontSize = 10.sp,
                            fontFamily = activeFont,
                            color = IndustrialColors.AmberGlow,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    BrushedSteelKeyCap(
                        modifier = Modifier.testTag("diag_close_button"),
                        darkSurface = true,
                        onClick = onDismiss
                    ) {
                        Text(
                            text = strings.closeBtn,
                            fontSize = 10.sp,
                            fontFamily = activeFont,
                            color = IndustrialColors.TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(IndustrialColors.DeepRecess)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = IndustrialColors.CyanTelemetry,
            fontSize = 10.sp,
            fontFamily = RobotoMonoFontFamily,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = value,
            color = IndustrialColors.TextPrimary,
            fontSize = 10.sp,
            fontFamily = RobotoMonoFontFamily
        )
    }
}

@Composable
fun QrShareModal(
    node: VpnNode,
    language: AppLanguage,
    strings: UiStrings,
    onCopyLink: () -> Unit,
    onDismiss: () -> Unit
) {
    val activeFont = if (language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily
    val qrBitmap by produceState<Bitmap?>(initialValue = null, node.rawLink) {
        value = withContext(Dispatchers.Default) {
            generateQrBitmap(node.rawLink, 512)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        BackHandler(onBack = onDismiss)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            IndustrialColors.BrushedSteelLight,
                            IndustrialColors.BrushedSteelBackground
                        )
                    )
                )
                .border(1.5.dp, IndustrialColors.BevelHighlight, RoundedCornerShape(12.dp))
                .padding(10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(IndustrialColors.RecessedTrayBackground)
                    .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = strings.qrModalTitle,
                    color = IndustrialColors.AmberGlow,
                    fontSize = 13.sp,
                    fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = node.name,
                    color = IndustrialColors.TextPrimary,
                    fontSize = 12.sp,
                    fontFamily = activeFont,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = strings.qrModalSubtitle,
                    color = IndustrialColors.TextSecondary,
                    fontSize = 11.sp,
                    fontFamily = activeFont
                )

                Box(
                    modifier = Modifier
                        .size(216.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .border(2.dp, IndustrialColors.CopperFront, RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val bmp = qrBitmap
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = stringResource(id = R.string.cd_qr_code),
                            modifier = Modifier.size(196.dp)
                        )
                    } else {
                        CircularProgressIndicator(
                            modifier = Modifier.size(28.dp),
                            color = IndustrialColors.CopperFront,
                            strokeWidth = 2.5.dp
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BrushedSteelKeyCap(
                        modifier = Modifier
                            .weight(1f)
                            .testTag("qr_copy_button"),
                        isHighlighted = true,
                        darkSurface = true,
                        onClick = onCopyLink
                    ) {
                        Text(
                            text = strings.copyKey,
                            fontSize = 10.sp,
                            fontFamily = activeFont,
                            color = IndustrialColors.AmberGlow,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    BrushedSteelKeyCap(
                        modifier = Modifier.testTag("qr_close_button"),
                        darkSurface = true,
                        onClick = onDismiss
                    ) {
                        Text(
                            text = strings.closeBtn,
                            fontSize = 10.sp,
                            fontFamily = activeFont,
                            color = IndustrialColors.TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

private fun generateQrBitmap(content: String, sizePx: Int): Bitmap? = runCatching {
    val hints = mapOf(
        EncodeHintType.MARGIN to 1,
        EncodeHintType.CHARACTER_SET to "UTF-8"
    )
    val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
    val pixels = IntArray(sizePx * sizePx)
    for (y in 0 until sizePx) {
        val offset = y * sizePx
        for (x in 0 until sizePx) {
            pixels[offset + x] = if (matrix[x, y]) AndroidColor.BLACK else AndroidColor.WHITE
        }
    }
    Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888).apply {
        setPixels(pixels, 0, sizePx, 0, 0, sizePx, sizePx)
    }
}.getOrNull()
