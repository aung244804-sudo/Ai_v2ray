package com.example.data

import android.content.Context
import com.example.R
import com.example.model.AppLanguage
import com.example.model.VpnNode
import com.example.model.VpnSettings
import com.example.telemetry.AiLogLevel
import com.example.telemetry.LiveLogBus
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class CloudSyncRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must sign in with Google before accessing cloud storage.")
    }

    suspend fun upsertUserProfile(
        displayName: String,
        email: String?,
        photoUrl: String?
    ): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        return try {
            val existing = docRef.get().await()
            if (existing.exists()) {
                val updates = mutableMapOf<String, Any>(
                    "displayName" to displayName.ifBlank { "AI V2Ray Operator" }.take(100),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!email.isNullOrBlank()) updates["email"] = email.take(254)
                if (!photoUrl.isNullOrBlank()) updates["photoUrl"] = photoUrl.take(500)
                docRef.update(updates).await()
            } else {
                val payload = mutableMapOf<String, Any>(
                    "userId" to uid,
                    "displayName" to displayName.ifBlank { "AI V2Ray Operator" }.take(100),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!email.isNullOrBlank()) payload["email"] = email.take(254)
                if (!photoUrl.isNullOrBlank()) payload["photoUrl"] = photoUrl.take(500)
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val op = OperationType.WRITE
            handleFirestoreError(e, op, docRef.path)
            Result.failure(e)
        }
    }

    fun observeNodes(userId: String): Flow<List<VpnNode>> {
        val path = "users/$userId/nodes"
        return db.collection("users")
            .document(userId)
            .collection("nodes")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    CloudVpnNode::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).map { it.toVpnNode() }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val exceptionToLog = firestoreError ?: (error as? Exception)
                if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                    handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                }
                throw error
            }
    }

    fun observeOwnNodes(): Flow<List<VpnNode>> = flow {
        val uid = requireUserId()
        emitAll(observeNodes(uid))
    }

    suspend fun upsertNode(node: VpnNode): Result<String> {
        val uid = requireUserId()
        val docId = sanitizeFirestoreDocId(node.id)
        val docRef = db.collection("users").document(uid).collection("nodes").document(docId)
        return try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                val updates = mapOf<String, Any>(
                    "nodeKey" to node.id.take(128),
                    "name" to node.name.ifBlank { "Unnamed Node" }.take(160),
                    "protocol" to node.protocol.ifBlank { "vless" }.take(32),
                    "address" to node.address.ifBlank { "0.0.0.0" }.take(255),
                    "port" to node.port.coerceIn(1, 65535).toLong(),
                    "rawLink" to node.rawLink.ifBlank { "vless://empty" }.take(4096),
                    "security" to node.security.take(32),
                    "network" to node.network.take(32),
                    "sni" to node.sni.take(255),
                    "region" to node.region.take(64),
                    "flag" to node.flag.take(16),
                    "latencyMs" to node.latencyMs.coerceIn(-1L, 60000L),
                    "isHealthy" to node.isHealthy,
                    "score" to node.score.coerceIn(-1000.0, 100000.0),
                    "failureCount" to node.failureCount.coerceIn(0, 10000).toLong(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            } else {
                val createPayload = mapOf<String, Any>(
                    "userId" to uid,
                    "nodeKey" to node.id.take(128),
                    "name" to node.name.ifBlank { "Unnamed Node" }.take(160),
                    "protocol" to node.protocol.ifBlank { "vless" }.take(32),
                    "address" to node.address.ifBlank { "0.0.0.0" }.take(255),
                    "port" to node.port.coerceIn(1, 65535).toLong(),
                    "rawLink" to node.rawLink.ifBlank { "vless://empty" }.take(4096),
                    "security" to node.security.take(32),
                    "network" to node.network.take(32),
                    "sni" to node.sni.take(255),
                    "region" to node.region.take(64),
                    "flag" to node.flag.take(16),
                    "latencyMs" to node.latencyMs.coerceIn(-1L, 60000L),
                    "isHealthy" to node.isHealthy,
                    "score" to node.score.coerceIn(-1000.0, 100000.0),
                    "failureCount" to node.failureCount.coerceIn(0, 10000).toLong(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(createPayload).await()
            }
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun syncNodes(nodes: List<VpnNode>): Result<Int> {
        var synced = 0
        for (node in nodes.take(100)) {
            val res = upsertNode(node)
            if (res.isFailure) return Result.failure(res.exceptionOrNull()!!)
            synced++
        }
        LiveLogBus.log("CLOUD-SYNC", "Synced $synced V2Ray node(s) to Firestore", AiLogLevel.SUCCESS)
        return Result.success(synced)
    }

    suspend fun deleteNode(nodeKey: String): Result<Unit> {
        val uid = requireUserId()
        val docId = sanitizeFirestoreDocId(nodeKey)
        val docRef = db.collection("users").document(uid).collection("nodes").document(docId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeSettings(userId: String): Flow<CloudVpnSettings?> {
        val docRef = db.collection("users").document(userId).collection("settings").document(SETTINGS_DOC_ID)
        return docRef.snapshots()
            .map { snapshot ->
                if (!snapshot.exists()) null
                else snapshot.toObject(
                    CloudVpnSettings::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val exceptionToLog = firestoreError ?: (error as? Exception)
                if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                    handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path)
                }
                throw error
            }
    }

    suspend fun saveSettings(
        settings: VpnSettings,
        language: AppLanguage,
        activeNodeId: String
    ): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("settings").document(SETTINGS_DOC_ID)
        return try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                val updates = mapOf<String, Any>(
                    "dnsProviderName" to settings.dnsProviderName.take(80),
                    "dnsIp" to settings.dnsIp.take(64),
                    "routingMode" to settings.routingMode.take(80),
                    "mtu" to settings.mtu.coerceIn(1200, 1500).toLong(),
                    "ipv6LeakProtection" to settings.ipv6LeakProtection,
                    "autoReconnectSelfHeal" to settings.autoReconnectSelfHeal,
                    "preferredLanguage" to language.code,
                    "activeNodeId" to activeNodeId.take(128),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            } else {
                val payload = mapOf<String, Any>(
                    "userId" to uid,
                    "dnsProviderName" to settings.dnsProviderName.take(80),
                    "dnsIp" to settings.dnsIp.take(64),
                    "routingMode" to settings.routingMode.take(80),
                    "mtu" to settings.mtu.coerceIn(1200, 1500).toLong(),
                    "ipv6LeakProtection" to settings.ipv6LeakProtection,
                    "autoReconnectSelfHeal" to settings.autoReconnectSelfHeal,
                    "preferredLanguage" to language.code,
                    "activeNodeId" to activeNodeId.take(128),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeAiSessions(userId: String): Flow<List<AiSessionRecord>> {
        val path = "users/$userId/ai_sessions"
        return db.collection("users")
            .document(userId)
            .collection("ai_sessions")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(20)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    AiSessionRecord::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val exceptionToLog = firestoreError ?: (error as? Exception)
                if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                    handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                }
                throw error
            }
    }

    suspend fun recordAiSession(
        mode: String,
        query: String,
        summary: String,
        recommendedProtocol: String,
        recommendedDns: String,
        recommendedMtu: Int
    ): Result<String> {
        val uid = requireUserId()
        val safeMode = if (mode in listOf("routing", "diagnostics", "voice")) mode else "routing"
        val docRef = db.collection("users").document(uid).collection("ai_sessions").document()
        val payload = mapOf<String, Any>(
            "userId" to uid,
            "mode" to safeMode,
            "query" to query.take(1000),
            "summary" to summary.ifBlank { "AI routing log" }.take(4000),
            "recommendedProtocol" to recommendedProtocol.take(64),
            "recommendedDns" to recommendedDns.take(64),
            "recommendedMtu" to recommendedMtu.coerceIn(1200, 1500).toLong(),
            "createdAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    companion object {
        const val SETTINGS_DOC_ID = "tunnel"
    }
}
