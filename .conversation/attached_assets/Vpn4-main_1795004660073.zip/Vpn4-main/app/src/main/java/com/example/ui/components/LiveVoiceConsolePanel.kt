package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ai.VoiceConsoleState
import com.example.ai.VoiceSessionStatus
import com.example.model.AppLanguage
import com.example.ui.UiStrings
import com.example.ui.theme.IndustrialColors
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.MyanmarFontFamily
import com.example.ui.theme.RobotoMonoFontFamily
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun LiveVoiceConsolePanel(
    voiceState: VoiceConsoleState,
    language: AppLanguage,
    strings: UiStrings,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    onDismissError: () -> Unit
) {
    val context = LocalContext.current
    val activeFont = if (language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily
    var permissionDeniedWarning by remember { mutableStateOf(false) }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            permissionDeniedWarning = false
            onStartVoice()
        } else {
            permissionDeniedWarning = true
        }
    }

    val isLive = voiceState.status == VoiceSessionStatus.ACTIVE
    val isConnecting = voiceState.status == VoiceSessionStatus.CONNECTING

    val waveTransition = rememberInfiniteTransition(label = "voiceWave")
    val wavePhase by waveTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.283f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "voiceWavePhase"
    )

    MachinedAluminumPlate(
        modifier = Modifier.testTag("live_voice_panel"),
        cornerRadius = 11.dp,
        innerPadding = 10.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(IndustrialColors.RecessedTrayBackground)
                .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.GraphicEq,
                        contentDescription = null,
                        tint = if (isLive) IndustrialColors.EmeraldSafe else IndustrialColors.CyanTelemetry,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = strings.voicePanelTitle,
                        color = if (isLive) IndustrialColors.EmeraldSafe else IndustrialColors.CyanTelemetry,
                        fontSize = 10.sp,
                        fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isLive) Color(0xFF0E2920) else Color(0xFF152230))
                        .border(
                            1.dp,
                            if (isLive) IndustrialColors.EmeraldSafe else IndustrialColors.CyanTelemetry,
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isLive) strings.voiceActiveBadge else strings.voiceStandbyBadge,
                        color = if (isLive) IndustrialColors.EmeraldSafe else IndustrialColors.CyanTelemetry,
                        fontSize = 8.sp,
                        fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Live Waveform Strip when active, otherwise guidance text
            if (isLive) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(34.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(IndustrialColors.DeepRecess)
                        .border(1.dp, IndustrialColors.EmeraldSafe.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 0 until 18) {
                        val barRatio = 0.25f + 0.75f * abs(sin(wavePhase + i * 0.55f))
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height((22f * barRatio).dp)
                                .clip(CircleShape)
                                .background(
                                    if (i % 2 == 0) IndustrialColors.EmeraldSafe else IndustrialColors.CyanTelemetry
                                )
                        )
                    }
                }
            } else {
                Text(
                    text = strings.voiceIdleHint,
                    color = IndustrialColors.TextSecondary,
                    fontSize = 11.sp,
                    fontFamily = activeFont
                )
            }

            // Live Transcription Readout
            AnimatedVisibility(
                visible = voiceState.userTranscript.isNotBlank() ||
                    voiceState.aiTranscript.isNotBlank() ||
                    voiceState.lastToolAction.isNotBlank()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(IndustrialColors.DeepRecess)
                        .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(6.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    if (voiceState.userTranscript.isNotBlank()) {
                        Text(
                            text = "${strings.voiceUserTranscriptLabel} ${voiceState.userTranscript}",
                            color = IndustrialColors.CyanTelemetry,
                            fontSize = 11.sp,
                            fontFamily = activeFont
                        )
                    }
                    if (voiceState.aiTranscript.isNotBlank()) {
                        Text(
                            text = "${strings.voiceAiTranscriptLabel} ${voiceState.aiTranscript}",
                            color = IndustrialColors.AmberGlow,
                            fontSize = 11.sp,
                            fontFamily = activeFont
                        )
                    }
                    if (voiceState.lastToolAction.isNotBlank()) {
                        Text(
                            text = "TOOL // ${voiceState.lastToolAction}",
                            color = IndustrialColors.EmeraldSafe,
                            fontSize = 10.sp,
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (permissionDeniedWarning) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF281616))
                        .border(1.dp, IndustrialColors.RubyError, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = strings.voiceMicDeniedMsg,
                        color = IndustrialColors.RubyError,
                        fontSize = 11.sp,
                        fontFamily = activeFont
                    )
                }
            }

            voiceState.errorMessage?.let { err ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF281616))
                        .border(1.dp, IndustrialColors.RubyError, RoundedCornerShape(6.dp))
                        .clickable(onClick = onDismissError)
                        .padding(8.dp)
                ) {
                    Text(
                        text = err,
                        color = IndustrialColors.RubyError,
                        fontSize = 11.sp,
                        fontFamily = activeFont
                    )
                }
            }

            // Primary Live Voice Trigger Button
            val btnBrush = if (isLive) {
                Brush.verticalGradient(listOf(Color(0xFFF87171), Color(0xFFB91C1C)))
            } else {
                Brush.verticalGradient(listOf(Color(0xFF38BDF8), Color(0xFF0284C7)))
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(btnBrush)
                    .border(
                        1.dp,
                        if (isLive) IndustrialColors.RubyError else IndustrialColors.CyanTelemetry,
                        RoundedCornerShape(7.dp)
                    )
                    .clickable(enabled = !isConnecting) {
                        if (isLive) {
                            onStopVoice()
                        } else {
                            val hasMic = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasMic) {
                                permissionDeniedWarning = false
                                onStartVoice()
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    }
                    .testTag("live_voice_toggle_button")
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                when {
                    isConnecting -> {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = IndustrialColors.DeepRecess,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.voiceConnectingBtn,
                            color = IndustrialColors.DeepRecess,
                            fontSize = 11.sp,
                            fontFamily = activeFont,
                            fontWeight = FontWeight.Black
                        )
                    }
                    isLive -> {
                        Icon(
                            imageVector = Icons.Filled.Stop,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = strings.voiceStopBtn,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontFamily = activeFont,
                            fontWeight = FontWeight.Black
                        )
                    }
                    else -> {
                        Icon(
                            imageVector = Icons.Filled.Mic,
                            contentDescription = null,
                            tint = IndustrialColors.DeepRecess,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = strings.voiceStartBtn,
                            color = IndustrialColors.DeepRecess,
                            fontSize = 11.sp,
                            fontFamily = activeFont,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }
    }
}
