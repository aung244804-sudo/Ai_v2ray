package com.example.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Brushed Machined Aluminum Chassis + Deep Obsidian OLED Instrument Palette
 * blended with Burnished Copper, Warm Amber, Emerald Signal, and Cyan Telemetry.
 */
object IndustrialColors {
    // Machined Brushed Aluminum Exterior
    val BrushedSteelBackground = Color(0xFFC8D1DA)
    val BrushedSteelLight = Color(0xFFDDE4EC)
    val BrushedSteelMid = Color(0xFFB9C4CF)
    val BrushedSteelDark = Color(0xFF8C97A4)
    val BevelHighlight = Color(0xFFF3F6FA)
    val BevelShadow = Color(0xFF6B7684)

    // Recessed Obsidian Instrument & OLED Panels
    val GunmetalChassis = Color(0xFF1A212B)
    val RecessedTrayBackground = Color(0xFF11171E)
    val DeepRecess = Color(0xFF0B1016)
    val TerminalScreenBg = Color(0xFF080D12)
    val MachinedBorder = Color(0xFF56616F)
    val MachinedHighlight = Color(0xFF94A0AE)
    val SteelKeyCap = Color(0xFFD8DFE7)
    val TabActiveSurface = Color(0xFFEAF0F5)

    // Burnished Copper, Gold & Warm Amber Accents
    val CopperFront = Color(0xFFE68422)
    val CopperSideBevel = Color(0xFFB35714)
    val CopperHighlightCap = Color(0xFFFFC15E)
    val AmberHalo = Color(0x66F59E0B)
    val AmberGlow = Color(0xFFFBBF24)

    // Telemetry Cyan & Status Signals
    val CyanTelemetry = Color(0xFF38BDF8)
    val CyanDeep = Color(0xFF0E7490)
    val LedOnline = Color(0xFF10B981)
    val LedHealing = Color(0xFFF59E0B)
    val LedOffline = Color(0xFFEF4444)
    val EmeraldSafe = Color(0xFF34D399)
    val RubyError = Color(0xFFF87171)

    // Text Hierarchy (Aluminum Light & Obsidian Dark surfaces)
    val TextOnAluminum = Color(0xFF1B232D)
    val TextMutedOnAluminum = Color(0xFF475464)
    val TextPrimary = Color(0xFFF3F6FA)
    val TextSecondary = Color(0xFFB8C2CE)
    val TextMuted = Color(0xFF7D8A99)

    // Incised Shadows
    val ShadowHighlight = Color(255, 255, 255, 180)
    val ShadowGroove = Color(12, 18, 26, 200)
}
