package com.example.vpn

import android.content.Context
import android.net.VpnService
import org.json.JSONObject
import java.lang.reflect.Proxy

/**
 * Reflection bridge to official XTLS/libXray AAR when bundled in app/libs/.
 */
class LibXrayRuntime(private val context: Context, private val vpn: VpnService?) {
    private var registeredController: Any? = null
    private var libClass: Class<*>? = null

    private fun resolveClass(): Class<*>? {
        libClass?.let { return it }
        val candidates = listOf(
            "libXray.LibXray",
            "org.xtls.libXray.LibXray",
            "com.xray.libXray.LibXray"
        )
        libClass = candidates.firstNotNullOfOrNull {
            runCatching { Class.forName(it) }.getOrNull()
        }
        return libClass
    }

    fun isAvailable(): Boolean = resolveClass() != null

    private fun cls(): Class<*> = resolveClass() ?: error("libXray AAR is not bundled in app/libs/")

    fun registerProtection(): Result<Unit> = runCatching {
        val v = vpn ?: error("VpnService instance required")
        val c = cls()
        val register = c.methods.firstOrNull {
            it.name == "registerDialerController" && it.parameterTypes.size == 1
        } ?: error("registerDialerController API not found")
        val iface = register.parameterTypes[0]
        val proxy = Proxy.newProxyInstance(iface.classLoader, arrayOf(iface)) { _, method, args ->
            if (method.name.lowercase() == "protectfd") {
                v.protect((args?.firstOrNull() as Number).toInt())
            } else {
                defaultValue(method.returnType)
            }
        }
        register.invoke(null, proxy)
        registeredController = proxy
    }

    fun setDns(server: String = "1.1.1.1:53"): Result<Unit> = runCatching {
        val c = cls()
        val controller = registeredController ?: error("Dialer controller must be registered before DNS")
        val m = c.methods.firstOrNull {
            it.name == "setDNS" && it.parameterTypes.size == 2
        } ?: error("setDNS API not found")
        m.invoke(null, controller, server)
    }

    fun resetDns() {
        runCatching { cls().methods.firstOrNull { it.name == "resetDNS" }?.invoke(null) }
    }

    fun invoke(request: JSONObject): JSONObject {
        val m = cls().methods.firstOrNull {
            it.name == "invoke" && it.parameterTypes.contentEquals(arrayOf(String::class.java))
        } ?: error("libXray.invoke API not found")
        val raw = m.invoke(null, request.toString()) as? String ?: error("Empty libXray response")
        return JSONObject(raw)
    }

    fun convertShareLink(link: String): String {
        val req = JSONObject().apply {
            put("apiVersion", 3)
            put("method", "convertShareLinksToXrayJson")
            put("payload", JSONObject().put("text", link))
        }
        val r = invoke(req)
        if (!r.optBoolean("success")) error(r.optString("error", "Invalid profile"))
        return r.optJSONObject("data")
            ?.optJSONArray("outbounds")
            ?.takeIf { it.length() > 0 }
            ?.toString()
            ?: error("No usable outbound returned by libXray")
    }

    fun startXray(xrayJson: String): Result<Unit> = runCatching {
        val r = invoke(
            JSONObject().apply {
                put("apiVersion", 3)
                put("method", "runXray")
                put("payload", JSONObject().put("xrayJson", xrayJson))
            }
        )
        if (!r.optBoolean("success")) error(r.optString("error", "Xray start failed"))
    }

    fun stopXray(): Result<Unit> = runCatching {
        val r = invoke(
            JSONObject().apply {
                put("apiVersion", 3)
                put("method", "stopXray")
                put("payload", JSONObject())
            }
        )
        if (!r.optBoolean("success")) error(r.optString("error", "Xray stop failed"))
    }

    fun version(): String = runCatching {
        invoke(
            JSONObject().apply {
                put("apiVersion", 3)
                put("method", "xrayVersion")
                put("payload", JSONObject())
            }
        ).optJSONObject("data")?.optString("version").orEmpty()
    }.getOrDefault("")

    private fun defaultValue(type: Class<*>): Any? = when (type) {
        Boolean::class.javaPrimitiveType -> false
        Int::class.javaPrimitiveType -> 0
        Long::class.javaPrimitiveType -> 0L
        Float::class.javaPrimitiveType -> 0f
        Double::class.javaPrimitiveType -> 0.0
        Short::class.javaPrimitiveType -> 0.toShort()
        Byte::class.javaPrimitiveType -> 0.toByte()
        Char::class.javaPrimitiveType -> '\u0000'
        else -> null
    }
}
