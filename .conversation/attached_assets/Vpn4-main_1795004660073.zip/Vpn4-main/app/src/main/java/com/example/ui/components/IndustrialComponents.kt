package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.TunnelState
import com.example.telemetry.AiLogEntry
import com.example.telemetry.AiLogLevel
import com.example.ui.UiStrings
import com.example.ui.theme.IndustrialColors
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.MyanmarFontFamily
import com.example.ui.theme.RobotoMonoFontFamily
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Beveled brushed-aluminum hardware housing with 4 machined Phillips corner screws.
 */
@Composable
fun MachinedAluminumPlate(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 12.dp,
    innerPadding: Dp = 10.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(cornerRadius))
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        IndustrialColors.BrushedSteelLight,
                        IndustrialColors.BrushedSteelBackground,
                        IndustrialColors.BrushedSteelMid
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(IndustrialColors.BevelHighlight, IndustrialColors.BevelShadow)
                ),
                shape = RoundedCornerShape(cornerRadius)
            )
            .padding(innerPadding)
    ) {
        content()
        ScrewHead(modifier = Modifier.align(Alignment.TopStart))
        ScrewHead(modifier = Modifier.align(Alignment.TopEnd))
        ScrewHead(modifier = Modifier.align(Alignment.BottomStart))
        ScrewHead(modifier = Modifier.align(Alignment.BottomEnd))
    }
}

@Composable
fun ScrewHead(modifier: Modifier = Modifier, size: Dp = 11.dp) {
    Canvas(modifier = modifier.size(size)) {
        val r = this.size.minDimension / 2f
        val c = Offset(this.size.width / 2f, this.size.height / 2f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFE7ECF2), Color(0xFF7B8592)),
                center = Offset(c.x - r * 0.25f, c.y - r * 0.25f),
                radius = r * 1.2f
            ),
            radius = r,
            center = c
        )
        drawCircle(
            color = Color(0xFF47515E),
            radius = r,
            center = c,
            style = Stroke(width = 1f)
        )
        val slot = r * 0.52f
        drawLine(
            color = Color(0xFF313944),
            start = Offset(c.x - slot, c.y - slot),
            end = Offset(c.x + slot, c.y + slot),
            strokeWidth = 1.6f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun IndustrialHeader(
    tunnelState: TunnelState,
    xrayCoreLabel: String,
    batteryPercent: Int,
    isCharging: Boolean,
    tiltXDeg: Int,
    tiltYDeg: Int,
    gyroAvailable: Boolean,
    language: AppLanguage,
    strings: UiStrings,
    onOpenDiag: () -> Unit
) {
    val ledColor by animateColorAsState(
        targetValue = when (tunnelState) {
            TunnelState.RUNNING -> IndustrialColors.LedOnline
            TunnelState.HEALING, TunnelState.STARTING -> IndustrialColors.LedHealing
            else -> IndustrialColors.LedOffline
        },
        label = "ledColor"
    )
    val isConnected = tunnelState == TunnelState.RUNNING || tunnelState == TunnelState.HEALING

    val transition = rememberInfiniteTransition(label = "headerEcg")
    val pulsePhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isConnected) 1800 else 3600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "headerEcgPhase"
    )

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Top Telemetry Micro-Bar matching screenshot
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CH-01 // AI-V2RAY",
                color = IndustrialColors.TextOnAluminum,
                fontSize = 10.sp,
                fontFamily = RobotoMonoFontFamily,
                fontWeight = FontWeight.Bold
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Secure Tunnel Status Pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(IndustrialColors.BrushedSteelLight.copy(alpha = 0.85f))
                        .border(1.dp, IndustrialColors.BevelShadow.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                        .semantics { contentDescription = strings.statusOnline },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(ledColor)
                    )
                    Text(
                        text = if (isConnected) "SECURE TUNNEL" else "STANDBY",
                        color = IndustrialColors.TextOnAluminum,
                        fontSize = 9.sp,
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Gyro Status Pill
                if (gyroAvailable) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(IndustrialColors.GunmetalChassis)
                            .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "3D GYRO ON",
                            color = IndustrialColors.CyanTelemetry,
                            fontSize = 8.sp,
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = if (batteryPercent >= 0) "BAT $batteryPercent%" else "BAT --%",
                    color = IndustrialColors.TextOnAluminum,
                    fontSize = 10.sp,
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold
                )
                if (isCharging) {
                    Icon(
                        imageVector = Icons.Filled.Bolt,
                        contentDescription = null,
                        tint = IndustrialColors.CopperFront,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }

        // Machined Aluminum Nameplate with 4 corner screws + ECG backdrop
        MachinedAluminumPlate(cornerRadius = 10.dp, innerPadding = 10.dp) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .drawBehind {
                        val midY = size.height * 0.56f
                        val pulseX = size.width * pulsePhase
                        val amp = if (isConnected) 16f else 8f
                        val path = Path().apply {
                            moveTo(0f, midY)
                            val pStart = (pulseX - 38f).coerceAtLeast(0f)
                            val pEnd = (pulseX + 38f).coerceAtMost(size.width)
                            lineTo(pStart, midY)
                            if (pEnd - pStart > 10f) {
                                val span = pEnd - pStart
                                lineTo(pStart + span * 0.25f, midY - amp * 0.45f)
                                lineTo(pStart + span * 0.45f, midY + amp * 0.65f)
                                lineTo(pStart + span * 0.65f, midY - amp)
                                lineTo(pStart + span * 0.85f, midY + amp * 0.35f)
                                lineTo(pEnd, midY)
                            }
                            lineTo(size.width, midY)
                        }
                        drawPath(
                            path = path,
                            color = if (isConnected) Color(0x66EF4444) else Color(0x380EA5E9),
                            style = Stroke(width = 2.2f, cap = StrokeCap.Round)
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = strings.appTitle,
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = InterFontFamily,
                        letterSpacing = 1.2.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = TextStyle(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    IndustrialColors.CopperHighlightCap,
                                    IndustrialColors.CopperFront,
                                    IndustrialColors.CopperSideBevel
                                )
                            ),
                            shadow = Shadow(
                                color = IndustrialColors.AmberHalo,
                                offset = Offset(0f, 2f),
                                blurRadius = 10f
                            )
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${strings.appSubtitle} • $xrayCoreLabel",
                        color = IndustrialColors.TextOnAluminum,
                        fontSize = 9.sp,
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // Sub-nameplate Credit + Live Gyro Tilt & Diag button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "DEVELOPED BY VICTOR GEEK",
                color = IndustrialColors.TextOnAluminum,
                fontSize = 10.sp,
                fontFamily = RobotoMonoFontFamily,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.6.sp,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFFD6CEBA))
                        .border(1.dp, Color(0xFF9C927A), RoundedCornerShape(4.dp))
                        .padding(horizontal = 7.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (gyroAvailable) "TILT X:${tiltXDeg}° Y:${tiltYDeg}°" else "AXIS LOCKED",
                        color = IndustrialColors.TextOnAluminum,
                        fontSize = 9.sp,
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .clip(RoundedCornerShape(6.dp))
                        .background(IndustrialColors.GunmetalChassis)
                        .border(1.dp, IndustrialColors.CopperFront, RoundedCornerShape(6.dp))
                        .clickable(onClick = onOpenDiag)
                        .testTag("diag_button")
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = strings.diagButton,
                        color = IndustrialColors.CopperHighlightCap,
                        fontSize = 9.sp,
                        fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun IndustrialNavTabs(
    selectedTab: Int,
    language: AppLanguage,
    strings: UiStrings,
    onSelectTab: (Int) -> Unit
) {
    val tabs = listOf(strings.tabTunnel, strings.tabSettings, strings.tabDeveloper)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(9.dp))
            .background(IndustrialColors.BrushedSteelMid.copy(alpha = 0.65f))
            .border(1.dp, IndustrialColors.BevelShadow.copy(alpha = 0.45f), RoundedCornerShape(9.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        tabs.forEachIndexed { index, title ->
            val isActive = selectedTab == index
            Box(
                modifier = Modifier
                    .weight(1f)
                    .defaultMinSize(minHeight = 48.dp)
                    .shadow(if (isActive) 3.dp else 0.dp, RoundedCornerShape(7.dp))
                    .clip(RoundedCornerShape(7.dp))
                    .background(
                        if (isActive) {
                            Brush.verticalGradient(
                                listOf(IndustrialColors.BevelHighlight, IndustrialColors.SteelKeyCap)
                            )
                        } else {
                            Brush.verticalGradient(
                                listOf(
                                    IndustrialColors.BrushedSteelLight.copy(alpha = 0.45f),
                                    IndustrialColors.BrushedSteelMid.copy(alpha = 0.55f)
                                )
                            )
                        }
                    )
                    .border(
                        1.dp,
                        if (isActive) IndustrialColors.BevelHighlight else IndustrialColors.BevelShadow.copy(alpha = 0.35f),
                        RoundedCornerShape(7.dp)
                    )
                    .clickable { onSelectTab(index) }
                    .testTag("nav_tab_$index")
                    .padding(vertical = 8.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    when (index) {
                        0 -> Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isActive) IndustrialColors.LedOnline else IndustrialColors.TextMutedOnAluminum
                                )
                        )

                        1 -> Icon(
                            imageVector = Icons.Filled.Settings,
                            contentDescription = null,
                            tint = if (isActive) IndustrialColors.TextOnAluminum else IndustrialColors.TextMutedOnAluminum,
                            modifier = Modifier.size(13.dp)
                        )

                        else -> Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = null,
                            tint = if (isActive) IndustrialColors.TextOnAluminum else IndustrialColors.TextMutedOnAluminum,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                    Text(
                        text = title,
                        fontSize = 11.sp,
                        fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.SemiBold,
                        color = if (isActive) IndustrialColors.TextOnAluminum else IndustrialColors.TextMutedOnAluminum,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun BrushedSteelKeyCap(
    modifier: Modifier = Modifier,
    isHighlighted: Boolean = false,
    darkSurface: Boolean = false,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    val bgBrush = when {
        isHighlighted && darkSurface -> Brush.verticalGradient(
            listOf(Color(0xFF3E2914), Color(0xFF25190D))
        )
        darkSurface -> Brush.verticalGradient(
            listOf(Color(0xFF252E3B), Color(0xFF181F29))
        )
        isHighlighted -> Brush.verticalGradient(
            listOf(IndustrialColors.CopperHighlightCap, IndustrialColors.CopperFront)
        )
        else -> Brush.verticalGradient(
            listOf(IndustrialColors.BevelHighlight, IndustrialColors.BrushedSteelMid)
        )
    }
    val borderColor = when {
        isHighlighted -> IndustrialColors.CopperFront
        darkSurface -> IndustrialColors.MachinedBorder
        else -> IndustrialColors.BevelShadow.copy(alpha = 0.65f)
    }
    Box(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .defaultMinSize(minHeight = 48.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(bgBrush)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
fun AnalogNeedleGauge(
    title: String,
    value: Float,
    maxValue: Float,
    unit: String,
    isConnected: Boolean,
    accentColor: Color = IndustrialColors.CopperFront,
    modifier: Modifier = Modifier
) {
    val targetAngle = if (isConnected && value >= 0f) {
        -135f + (value.coerceIn(0f, maxValue) / maxValue) * 270f
    } else {
        -135f
    }
    val animatedAngle by animateFloatAsState(
        targetValue = targetAngle,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "needleAngle"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(86.dp)
                .shadow(4.dp, CircleShape)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF1A222D), Color(0xFF0A0F14))
                    )
                )
                .border(3.dp, IndustrialColors.BevelShadow, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(78.dp)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = (size.minDimension / 2f) - 4f

                drawCircle(
                    color = accentColor.copy(alpha = 0.25f),
                    radius = radius - 1f,
                    center = center,
                    style = Stroke(width = 1.5f)
                )

                for (i in 0..18) {
                    val angleDeg = -135f + i * 15f
                    val rad = (angleDeg - 90f) * (PI / 180.0)
                    val inner = radius - if (i % 3 == 0) 7f else 4f
                    val p1 = Offset(
                        center.x + (inner * cos(rad)).toFloat(),
                        center.y + (inner * sin(rad)).toFloat()
                    )
                    val p2 = Offset(
                        center.x + (radius * cos(rad)).toFloat(),
                        center.y + (radius * sin(rad)).toFloat()
                    )
                    val progress = (value.coerceIn(0f, maxValue) / maxValue) * 18f
                    drawLine(
                        color = if (isConnected && value >= 0f && i <= progress) {
                            accentColor
                        } else {
                            Color(0xFF425060)
                        },
                        start = p1,
                        end = p2,
                        strokeWidth = if (i % 3 == 0) 2.2f else 1.2f
                    )
                }

                rotate(degrees = animatedAngle, pivot = center) {
                    drawLine(
                        color = accentColor,
                        start = center,
                        end = Offset(center.x, center.y - radius + 8f),
                        strokeWidth = 2.6f,
                        cap = StrokeCap.Round
                    )
                }

                drawCircle(
                    color = IndustrialColors.BevelHighlight,
                    radius = 3.5f,
                    center = center
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 18.dp)
            ) {
                Text(
                    text = if (isConnected && value >= 0f) {
                        if (unit == "MB/S") "%.1f".format(value) else "${value.toInt()}"
                    } else "---",
                    fontSize = 13.sp,
                    fontFamily = RobotoMonoFontFamily,
                    color = if (accentColor == IndustrialColors.CyanTelemetry) {
                        IndustrialColors.CyanTelemetry
                    } else {
                        IndustrialColors.AmberGlow
                    },
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
                Text(
                    text = unit,
                    fontSize = 7.sp,
                    fontFamily = RobotoMonoFontFamily,
                    color = IndustrialColors.TextSecondary,
                    maxLines = 1
                )
            }
        }

        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = title,
            fontSize = 9.sp,
            fontFamily = RobotoMonoFontFamily,
            color = IndustrialColors.TextOnAluminum,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

/**
 * Live AI Working Terminal Interface blended identically with Machined Aluminum Frame + 4 Corner Screws
 * + Deep Obsidian Terminal Screen at the bottom of the UI.
 */
@Composable
fun AiLiveTerminalPanel(
    logs: List<AiLogEntry>,
    isTunnelOnline: Boolean,
    language: AppLanguage,
    strings: UiStrings,
    onClearLogs: () -> Unit
) {
    val activeFont = if (language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily
    var isPaused by remember { mutableStateOf(false) }
    var filterMode by remember { mutableStateOf("ALL") }
    val listState = rememberLazyListState()

    val filteredLogs = remember(logs, filterMode) {
        when (filterMode) {
            "AI" -> logs.filter {
                it.tag.contains("AI", ignoreCase = true) ||
                    it.tag.contains("GEMINI", ignoreCase = true) ||
                    it.tag.contains("SELF-HEAL", ignoreCase = true)
            }
            "CORE" -> logs.filter {
                it.tag.contains("XRAY", ignoreCase = true) ||
                    it.tag.contains("PING", ignoreCase = true) ||
                    it.tag.contains("CONFIG", ignoreCase = true)
            }
            else -> logs
        }
    }

    LaunchedEffect(filteredLogs.size, isPaused) {
        if (!isPaused && filteredLogs.isNotEmpty()) {
            listState.animateScrollToItem(filteredLogs.lastIndex)
        }
    }

    val blinkTransition = rememberInfiniteTransition(label = "cursorBlink")
    val cursorAlpha by blinkTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 650, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cursorAlpha"
    )

    MachinedAluminumPlate(
        modifier = Modifier.testTag("ai_terminal_panel"),
        cornerRadius = 11.dp,
        innerPadding = 10.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(IndustrialColors.TerminalScreenBg)
                .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Terminal Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Terminal,
                        contentDescription = null,
                        tint = IndustrialColors.AmberGlow,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = strings.terminalTitle,
                        color = IndustrialColors.AmberGlow,
                        fontSize = 10.sp,
                        fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isTunnelOnline) Color(0xFF0E2920) else Color(0xFF281D0F))
                        .border(
                            1.dp,
                            if (isTunnelOnline) IndustrialColors.EmeraldSafe else IndustrialColors.CopperFront,
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${filteredLogs.size} EVT",
                        color = if (isTunnelOnline) IndustrialColors.EmeraldSafe else IndustrialColors.CopperHighlightCap,
                        fontSize = 8.sp,
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Filter + Pause/Clear Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("ALL", "AI", "CORE").forEach { mode ->
                    val selected = filterMode == mode
                    BrushedSteelKeyCap(
                        modifier = Modifier.testTag("terminal_filter_$mode"),
                        isHighlighted = selected,
                        darkSurface = true,
                        onClick = { filterMode = mode }
                    ) {
                        Text(
                            text = mode,
                            fontSize = 9.sp,
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = if (selected) IndustrialColors.AmberGlow else IndustrialColors.TextSecondary
                        )
                    }
                }
                BrushedSteelKeyCap(
                    modifier = Modifier.testTag("ai_terminal_pause_button"),
                    isHighlighted = isPaused,
                    darkSurface = true,
                    onClick = { isPaused = !isPaused }
                ) {
                    Text(
                        text = if (isPaused) strings.terminalResumeBtn else strings.terminalPauseBtn,
                        fontSize = 9.sp,
                        fontFamily = activeFont,
                        fontWeight = FontWeight.Bold,
                        color = if (isPaused) IndustrialColors.CyanTelemetry else IndustrialColors.TextSecondary
                    )
                }
                BrushedSteelKeyCap(
                    modifier = Modifier.testTag("ai_terminal_clear_button"),
                    darkSurface = true,
                    onClick = onClearLogs
                ) {
                    Text(
                        text = strings.terminalClearBtn,
                        fontSize = 9.sp,
                        fontFamily = activeFont,
                        fontWeight = FontWeight.Bold,
                        color = IndustrialColors.RubyError
                    )
                }
            }

            // Recessed Obsidian Terminal Log Stream
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(172.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF05080C))
                    .border(1.dp, Color(0xFF232D3A), RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                LazyColumn(
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(filteredLogs, key = { it.id }) { entry ->
                        val tagColor = when (entry.level) {
                            AiLogLevel.AI -> IndustrialColors.AmberGlow
                            AiLogLevel.SUCCESS -> IndustrialColors.EmeraldSafe
                            AiLogLevel.WARN -> IndustrialColors.CopperHighlightCap
                            AiLogLevel.ERROR -> IndustrialColors.RubyError
                            AiLogLevel.INFO -> IndustrialColors.CyanTelemetry
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = entry.timestamp,
                                color = IndustrialColors.TextMuted,
                                fontSize = 9.sp,
                                fontFamily = RobotoMonoFontFamily
                            )
                            Text(
                                text = "[${entry.tag}]",
                                color = tagColor,
                                fontSize = 9.sp,
                                fontFamily = RobotoMonoFontFamily,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = entry.message,
                                color = IndustrialColors.TextPrimary,
                                fontSize = 9.sp,
                                fontFamily = RobotoMonoFontFamily,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    item {
                        Text(
                            text = if (isPaused) "victor@aiv2ray:~$ [PAUSED]" else "victor@aiv2ray:~$ _",
                            color = IndustrialColors.EmeraldSafe.copy(alpha = if (isPaused) 0.7f else cursorAlpha),
                            fontSize = 9.sp,
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IndustrialFooter(
    language: AppLanguage,
    onToggleLang: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Dual-Segment English / မြန်မာ Switch matching screenshot bottom-left
        Row(
            modifier = Modifier
                .defaultMinSize(minHeight = 48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(IndustrialColors.GunmetalChassis)
                .border(1.dp, IndustrialColors.BevelShadow, RoundedCornerShape(8.dp))
                .clickable(onClick = onToggleLang)
                .testTag("language_toggle_button")
                .padding(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(
                        if (language == AppLanguage.EN) IndustrialColors.BevelHighlight else Color.Transparent
                    )
                    .padding(horizontal = 9.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "• English",
                    fontSize = 10.sp,
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = if (language == AppLanguage.EN) {
                        IndustrialColors.TextOnAluminum
                    } else {
                        IndustrialColors.TextSecondary
                    }
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(
                        if (language == AppLanguage.MM) IndustrialColors.BevelHighlight else Color.Transparent
                    )
                    .padding(horizontal = 9.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "မြန်မာ",
                    fontSize = 10.sp,
                    fontFamily = MyanmarFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = if (language == AppLanguage.MM) {
                        IndustrialColors.TextOnAluminum
                    } else {
                        IndustrialColors.TextSecondary
                    }
                )
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = "CHASSIS SERIAL: SS-V2R-99201",
                color = IndustrialColors.TextOnAluminum,
                fontSize = 9.sp,
                fontFamily = RobotoMonoFontFamily,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "HEAVY-DUTY INDUSTRIAL INTERFACE",
                color = IndustrialColors.TextMutedOnAluminum,
                fontSize = 8.sp,
                fontFamily = RobotoMonoFontFamily,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
