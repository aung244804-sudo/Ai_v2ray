package com.example.vpn

import android.net.TrafficStats
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Collects UID traffic stats (RX/TX bytes, live throughput Kbps)
 * and measures active node TCP latency periodically.
 */
class TelemetryCollector(
    private val uid: Int,
    private val probeHostProvider: () -> Pair<String, Int>?,
    private val onUpdate: (latencyMs: Long, rxBytes: Long, txBytes: Long, downKbps: Float, upKbps: Float) -> Unit
) {
    private var job: Job? = null

    fun start(scope: CoroutineScope) {
        if (job != null) return
        job = scope.launch(Dispatchers.IO) {
            val baseRx = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L)
            val baseTx = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L)
            var lastRx = baseRx
            var lastTx = baseTx
            var lastAt = SystemClock.elapsedRealtime()

            while (isActive) {
                val now = SystemClock.elapsedRealtime()
                val curRx = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L)
                val curTx = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L)
                val dtSec = ((now - lastAt).coerceAtLeast(1L)) / 1000.0f
                val downKbps = (((curRx - lastRx).coerceAtLeast(0L) * 8f) / 1000f) / dtSec
                val upKbps = (((curTx - lastTx).coerceAtLeast(0L) * 8f) / 1000f) / dtSec

                val target = probeHostProvider()
                val latency = if (target != null) probeTcpLatency(target.first, target.second) else -1L

                onUpdate(
                    latency,
                    (curRx - baseRx).coerceAtLeast(0L),
                    (curTx - baseTx).coerceAtLeast(0L),
                    downKbps,
                    upKbps
                )

                lastRx = curRx
                lastTx = curTx
                lastAt = now
                delay(1500)
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
    }

    private fun probeTcpLatency(host: String, port: Int): Long {
        var socket: Socket? = null
        return try {
            val start = SystemClock.elapsedRealtime()
            socket = Socket()
            socket.connect(InetSocketAddress(host, port), 2200)
            (SystemClock.elapsedRealtime() - start).coerceAtLeast(1L)
        } catch (_: Throwable) {
            -1L
        } finally {
            runCatching { socket?.close() }
        }
    }
}
