package com.example.vpn

import com.example.model.AiDecisionCompat
import com.example.model.TargetPlatform
import com.example.model.Telemetry
import com.example.model.VpnNode

/**
 * AI Tunnel Orchestrator combining Enterprise Nano rule-based fallback
 * with real-time latency scoring and autonomous self-healing failover.
 */
class AiTunnelOrchestrator {

    fun autoSelectBestNode(
        nodes: List<VpnNode>,
        targetPlatform: TargetPlatform = TargetPlatform.GENERAL
    ): VpnNode? {
        val candidates = nodes.filter { it.isHealthy && it.latencyMs > 0 }
            .ifEmpty { nodes.filter { it.failureCount < 3 } }
            .ifEmpty { nodes }
        if (candidates.isEmpty()) return null

        return candidates.maxByOrNull { node ->
            val baseLatency = if (node.latencyMs > 0) node.latencyMs else 999L
            val protocolWeight = when (node.protocol.lowercase()) {
                "vless" -> 1.30
                "hysteria2", "hy2" -> 1.25
                "trojan" -> 1.15
                "vmess" -> 1.05
                else -> 1.00
            }
            val regionBonus = when (targetPlatform) {
                TargetPlatform.PUBG, TargetPlatform.MLBB, TargetPlatform.HOK ->
                    if (node.region in listOf("Singapore", "Thailand", "Hong Kong")) 18.0 else 0.0
                TargetPlatform.TELEGRAM ->
                    if (node.region in listOf("Germany", "Singapore")) 16.0 else 0.0
                TargetPlatform.YOUTUBE, TargetPlatform.TIKTOK ->
                    if (node.region in listOf("Japan", "Singapore", "United States")) 14.0 else 0.0
                TargetPlatform.FACEBOOK, TargetPlatform.GENERAL ->
                    if (node.region in listOf("Singapore", "Japan", "Hong Kong")) 12.0 else 0.0
            }
            val reliabilityPenalty = node.failureCount * 35.0
            val speedScore = (10000.0 / baseLatency.coerceAtLeast(15L)) * protocolWeight +
                regionBonus - reliabilityPenalty
            node.score = speedScore
            speedScore
        }
    }

    fun checkAndSelfHeal(
        activeNode: VpnNode?,
        currentTelemetry: Telemetry,
        consecutiveFailures: Int,
        nodePool: List<VpnNode>,
        targetPlatform: TargetPlatform = TargetPlatform.GENERAL
    ): VpnNode? {
        if (activeNode == null || nodePool.size <= 1) return null
        val shouldHeal = consecutiveFailures >= 2 ||
            currentTelemetry.lossPercent >= 30.0 ||
            (currentTelemetry.latencyMs > 500L && consecutiveFailures >= 1) ||
            (currentTelemetry.latencyMs < 0 && consecutiveFailures >= 1)
        if (!shouldHeal) return null

        activeNode.failureCount++
        activeNode.isHealthy = false
        val backupPool = nodePool.filter { it.id != activeNode.id }
        return autoSelectBestNode(backupPool, targetPlatform)
    }

    /**
     * Local rule-based Nano fallback decision (from AI-V2Ray-Enterprise core-ai-nano).
     */
    fun evaluateLocalNanoFallback(telemetry: Telemetry): AiDecisionCompat {
        return when {
            telemetry.latencyMs in 1..100 ->
                AiDecisionCompat("KEEP", "Optimal sub-100ms latency (${telemetry.latencyMs} ms)")
            telemetry.latencyMs > 450 || telemetry.latencyMs < 0 ->
                AiDecisionCompat("FAILOVER", "High latency or timeout detected; failover advised")
            else ->
                AiDecisionCompat("MONITOR", "Moderate latency (${telemetry.latencyMs} ms); monitoring")
        }
    }
}
