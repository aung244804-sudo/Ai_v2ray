package com.example.data

import android.content.Context
import com.example.model.AppLanguage
import com.example.model.TargetPlatform
import com.example.model.VpnNode
import com.example.model.VpnSettings
import com.example.telemetry.AiLogLevel
import com.example.telemetry.LiveLogBus
import com.example.vpn.NodeParser
import com.example.vpn.NodeSpeedTester
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ConfigRepository(context: Context) {

    private val prefs = context.getSharedPreferences("ai_v2ray_enterprise_prefs", Context.MODE_PRIVATE)
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    fun getRawInput(): String = prefs.getString(KEY_RAW_INPUT, "") ?: ""

    fun saveRawInput(value: String) {
        prefs.edit().putString(KEY_RAW_INPUT, value.trim()).apply()
    }

    fun getActiveNodeId(): String = prefs.getString(KEY_ACTIVE_NODE_ID, "") ?: ""

    fun setActiveNodeId(nodeId: String) {
        prefs.edit().putString(KEY_ACTIVE_NODE_ID, nodeId).apply()
    }

    fun getActiveNode(): VpnNode? {
        val nodes = getNodes()
        val activeId = getActiveNodeId()
        return nodes.firstOrNull { it.id == activeId } ?: nodes.firstOrNull()
    }

    fun getNodes(): List<VpnNode> {
        val raw = prefs.getString(KEY_NODES, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { idx ->
                val o = arr.optJSONObject(idx) ?: return@mapNotNull null
                VpnNode(
                    id = o.optString("id"),
                    name = o.optString("name"),
                    protocol = o.optString("protocol"),
                    address = o.optString("address"),
                    port = o.optInt("port", 443),
                    rawLink = o.optString("rawLink"),
                    security = o.optString("security", "tls"),
                    network = o.optString("network", "tcp"),
                    sni = o.optString("sni", ""),
                    region = o.optString("region", "Global"),
                    flag = o.optString("flag", "🌐"),
                    latencyMs = o.optLong("latencyMs", -1L),
                    isHealthy = o.optBoolean("isHealthy", true),
                    score = o.optDouble("score", 0.0),
                    failureCount = o.optInt("failureCount", 0)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun saveNodes(nodes: List<VpnNode>) {
        val arr = JSONArray()
        nodes.forEach { n ->
            arr.put(
                JSONObject().apply {
                    put("id", n.id)
                    put("name", n.name)
                    put("protocol", n.protocol)
                    put("address", n.address)
                    put("port", n.port)
                    put("rawLink", n.rawLink)
                    put("security", n.security)
                    put("network", n.network)
                    put("sni", n.sni)
                    put("region", n.region)
                    put("flag", n.flag)
                    put("latencyMs", n.latencyMs)
                    put("isHealthy", n.isHealthy)
                    put("score", n.score)
                    put("failureCount", n.failureCount)
                }
            )
        }
        prefs.edit().putString(KEY_NODES, arr.toString()).apply()
    }

    fun removeNode(nodeId: String): List<VpnNode> {
        val updated = getNodes().filterNot { it.id == nodeId }
        saveNodes(updated)
        if (getActiveNodeId() == nodeId) {
            setActiveNodeId(updated.firstOrNull()?.id.orEmpty())
        }
        return updated
    }

    fun getSettings(): VpnSettings {
        return VpnSettings(
            dnsProviderName = prefs.getString(KEY_DNS_NAME, "Cloudflare DoH") ?: "Cloudflare DoH",
            dnsIp = prefs.getString(KEY_DNS_IP, "1.1.1.1") ?: "1.1.1.1",
            routingMode = prefs.getString(KEY_ROUTING_MODE, "Bypass Myanmar LAN & Direct")
                ?: "Bypass Myanmar LAN & Direct",
            mtu = prefs.getInt(KEY_MTU, 1280),
            ipv6LeakProtection = prefs.getBoolean(KEY_IPV6_GUARD, true),
            autoReconnectSelfHeal = prefs.getBoolean(KEY_SELF_HEAL, true)
        )
    }

    fun saveSettings(settings: VpnSettings) {
        prefs.edit()
            .putString(KEY_DNS_NAME, settings.dnsProviderName)
            .putString(KEY_DNS_IP, settings.dnsIp)
            .putString(KEY_ROUTING_MODE, settings.routingMode)
            .putInt(KEY_MTU, settings.mtu)
            .putBoolean(KEY_IPV6_GUARD, settings.ipv6LeakProtection)
            .putBoolean(KEY_SELF_HEAL, settings.autoReconnectSelfHeal)
            .apply()
    }

    fun getLanguage(): AppLanguage {
        val code = prefs.getString(KEY_LANG, AppLanguage.EN.code)
        return AppLanguage.entries.firstOrNull { it.code == code } ?: AppLanguage.EN
    }

    fun saveLanguage(lang: AppLanguage) {
        prefs.edit().putString(KEY_LANG, lang.code).apply()
    }

    fun getTargetPlatform(): TargetPlatform {
        val id = prefs.getString(KEY_TARGET_PLATFORM, TargetPlatform.GENERAL.id)
        return TargetPlatform.entries.firstOrNull { it.id == id } ?: TargetPlatform.GENERAL
    }

    fun saveTargetPlatform(platform: TargetPlatform) {
        prefs.edit().putString(KEY_TARGET_PLATFORM, platform.id).apply()
    }

    suspend fun importAndSync(rawInput: String): Result<List<VpnNode>> = withContext(Dispatchers.IO) {
        runCatching {
            val trimmed = rawInput.trim()
            require(trimmed.isNotBlank()) { "Input cannot be empty." }
            saveRawInput(trimmed)

            val payload = when {
                trimmed.startsWith("https://", ignoreCase = true) -> {
                    LiveLogBus.log("CONFIG-SYNC", "Fetching HTTPS subscription…", AiLogLevel.INFO)
                    fetchRemoteSubscription(trimmed)
                }
                trimmed.startsWith("http://", ignoreCase = true) -> {
                    LiveLogBus.log("CONFIG-SYNC", "Blocked insecure http:// URL", AiLogLevel.ERROR)
                    error("Insecure http:// subscription URLs are blocked by network security policy. Use https:// instead.")
                }
                else -> trimmed
            }

            val parsed = NodeParser.parseNodes(payload).ifEmpty {
                NodeParser.parseSingleLink(payload)?.let { listOf(it) } ?: emptyList()
            }
            require(parsed.isNotEmpty()) {
                "No valid VLESS, VMess, Trojan, Shadowsocks, or Hysteria2 links found."
            }

            LiveLogBus.log("PING-PROBE", "Probing TCP latency for ${parsed.size} imported node(s)…", AiLogLevel.INFO)
            val existing = getNodes()
            val merged = (parsed + existing).distinctBy { it.id }
            NodeSpeedTester.testAll(merged, timeoutMs = 1800)
            val sorted = merged.sortedWith(
                compareBy<VpnNode> { if (it.latencyMs in 1..Int.MAX_VALUE) it.latencyMs else Long.MAX_VALUE }
            )
            saveNodes(sorted)
            if (getActiveNodeId().isBlank() || sorted.none { it.id == getActiveNodeId() }) {
                setActiveNodeId(sorted.first().id)
            }
            val onlineCount = sorted.count { it.latencyMs > 0 }
            LiveLogBus.log("PING-PROBE", "Calibrated $onlineCount/${sorted.size} live node(s)", AiLogLevel.SUCCESS)
            sorted
        }
    }

    suspend fun refreshNodePings(): List<VpnNode> = withContext(Dispatchers.IO) {
        val current = getNodes()
        if (current.isEmpty()) return@withContext emptyList()
        LiveLogBus.log("PING-PROBE", "Running parallel TCP probe on ${current.size} node(s)…", AiLogLevel.INFO)
        NodeSpeedTester.testAll(current, timeoutMs = 1800)
        val sorted = current.sortedWith(
            compareBy<VpnNode> { if (it.latencyMs in 1..Int.MAX_VALUE) it.latencyMs else Long.MAX_VALUE }
        )
        saveNodes(sorted)
        val best = sorted.firstOrNull { it.latencyMs > 0 }
        LiveLogBus.log(
            "PING-PROBE",
            if (best != null) "Fastest node: ${best.name} (${best.latencyMs}ms)" else "No reachable nodes responded",
            if (best != null) AiLogLevel.SUCCESS else AiLogLevel.WARN
        )
        sorted
    }

    private fun fetchRemoteSubscription(subUrl: String): String {
        val req = Request.Builder()
            .url(subUrl)
            .header("User-Agent", "v2rayNG/1.9.15 (AI-V2Ray-Enterprise)")
            .header("Accept", "*/*")
            .build()
        return httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                error("Subscription request failed (HTTP ${resp.code}).")
            }
            resp.body?.string()?.takeIf { it.isNotBlank() }
                ?: error("Subscription URL returned an empty response.")
        }
    }

    companion object {
        private const val KEY_RAW_INPUT = "active_profile_input"
        private const val KEY_ACTIVE_NODE_ID = "active_vpn_node_id"
        private const val KEY_NODES = "cached_vpn_nodes"
        private const val KEY_SELF_HEAL = "ai_self_heal_enabled"
        private const val KEY_DNS_NAME = "dns_provider_name"
        private const val KEY_DNS_IP = "dns_provider_ip"
        private const val KEY_ROUTING_MODE = "routing_mode"
        private const val KEY_MTU = "vpn_mtu"
        private const val KEY_IPV6_GUARD = "ipv6_leak_guard"
        private const val KEY_LANG = "app_language"
        private const val KEY_TARGET_PLATFORM = "target_platform"
    }
}
