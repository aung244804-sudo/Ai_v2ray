package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ai.VoiceConsoleState
import com.example.model.AiAdvisorState
import com.example.model.AiRoutingAdvice
import com.example.model.AppLanguage
import com.example.model.TargetPlatform
import com.example.model.TunnelState
import com.example.model.VpnNode
import com.example.ui.MainUiState
import com.example.ui.UiStrings
import com.example.ui.components.AnalogNeedleGauge
import com.example.ui.components.BrushedSteelKeyCap
import com.example.ui.components.LiveVoiceConsolePanel
import com.example.ui.components.MachinedAluminumPlate
import com.example.ui.theme.IndustrialColors
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.MyanmarFontFamily
import com.example.ui.theme.RobotoMonoFontFamily

@Composable
fun TunnelDashboardScreen(
    state: MainUiState,
    voiceState: VoiceConsoleState,
    strings: UiStrings,
    onSelectTarget: (TargetPlatform) -> Unit,
    onAskGemini: (String) -> Unit,
    onApplyAiAdvice: (AiRoutingAdvice) -> Unit,
    onToggleTunnel: () -> Unit,
    onOpenImport: () -> Unit,
    onPingAll: () -> Unit,
    onAiPickBest: () -> Unit,
    onSelectProtocolFilter: (String) -> Unit,
    onToggleUnder100Ms: () -> Unit,
    onSelectNode: (VpnNode) -> Unit,
    onCopyNodeLink: (VpnNode) -> Unit,
    onShowNodeQr: (VpnNode) -> Unit,
    onRemoveNode: (VpnNode) -> Unit,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    onDismissVoiceError: () -> Unit
) {
    var purposeInput by rememberSaveable { mutableStateOf("") }
    var showServerMatrix by rememberSaveable { mutableStateOf(state.nodes.isEmpty()) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // MAIN CHASSIS // Dual Analog Gauges + Center Lightning Power Dial + RX/TX OLED Strips
        MainChassisGaugeCluster(
            state = state,
            strings = strings,
            onToggleTunnel = onToggleTunnel
        )

        // ACTIVE NODE BAR (Matches Screenshot Dark Recessed Plate + SWITCH Button)
        ActiveNodeHardwareBar(
            state = state,
            strings = strings,
            isMatrixExpanded = showServerMatrix,
            onToggleMatrix = { showServerMatrix = !showServerMatrix },
            onOpenImport = onOpenImport
        )

        // EXPANDABLE SERVER MATRIX (Always visible when empty or when user toggles SWITCH)
        AnimatedVisibility(visible = showServerMatrix || state.nodes.isEmpty()) {
            ServerMatrixPanel(
                state = state,
                strings = strings,
                onOpenImport = onOpenImport,
                onPingAll = onPingAll,
                onAiPickBest = onAiPickBest,
                onSelectProtocolFilter = onSelectProtocolFilter,
                onToggleUnder100Ms = onToggleUnder100Ms,
                onSelectNode = onSelectNode,
                onCopyNodeLink = onCopyNodeLink,
                onShowNodeQr = onShowNodeQr,
                onRemoveNode = onRemoveNode
            )
        }

        // AI • ASK GEMINI TUNNEL ROUTE PANEL (Beveled Aluminum Frame + Obsidian Neural Panel)
        AskGeminiPanel(
            purposeInput = purposeInput,
            selectedTarget = state.selectedTarget,
            language = state.language,
            strings = strings,
            advisorState = state.aiAdvisorState,
            onPurposeChange = { purposeInput = it },
            onSelectTarget = onSelectTarget,
            onAskGemini = { onAskGemini(purposeInput) },
            onApplyAdvice = onApplyAiAdvice
        )

        // GEMINI 3.8 LIVE BIDIRECTIONAL VOICE CONSOLE
        LiveVoiceConsolePanel(
            voiceState = voiceState,
            language = state.language,
            strings = strings,
            onStartVoice = onStartVoice,
            onStopVoice = onStopVoice,
            onDismissError = onDismissVoiceError
        )
    }
}

@Composable
private fun MainChassisGaugeCluster(
    state: MainUiState,
    strings: UiStrings,
    onToggleTunnel: () -> Unit
) {
    val isConnected = state.tunnelState == TunnelState.RUNNING || state.tunnelState == TunnelState.HEALING
    val isBusy = state.tunnelState == TunnelState.STARTING || state.tunnelState == TunnelState.STOPPING

    val statusColor by animateColorAsState(
        targetValue = when (state.tunnelState) {
            TunnelState.RUNNING -> IndustrialColors.LedOnline
            TunnelState.HEALING -> IndustrialColors.LedHealing
            TunnelState.STARTING -> IndustrialColors.AmberGlow
            else -> IndustrialColors.RubyError
        },
        label = "chassisStatusColor"
    )

    val speedMBs = ((state.telemetry.downloadKbps + state.telemetry.uploadKbps) / 8000f).coerceAtLeast(0f)
    val displayPing = if (isConnected && state.telemetry.latencyMs > 0) {
        state.telemetry.latencyMs.toFloat()
    } else {
        (state.activeNode?.latencyMs ?: -1L).toFloat()
    }

    MachinedAluminumPlate(cornerRadius = 12.dp, innerPadding = 12.dp) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp, bottom = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                AnalogNeedleGauge(
                    title = strings.pingGaugeLabel,
                    value = displayPing,
                    maxValue = 300f,
                    unit = "MS PING",
                    isConnected = isConnected || displayPing > 0f,
                    accentColor = IndustrialColors.CopperFront
                )

                // Center Machined Ring Power Switch with Lightning Icon
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(106.dp)
                            .shadow(6.dp, CircleShape)
                            .clip(CircleShape)
                            .background(
                                Brush.verticalGradient(
                                    listOf(IndustrialColors.BevelHighlight, IndustrialColors.BrushedSteelMid)
                                )
                            )
                            .border(2.dp, IndustrialColors.BevelShadow.copy(alpha = 0.7f), CircleShape)
                            .clickable(enabled = !isBusy, onClick = onToggleTunnel)
                            .testTag("power_toggle_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(58.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            colors = if (isConnected) {
                                                listOf(Color(0xFF422A12), IndustrialColors.DeepRecess)
                                            } else {
                                                listOf(Color(0xFF222A35), IndustrialColors.DeepRecess)
                                            }
                                        )
                                    )
                                    .border(
                                        2.dp,
                                        if (isConnected) IndustrialColors.AmberGlow else IndustrialColors.MachinedBorder,
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Bolt,
                                    contentDescription = stringResource(id = R.string.cd_power_button),
                                    tint = if (isConnected) IndustrialColors.AmberGlow else IndustrialColors.TextSecondary,
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = when {
                                    isBusy -> strings.connectingBtn
                                    isConnected -> strings.statusOnline
                                    else -> strings.connectBtn
                                },
                                fontSize = 9.sp,
                                fontFamily = if (state.language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                                fontWeight = FontWeight.Black,
                                color = statusColor,
                                maxLines = 1
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "MAIN CHASSIS • ${formatSessionTime(state.telemetry.sessionSeconds)}",
                        fontSize = 9.sp,
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = IndustrialColors.TextOnAluminum
                    )
                }

                AnalogNeedleGauge(
                    title = strings.speedGaugeLabel,
                    value = if (isConnected) speedMBs else 0f,
                    maxValue = 50f,
                    unit = "MB/S",
                    isConnected = isConnected,
                    accentColor = IndustrialColors.CyanTelemetry
                )
            }

            // Dual Recessed Obsidian OLED Strips (RX RECVD amber / TX SENT cyan)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OledReadoutStrip(
                    label = strings.rxRecvdLabel,
                    value = formatBytes(state.telemetry.rxBytes),
                    valueColor = IndustrialColors.AmberGlow,
                    modifier = Modifier.weight(1f)
                )
                OledReadoutStrip(
                    label = strings.txSentLabel,
                    value = formatBytes(state.telemetry.txBytes),
                    valueColor = IndustrialColors.CyanTelemetry,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun OledReadoutStrip(
    label: String,
    value: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF0A0E13), Color(0xFF141B24))
                )
            )
            .border(1.dp, IndustrialColors.BevelShadow, RoundedCornerShape(6.dp))
            .padding(horizontal = 10.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = IndustrialColors.TextSecondary,
            fontSize = 8.sp,
            fontFamily = RobotoMonoFontFamily,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
        Text(
            text = value,
            color = valueColor,
            fontSize = 12.sp,
            fontFamily = RobotoMonoFontFamily,
            fontWeight = FontWeight.Black,
            maxLines = 1
        )
    }
}

@Composable
private fun ActiveNodeHardwareBar(
    state: MainUiState,
    strings: UiStrings,
    isMatrixExpanded: Boolean,
    onToggleMatrix: () -> Unit,
    onOpenImport: () -> Unit
) {
    val active = state.activeNode
    val activeFont = if (state.language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(10.dp))
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.verticalGradient(
                    listOf(IndustrialColors.GunmetalChassis, IndustrialColors.DeepRecess)
                )
            )
            .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = active?.flag ?: "🌐",
                fontSize = 20.sp
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = active?.name ?: strings.emptyNodesTitle,
                    color = IndustrialColors.CopperHighlightCap,
                    fontSize = 13.sp,
                    fontFamily = activeFont,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (active != null) {
                        val pingText = if (active.latencyMs > 0) "${active.latencyMs}ms" else "--"
                        "• ${active.protocol.uppercase()} | PORT: ${active.port} | PING: $pingText"
                    } else {
                        state.statusMessage
                    },
                    color = IndustrialColors.EmeraldSafe,
                    fontSize = 9.sp,
                    fontFamily = RobotoMonoFontFamily,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        BrushedSteelKeyCap(
            modifier = Modifier.testTag("toggle_matrix_button"),
            isHighlighted = isMatrixExpanded,
            onClick = if (state.nodes.isEmpty()) onOpenImport else onToggleMatrix
        ) {
            Text(
                text = if (state.nodes.isEmpty()) strings.importConfigBtn else strings.switchNodeBtn,
                fontSize = 10.sp,
                fontFamily = activeFont,
                color = IndustrialColors.TextOnAluminum,
                fontWeight = FontWeight.Black
            )
        }
    }
}

@Composable
private fun AskGeminiPanel(
    purposeInput: String,
    selectedTarget: TargetPlatform,
    language: AppLanguage,
    strings: UiStrings,
    advisorState: AiAdvisorState,
    onPurposeChange: (String) -> Unit,
    onSelectTarget: (TargetPlatform) -> Unit,
    onAskGemini: () -> Unit,
    onApplyAdvice: (AiRoutingAdvice) -> Unit
) {
    val activeFont = if (language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily

    MachinedAluminumPlate(cornerRadius = 11.dp, innerPadding = 10.dp) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(IndustrialColors.RecessedTrayBackground)
                .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.askGeminiPanelTitle,
                    color = IndustrialColors.AmberGlow,
                    fontSize = 10.sp,
                    fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF281D0F))
                        .border(1.dp, IndustrialColors.CopperFront, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "NEURAL v2",
                        color = IndustrialColors.AmberGlow,
                        fontSize = 8.sp,
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(IndustrialColors.DeepRecess)
                    .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                BasicTextField(
                    value = purposeInput,
                    onValueChange = onPurposeChange,
                    singleLine = true,
                    cursorBrush = SolidColor(IndustrialColors.AmberGlow),
                    textStyle = TextStyle(
                        color = IndustrialColors.AmberGlow,
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 12.sp
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gemini_purpose_input")
                )
                if (purposeInput.isEmpty()) {
                    Text(
                        text = strings.targetPlaceholder,
                        color = IndustrialColors.AmberGlow.copy(alpha = 0.68f),
                        fontSize = 11.sp,
                        fontFamily = activeFont,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TargetPlatform.entries.forEach { target ->
                    val isSelected = target == selectedTarget
                    BrushedSteelKeyCap(
                        modifier = Modifier.testTag("target_chip_${target.id}"),
                        isHighlighted = isSelected,
                        darkSurface = true,
                        onClick = { onSelectTarget(target) }
                    ) {
                        Text(
                            text = if (language == AppLanguage.MM) target.labelMm else target.labelEn,
                            fontSize = 10.sp,
                            fontFamily = activeFont,
                            color = if (isSelected) IndustrialColors.AmberGlow else IndustrialColors.TextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            val isLoading = advisorState is AiAdvisorState.Loading
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(IndustrialColors.CopperHighlightCap, IndustrialColors.CopperFront, IndustrialColors.CopperSideBevel)
                        )
                    )
                    .border(1.dp, IndustrialColors.CopperHighlightCap, RoundedCornerShape(7.dp))
                    .clickable(enabled = !isLoading, onClick = onAskGemini)
                    .testTag("ask_gemini_button")
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = IndustrialColors.DeepRecess,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = strings.askingGeminiBtn,
                        color = IndustrialColors.DeepRecess,
                        fontSize = 11.sp,
                        fontFamily = activeFont,
                        fontWeight = FontWeight.Black
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.Bolt,
                        contentDescription = null,
                        tint = IndustrialColors.DeepRecess,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = strings.askGeminiBtn,
                        color = IndustrialColors.DeepRecess,
                        fontSize = 11.sp,
                        fontFamily = activeFont,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            AnimatedVisibility(visible = advisorState is AiAdvisorState.Success || advisorState is AiAdvisorState.Error) {
                Column(modifier = Modifier.padding(top = 4.dp)) {
                    when (advisorState) {
                        is AiAdvisorState.Success -> {
                            val adv = advisorState.advice
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(IndustrialColors.DeepRecess)
                                    .border(1.dp, IndustrialColors.CopperFront.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "GEMINI AI // ${adv.recommendedProtocol}",
                                        color = IndustrialColors.AmberGlow,
                                        fontSize = 10.sp,
                                        fontFamily = RobotoMonoFontFamily,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${adv.confidence}% CONF",
                                        color = IndustrialColors.EmeraldSafe,
                                        fontSize = 10.sp,
                                        fontFamily = RobotoMonoFontFamily,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = adv.summary,
                                    color = IndustrialColors.TextPrimary,
                                    fontSize = 12.sp,
                                    fontFamily = activeFont
                                )
                                Text(
                                    text = "DNS: ${adv.recommendedDns} • MTU: ${adv.recommendedMtu} • ${adv.routingTip}",
                                    color = IndustrialColors.CyanTelemetry,
                                    fontSize = 10.sp,
                                    fontFamily = activeFont
                                )
                                BrushedSteelKeyCap(
                                    modifier = Modifier.testTag("apply_ai_advice_button"),
                                    isHighlighted = true,
                                    darkSurface = true,
                                    onClick = { onApplyAdvice(adv) }
                                ) {
                                    Text(
                                        text = strings.applyAiTuningBtn,
                                        fontSize = 10.sp,
                                        fontFamily = activeFont,
                                        color = IndustrialColors.AmberGlow,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        is AiAdvisorState.Error -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF281616))
                                    .border(1.dp, IndustrialColors.RubyError, RoundedCornerShape(6.dp))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = advisorState.message,
                                    color = IndustrialColors.RubyError,
                                    fontSize = 11.sp,
                                    fontFamily = activeFont
                                )
                            }
                        }

                        else -> Unit
                    }
                }
            }
        }
    }
}

@Composable
private fun ServerMatrixPanel(
    state: MainUiState,
    strings: UiStrings,
    onOpenImport: () -> Unit,
    onPingAll: () -> Unit,
    onAiPickBest: () -> Unit,
    onSelectProtocolFilter: (String) -> Unit,
    onToggleUnder100Ms: () -> Unit,
    onSelectNode: (VpnNode) -> Unit,
    onCopyNodeLink: (VpnNode) -> Unit,
    onShowNodeQr: (VpnNode) -> Unit,
    onRemoveNode: (VpnNode) -> Unit
) {
    val activeFont = if (state.language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily

    MachinedAluminumPlate(cornerRadius = 11.dp, innerPadding = 10.dp) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(IndustrialColors.RecessedTrayBackground)
                .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${strings.serverMatrixTitle} (${state.filteredNodes.size})",
                    fontSize = 10.sp,
                    fontFamily = if (state.language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                    color = IndustrialColors.AmberGlow,
                    fontWeight = FontWeight.Bold
                )
                if (state.isTestingPings) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = IndustrialColors.CyanTelemetry,
                        strokeWidth = 2.dp
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BrushedSteelKeyCap(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("open_import_button"),
                    isHighlighted = true,
                    darkSurface = true,
                    onClick = onOpenImport
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = null,
                            tint = IndustrialColors.AmberGlow,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = strings.importConfigBtn,
                            fontSize = 10.sp,
                            fontFamily = activeFont,
                            color = IndustrialColors.AmberGlow,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                BrushedSteelKeyCap(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ping_all_button"),
                    darkSurface = true,
                    onClick = onPingAll
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Speed,
                            contentDescription = null,
                            tint = IndustrialColors.CyanTelemetry,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = strings.pingAllBtn,
                            fontSize = 10.sp,
                            fontFamily = activeFont,
                            color = IndustrialColors.CyanTelemetry,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                BrushedSteelKeyCap(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_pick_button"),
                    darkSurface = true,
                    onClick = onAiPickBest
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = IndustrialColors.EmeraldSafe,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = strings.aiBestPickBtn,
                            fontSize = 10.sp,
                            fontFamily = activeFont,
                            color = IndustrialColors.EmeraldSafe,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BrushedSteelKeyCap(
                    modifier = Modifier.testTag("filter_under_100ms"),
                    isHighlighted = state.under100MsOnly,
                    darkSurface = true,
                    onClick = onToggleUnder100Ms
                ) {
                    Text(
                        text = strings.under100Chip,
                        fontSize = 10.sp,
                        fontFamily = activeFont,
                        color = if (state.under100MsOnly) IndustrialColors.EmeraldSafe else IndustrialColors.TextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                }
                listOf("ALL", "VLESS", "VMESS", "TROJAN", "HYSTERIA2", "SHADOWSOCKS").forEach { proto ->
                    val selected = state.protocolFilter == proto
                    BrushedSteelKeyCap(
                        modifier = Modifier.testTag("filter_proto_$proto"),
                        isHighlighted = selected,
                        darkSurface = true,
                        onClick = { onSelectProtocolFilter(proto) }
                    ) {
                        Text(
                            text = proto,
                            fontSize = 10.sp,
                            fontFamily = RobotoMonoFontFamily,
                            color = if (selected) IndustrialColors.AmberGlow else IndustrialColors.TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (state.filteredNodes.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(IndustrialColors.DeepRecess)
                        .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(6.dp))
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = strings.emptyNodesTitle,
                        color = IndustrialColors.AmberGlow,
                        fontSize = 12.sp,
                        fontFamily = activeFont,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = strings.emptyNodesDesc,
                        color = IndustrialColors.TextSecondary,
                        fontSize = 11.sp,
                        fontFamily = activeFont
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.filteredNodes.forEach { node ->
                        NodeCardRow(
                            node = node,
                            isActive = node.id == state.activeNode?.id,
                            language = state.language,
                            strings = strings,
                            onSelect = { onSelectNode(node) },
                            onCopy = { onCopyNodeLink(node) },
                            onQr = { onShowNodeQr(node) },
                            onRemove = { onRemoveNode(node) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NodeCardRow(
    node: VpnNode,
    isActive: Boolean,
    language: AppLanguage,
    strings: UiStrings,
    onSelect: () -> Unit,
    onCopy: () -> Unit,
    onQr: () -> Unit,
    onRemove: () -> Unit
) {
    val activeFont = if (language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily
    val pingColor = when {
        node.latencyMs in 1..100 -> IndustrialColors.EmeraldSafe
        node.latencyMs in 101..250 -> IndustrialColors.AmberGlow
        node.latencyMs > 250 -> IndustrialColors.CopperFront
        else -> IndustrialColors.TextMuted
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(if (isActive) Color(0xFF1F1A12) else IndustrialColors.DeepRecess)
            .border(
                1.dp,
                if (isActive) IndustrialColors.CopperFront else IndustrialColors.MachinedBorder,
                RoundedCornerShape(6.dp)
            )
            .clickable(onClick = onSelect)
            .testTag("node_card_${node.id}")
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = node.flag, fontSize = 14.sp)
                    Text(
                        text = node.name,
                        fontSize = 13.sp,
                        fontFamily = activeFont,
                        fontWeight = FontWeight.Bold,
                        color = IndustrialColors.TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${node.protocol.uppercase()} • ${node.address}:${node.port} • ${node.security.uppercase()}",
                    fontSize = 10.sp,
                    fontFamily = RobotoMonoFontFamily,
                    color = IndustrialColors.TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = if (node.latencyMs > 0) "${node.latencyMs} ms" else "TIMEOUT",
                    fontSize = 12.sp,
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = pingColor
                )
                if (isActive) {
                    Text(
                        text = strings.activeBadge,
                        fontSize = 9.sp,
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = IndustrialColors.AmberGlow
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onCopy,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("copy_node_${node.id}")
            ) {
                Icon(
                    imageVector = Icons.Filled.ContentCopy,
                    contentDescription = strings.copyKey,
                    tint = IndustrialColors.TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
            IconButton(
                onClick = onQr,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("qr_node_${node.id}")
            ) {
                Icon(
                    imageVector = Icons.Filled.QrCode2,
                    contentDescription = strings.qrBtn,
                    tint = IndustrialColors.CyanTelemetry,
                    modifier = Modifier.size(18.dp)
                )
            }
            IconButton(
                onClick = onRemove,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("delete_node_${node.id}")
            ) {
                Icon(
                    imageVector = Icons.Filled.DeleteOutline,
                    contentDescription = "Remove node",
                    tint = IndustrialColors.RubyError,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

private fun formatSessionTime(seconds: Long): String {
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return "%02d:%02d:%02d".format(hrs, mins, secs)
}

private fun formatBytes(bytes: Long): String {
    return when {
        bytes < 1024L -> "${bytes} B"
        bytes < 1024L * 1024L -> "${bytes / 1024L} KB"
        else -> "%.2f MB".format(bytes / (1024f * 1024f))
    }
}
