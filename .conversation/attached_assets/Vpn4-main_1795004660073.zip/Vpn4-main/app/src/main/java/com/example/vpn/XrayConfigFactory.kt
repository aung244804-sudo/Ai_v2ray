package com.example.vpn

import org.json.JSONArray
import org.json.JSONObject

object XrayConfigFactory {
    fun build(
        outboundJson: String,
        tunFd: Int,
        physicalInterfaceName: String,
        dnsServer: String = "1.1.1.1",
        mtu: Int = 1280
    ): String {
        require(physicalInterfaceName.isNotBlank()) {
            "No underlying network interface detected before creating the VPN."
        }
        val outbounds = JSONArray(outboundJson)
        for (i in 0 until outbounds.length()) {
            val o = outbounds.getJSONObject(i)
            val stream = o.optJSONObject("streamSettings")
                ?: JSONObject().also { o.put("streamSettings", it) }
            val sockopt = stream.optJSONObject("sockopt")
                ?: JSONObject().also { stream.put("sockopt", it) }
            sockopt.put("interface", physicalInterfaceName)
        }
        val root = JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put(
                "inbounds",
                JSONArray().put(
                    JSONObject()
                        .put("tag", "tun-in")
                        .put("protocol", "tun")
                        .put(
                            "settings",
                            JSONObject()
                                .put("name", "aiv2ray0")
                                .put("mtu", mtu)
                                .put("gateway", JSONArray().put("10.8.0.1/30"))
                                .put("dns", JSONArray().put(dnsServer).put("8.8.8.8"))
                                .put("autoOutboundsInterface", physicalInterfaceName)
                        )
                )
            )
            .put("outbounds", outbounds)
            .put("routing", JSONObject().put("domainStrategy", "AsIs"))
            .put("dns", JSONObject().put("servers", JSONArray().put(dnsServer).put("8.8.8.8")))
            .put("env", JSONObject().put("xray.tun.fd", tunFd.toString()))
        return root.toString()
    }
}
