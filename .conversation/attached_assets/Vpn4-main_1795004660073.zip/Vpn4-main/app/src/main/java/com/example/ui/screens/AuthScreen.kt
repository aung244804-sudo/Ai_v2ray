package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.auth.attemptAutoSignIn
import com.example.auth.onGoogleSignInClicked
import com.example.model.AppLanguage
import com.example.ui.StringsCatalog
import com.example.ui.components.IndustrialFooter
import com.example.ui.components.MachinedAluminumPlate
import com.example.ui.theme.IndustrialColors
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.MyanmarFontFamily
import com.example.ui.theme.RobotoMonoFontFamily

@Composable
fun AuthScreen(
    onAuthSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var language by rememberSaveable { mutableStateOf(AppLanguage.EN) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val strings = StringsCatalog.get(language)
    val activeFont = if (language == AppLanguage.MM) MyanmarFontFamily else InterFontFamily

    LaunchedEffect(Unit) {
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = {
                isLoading = false
                onAuthSuccess()
            },
            onUnauthenticated = {
                isLoading = false
            },
            scope = scope
        )
    }

    Scaffold(
        containerColor = IndustrialColors.BrushedSteelBackground,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            IndustrialColors.BrushedSteelMid,
                            IndustrialColors.BrushedSteelLight,
                            IndustrialColors.BrushedSteelBackground,
                            IndustrialColors.BrushedSteelMid
                        )
                    )
                )
                .drawBehind {
                    val grooveSpacing = 3.dp.toPx()
                    var x = 0f
                    var idx = 0
                    while (x < size.width) {
                        val tint = if (idx % 2 == 0) {
                            Color.White.copy(alpha = 0.08f)
                        } else {
                            Color.Black.copy(alpha = 0.035f)
                        }
                        drawLine(
                            color = tint,
                            start = Offset(x, 0f),
                            end = Offset(x, size.height),
                            strokeWidth = 1.2f
                        )
                        x += grooveSpacing
                        idx++
                    }
                }
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 540.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Machined Aluminum Header Plate
                MachinedAluminumPlate(cornerRadius = 12.dp, innerPadding = 14.dp) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(IndustrialColors.AmberGlow)
                            )
                            Text(
                                text = "ZERO-TRUST CLOUD CHASSIS",
                                color = IndustrialColors.TextOnAluminum,
                                fontSize = 10.sp,
                                fontFamily = RobotoMonoFontFamily,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = strings.appTitle,
                            fontSize = 23.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = InterFontFamily,
                            letterSpacing = 1.2.sp,
                            style = TextStyle(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        IndustrialColors.CopperHighlightCap,
                                        IndustrialColors.CopperFront,
                                        IndustrialColors.CopperSideBevel
                                    )
                                )
                            )
                        )
                        Text(
                            text = "FIRESTORE SYNC • GEMINI 3.8 LIVE VOICE",
                            color = IndustrialColors.TextMutedOnAluminum,
                            fontSize = 9.sp,
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp
                        )
                    }
                }

                // Obsidian Operator Access Console
                MachinedAluminumPlate(cornerRadius = 12.dp, innerPadding = 10.dp) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(IndustrialColors.RecessedTrayBackground)
                            .border(1.dp, IndustrialColors.MachinedBorder, RoundedCornerShape(8.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = null,
                                tint = IndustrialColors.AmberGlow,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = strings.authGateTitle,
                                color = IndustrialColors.AmberGlow,
                                fontSize = 12.sp,
                                fontFamily = if (language == AppLanguage.MM) MyanmarFontFamily else RobotoMonoFontFamily,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = strings.authGateSubtitle,
                            color = IndustrialColors.TextSecondary,
                            fontSize = 12.sp,
                            fontFamily = activeFont
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            AuthFeatureRow(
                                icon = Icons.Filled.CloudSync,
                                tint = IndustrialColors.CyanTelemetry,
                                text = strings.authFeatureCloudSync,
                                fontFamily = activeFont
                            )
                            AuthFeatureRow(
                                icon = Icons.Filled.GraphicEq,
                                tint = IndustrialColors.AmberGlow,
                                text = strings.authFeatureLiveVoice,
                                fontFamily = activeFont
                            )
                            AuthFeatureRow(
                                icon = Icons.Filled.VerifiedUser,
                                tint = IndustrialColors.EmeraldSafe,
                                text = strings.authFeatureZeroTrust,
                                fontFamily = activeFont
                            )
                        }

                        errorMessage?.let { msg ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF281616))
                                    .border(1.dp, IndustrialColors.RubyError, RoundedCornerShape(6.dp))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = msg,
                                    color = IndustrialColors.RubyError,
                                    fontSize = 11.sp,
                                    fontFamily = activeFont
                                )
                            }
                        }

                        // Primary Copper Google Sign-In Trigger
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 52.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            IndustrialColors.CopperHighlightCap,
                                            IndustrialColors.CopperFront,
                                            IndustrialColors.CopperSideBevel
                                        )
                                    )
                                )
                                .border(1.dp, IndustrialColors.CopperHighlightCap, RoundedCornerShape(8.dp))
                                .clickable(enabled = !isLoading) {
                                    isLoading = true
                                    errorMessage = null
                                    onGoogleSignInClicked(
                                        context = context,
                                        credentialManager = credentialManager,
                                        onAuthSuccess = {
                                            isLoading = false
                                            onAuthSuccess()
                                        },
                                        onAuthError = { err ->
                                            isLoading = false
                                            errorMessage = err
                                        },
                                        scope = scope,
                                        onAuthCancelled = {
                                            isLoading = false
                                            errorMessage = strings.authCancelledMsg
                                        }
                                    )
                                }
                                .testTag("google_sign_in_button")
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = IndustrialColors.DeepRecess,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = strings.authSigningInLabel,
                                    color = IndustrialColors.DeepRecess,
                                    fontSize = 12.sp,
                                    fontFamily = activeFont,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                            } else {
                                Text(
                                    text = strings.authSignInGoogleBtn,
                                    color = IndustrialColors.DeepRecess,
                                    fontSize = 13.sp,
                                    fontFamily = InterFontFamily,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                IndustrialFooter(
                    language = language,
                    onToggleLang = {
                        language = if (language == AppLanguage.EN) AppLanguage.MM else AppLanguage.EN
                    }
                )
            }
        }
    }
}

@Composable
private fun AuthFeatureRow(
    icon: ImageVector,
    tint: Color,
    text: String,
    fontFamily: androidx.compose.ui.text.font.FontFamily
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(IndustrialColors.DeepRecess)
            .border(1.dp, IndustrialColors.MachinedBorder.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = text,
            color = IndustrialColors.TextPrimary,
            fontSize = 11.sp,
            fontFamily = fontFamily
        )
    }
}
