package com.example.model

enum class TunnelState {
    STOPPED,
    STARTING,
    RUNNING,
    HEALING,
    STOPPING,
    ERROR
}

enum class AppLanguage(val code: String, val label: String) {
    EN("en", "ENG"),
    MM("mm", "မြန်မာ")
}

enum class TargetPlatform(
    val id: String,
    val labelEn: String,
    val labelMm: String,
    val cdnHint: String
) {
    GENERAL("general", "General Web", "သာမာန် သုံးစွဲရန်", "Cloudflare / Google Anycast"),
    PUBG("pubg", "PUBG Mobile", "PUBG Mobile ဂိမ်း", "SEA Singapore Game Relay"),
    MLBB("mlbb", "Mobile Legends", "Mobile Legends (MLBB)", "Moonton SG Low-Jitter"),
    HOK("hok", "Honor of Kings", "Honor of Kings (HOK)", "Tencent SEA Edge"),
    FACEBOOK("facebook", "Facebook & Meta", "Facebook / Messenger", "Meta Global Edge Cache"),
    TELEGRAM("telegram", "Telegram", "Telegram Messenger", "Telegram DC4 / DC5 Cluster"),
    YOUTUBE("youtube", "4K Stream", "YouTube / 4K Stream", "High-Bandwidth CDN Route"),
    TIKTOK("tiktok", "TikTok", "TikTok Video", "ByteDance SEA Edge")
}

data class Telemetry(
    val latencyMs: Long = -1L,
    val rxBytes: Long = 0L,
    val txBytes: Long = 0L,
    val downloadKbps: Float = 0f,
    val uploadKbps: Float = 0f,
    val lossPercent: Double = 0.0,
    val sessionSeconds: Long = 0L
)

data class VpnNode(
    val id: String,
    val name: String,
    val protocol: String,
    val address: String,
    val port: Int,
    val rawLink: String,
    val security: String = "tls",
    val network: String = "tcp",
    val sni: String = "",
    val region: String = "Global",
    val flag: String = "🌐",
    var latencyMs: Long = -1L,
    var isHealthy: Boolean = true,
    var score: Double = 0.0,
    var failureCount: Int = 0
)

data class VpnSettings(
    val dnsProviderName: String = "Cloudflare DoH",
    val dnsIp: String = "1.1.1.1",
    val routingMode: String = "Bypass Myanmar LAN & Direct",
    val mtu: Int = 1280,
    val ipv6LeakProtection: Boolean = true,
    val autoReconnectSelfHeal: Boolean = true
)

data class AiRoutingAdvice(
    val summary: String,
    val recommendedProtocol: String,
    val recommendedDns: String,
    val recommendedMtu: Int,
    val routingTip: String,
    val targetNodeId: String? = null,
    val confidence: Int = 95
)

data class NetworkDiagSnapshot(
    val networkType: String = "Unknown",
    val interfaceName: String = "None",
    val activeDns: String = "1.1.1.1",
    val libXrayBundled: Boolean = false,
    val xrayVersion: String = "Not bundled",
    val mtu: Int = 1280,
    val ipv6Guard: Boolean = true
)

sealed interface AiAdvisorState {
    data object Idle : AiAdvisorState
    data object Loading : AiAdvisorState
    data class Success(val advice: AiRoutingAdvice) : AiAdvisorState
    data class Error(val message: String) : AiAdvisorState
}

data class AiDecisionCompat(
    val action: String,
    val reason: String = ""
)
