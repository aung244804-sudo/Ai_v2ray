package com.example.telemetry

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

enum class AiLogLevel {
    INFO,
    AI,
    SUCCESS,
    WARN,
    ERROR
}

data class AiLogEntry(
    val id: Long,
    val timestamp: String,
    val tag: String,
    val message: String,
    val level: AiLogLevel
)

/**
 * Thread-safe real-time terminal log bus capturing actual work from
 * Gemini AI Leader, Rule-Based Nano Orchestrator, Ping Prober, and Xray TUN engine.
 */
object LiveLogBus {
    private const val MAX_LOGS = 150
    private val seq = AtomicLong(0L)
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    private val _logs = MutableStateFlow<List<AiLogEntry>>(emptyList())
    val logs: StateFlow<List<AiLogEntry>> = _logs.asStateFlow()

    fun log(tag: String, message: String, level: AiLogLevel = AiLogLevel.INFO) {
        val ts = synchronized(timeFormat) { timeFormat.format(Date()) }
        val entry = AiLogEntry(
            id = seq.incrementAndGet(),
            timestamp = ts,
            tag = tag,
            message = message,
            level = level
        )
        _logs.update { current ->
            val updated = current + entry
            if (updated.size > MAX_LOGS) updated.takeLast(MAX_LOGS) else updated
        }
    }

    fun clear() {
        _logs.value = emptyList()
        log("TERMINAL", "Log buffer cleared. Listening to AI & Xray engines…", AiLogLevel.INFO)
    }
}
