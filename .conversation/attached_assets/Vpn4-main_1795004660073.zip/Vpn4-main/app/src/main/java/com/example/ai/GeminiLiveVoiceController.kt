package com.example.ai

import android.util.Log
import com.example.model.AppLanguage
import com.example.telemetry.AiLogLevel
import com.example.telemetry.LiveLogBus
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.AudioTranscriptionConfig
import com.google.firebase.ai.type.FunctionDeclaration
import com.google.firebase.ai.type.FunctionResponsePart
import com.google.firebase.ai.type.LiveSession
import com.google.firebase.ai.type.PublicPreviewAPI
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.SpeechConfig
import com.google.firebase.ai.type.Tool
import com.google.firebase.ai.type.Voice
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.liveAudioConversationConfig
import com.google.firebase.ai.type.liveGenerationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonPrimitive

private const val TAG = "GeminiLiveVoice"
private const val LIVE_MODEL_NAME = "gemini-3.8-live"

enum class VoiceSessionStatus {
    IDLE,
    CONNECTING,
    ACTIVE,
    ERROR
}

data class VoiceConsoleState(
    val status: VoiceSessionStatus = VoiceSessionStatus.IDLE,
    val userTranscript: String = "",
    val aiTranscript: String = "",
    val lastToolAction: String = "",
    val errorMessage: String? = null
)

interface LiveVoiceToolBridge {
    fun autoPickBestNode(): String
    fun applyDnsAndMtu(dnsIp: String, mtu: Int): String
    fun switchLanguage(languageCode: String): String
}

@OptIn(PublicPreviewAPI::class)
class GeminiLiveVoiceController {

    private val _state = MutableStateFlow(VoiceConsoleState())
    val state: StateFlow<VoiceConsoleState> = _state.asStateFlow()

    private var activeSession: LiveSession? = null
    private var audioJob: Job? = null
    private val userTranscriptBuffer = StringBuilder()
    private val aiTranscriptBuffer = StringBuilder()

    private val liveModel by lazy {
        Firebase.ai.liveModel(
            modelName = LIVE_MODEL_NAME,
            generationConfig = liveGenerationConfig {
                responseModality = ResponseModality.AUDIO
                speechConfig = SpeechConfig(voice = Voice("FENRIR"))
                inputAudioTranscription = AudioTranscriptionConfig()
                outputAudioTranscription = AudioTranscriptionConfig()
            },
            tools = listOf(
                Tool.functionDeclarations(
                    listOf(
                        FunctionDeclaration(
                            name = "auto_pick_best_node",
                            description = "Selects the fastest healthy V2Ray node from the imported pool.",
                            parameters = emptyMap()
                        ),
                        FunctionDeclaration(
                            name = "apply_dns_mtu_tuning",
                            description = "Updates the V2Ray tunnel DNS IP and MTU size.",
                            parameters = mapOf(
                                "dns_ip" to Schema.string("DNS IP such as 1.1.1.1, 8.8.8.8, or 94.140.14.14"),
                                "mtu" to Schema.integer("MTU integer between 1200 and 1500")
                            )
                        ),
                        FunctionDeclaration(
                            name = "switch_language",
                            description = "Switches the app UI language between English ('en') and Burmese ('mm').",
                            parameters = mapOf(
                                "language" to Schema.enumeration(listOf("en", "mm"), "Language code")
                            )
                        )
                    )
                )
            ),
            systemInstruction = content {
                text(
                    """
                    You are the AI V2Ray Client Live Voice Co-Pilot (AI Leader).
                    Assist the operator with V2Ray/Xray routing, latency optimization, DNS/MTU tuning, and troubleshooting.
                    Respond concisely and naturally in whichever language the user uses (Burmese/Myanmar or English).
                    Use your tool functions whenever the user asks to pick the best server, tune DNS/MTU, or switch language.
                    """.trimIndent()
                )
            }
        )
    }

    fun startSession(
        scope: CoroutineScope,
        language: AppLanguage,
        toolBridge: LiveVoiceToolBridge,
        onSessionSaved: (userText: String, aiText: String) -> Unit
    ) {
        val currentStatus = _state.value.status
        if (currentStatus == VoiceSessionStatus.CONNECTING || currentStatus == VoiceSessionStatus.ACTIVE) {
            return
        }

        userTranscriptBuffer.clear()
        aiTranscriptBuffer.clear()
        _state.value = VoiceConsoleState(status = VoiceSessionStatus.CONNECTING)
        LiveLogBus.log("GEMINI-LIVE", "Opening $LIVE_MODEL_NAME audio websocket…", AiLogLevel.AI)

        audioJob = scope.launch(Dispatchers.IO) {
            try {
                val session = liveModel.connect()
                activeSession = session
                _state.update {
                    it.copy(
                        status = VoiceSessionStatus.ACTIVE,
                        errorMessage = null
                    )
                }
                LiveLogBus.log(
                    "GEMINI-LIVE",
                    "Live voice stream ONLINE (${if (language == AppLanguage.MM) "MM/EN" else "EN/MM"})",
                    AiLogLevel.SUCCESS
                )

                val conversationConfig = liveAudioConversationConfig {
                    enableInterruptions = true
                    transcriptHandler = { input, output ->
                        val userChunk = input?.text?.trim().orEmpty()
                        val aiChunk = output?.text?.trim().orEmpty()
                        if (userChunk.isNotBlank()) {
                            appendTranscriptChunk(userTranscriptBuffer, userChunk)
                            _state.update {
                                it.copy(userTranscript = userTranscriptBuffer.toString().takeLast(280))
                            }
                        }
                        if (aiChunk.isNotBlank()) {
                            appendTranscriptChunk(aiTranscriptBuffer, aiChunk)
                            _state.update {
                                it.copy(aiTranscript = aiTranscriptBuffer.toString().takeLast(280))
                            }
                        }
                    }
                    functionCallHandler = { call ->
                        val outcome = when (call.name) {
                            "auto_pick_best_node" -> toolBridge.autoPickBestNode()
                            "apply_dns_mtu_tuning" -> {
                                val dns = call.args["dns_ip"]?.jsonPrimitive?.content ?: "1.1.1.1"
                                val mtu = call.args["mtu"]?.jsonPrimitive?.intOrNull ?: 1280
                                toolBridge.applyDnsAndMtu(dns, mtu)
                            }
                            "switch_language" -> {
                                val lang = call.args["language"]?.jsonPrimitive?.content ?: "en"
                                toolBridge.switchLanguage(lang)
                            }
                            else -> "Unknown tool ${call.name}"
                        }
                        LiveLogBus.log("LIVE-TOOL", "${call.name} -> $outcome", AiLogLevel.SUCCESS)
                        _state.update { it.copy(lastToolAction = outcome) }
                        FunctionResponsePart(
                            name = call.name,
                            response = JsonObject(
                                mapOf(
                                    "status" to JsonPrimitive("ok"),
                                    "result" to JsonPrimitive(outcome)
                                )
                            ),
                            id = call.id
                        )
                    }
                    goAwayHandler = { goAway ->
                        LiveLogBus.log(
                            "GEMINI-LIVE",
                            "Session rotation notice (${goAway.timeLeft})",
                            AiLogLevel.WARN
                        )
                    }
                }

                session.startAudioConversation(conversationConfig)
            } catch (e: CancellationException) {
                throw e
            } catch (e: SecurityException) {
                Log.e(TAG, "Microphone permission missing for Live Voice", e)
                LiveLogBus.log("GEMINI-LIVE", "Microphone permission denied", AiLogLevel.ERROR)
                _state.update {
                    it.copy(
                        status = VoiceSessionStatus.ERROR,
                        errorMessage = "Microphone permission required for Live Voice."
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Gemini Live Voice session failed", e)
                LiveLogBus.log("GEMINI-LIVE", "Voice stream fault: ${e.message}", AiLogLevel.ERROR)
                _state.update {
                    it.copy(
                        status = VoiceSessionStatus.ERROR,
                        errorMessage = e.localizedMessage ?: "Failed to connect Gemini 3.8 Live voice."
                    )
                }
            } finally {
                val uText = userTranscriptBuffer.toString().trim()
                val aText = aiTranscriptBuffer.toString().trim()
                if (uText.isNotBlank() || aText.isNotBlank()) {
                    onSessionSaved(uText, aText)
                }
            }
        }
    }

    fun stopSession(scope: CoroutineScope) {
        scope.launch {
            withContext(Dispatchers.IO) {
                runCatching { activeSession?.stopAudioConversation() }
                runCatching { activeSession?.close() }
                activeSession = null
            }
            audioJob?.cancel()
            audioJob = null
            _state.update { it.copy(status = VoiceSessionStatus.IDLE) }
            LiveLogBus.log("GEMINI-LIVE", "Voice conversation ended", AiLogLevel.INFO)
        }
    }

    fun clearError() {
        _state.update { it.copy(errorMessage = null, status = VoiceSessionStatus.IDLE) }
    }

    private fun appendTranscriptChunk(buffer: StringBuilder, chunk: String) {
        if (buffer.isNotEmpty() && !buffer.endsWith(" ")) {
            buffer.append(' ')
        }
        buffer.append(chunk)
        if (buffer.length > 2000) {
            buffer.delete(0, buffer.length - 2000)
        }
    }
}
