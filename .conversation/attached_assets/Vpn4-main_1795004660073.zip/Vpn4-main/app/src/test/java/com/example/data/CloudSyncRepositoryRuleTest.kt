package com.example.data

import com.example.base.FirestoreEmulatorTestBase
import com.example.model.AppLanguage
import com.example.model.VpnNode
import com.example.model.VpnSettings
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class CloudSyncRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun upsertUserProfileAndNode_authenticatedOwner_succeedsAndEmitsViaSnapshots() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repo = CloudSyncRepository(firestore, auth)

        val profileRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.upsertUserProfile("Alice Operator", ALICE_EMAIL, null)
        }
        assertTrue("Profile upsert should succeed: ${profileRes.exceptionOrNull()}", profileRes.isSuccess)

        val nodeKey = "node_${UUID.randomUUID().toString().take(8)}"
        val node = VpnNode(
            id = nodeKey,
            name = "SG-Reality-Test",
            protocol = "vless",
            address = "104.18.2.1",
            port = 443,
            rawLink = "vless://11111111-1111-1111-1111-111111111111@104.18.2.1:443?security=reality#SG-Reality-Test",
            security = "reality",
            network = "tcp",
            sni = "sg.example.com",
            region = "Singapore",
            flag = "🇸🇬",
            latencyMs = 42L,
            isHealthy = true,
            score = 95.0,
            failureCount = 0
        )

        val upsertRes = withTimeout(DEFAULT_TIMEOUT_MS) { repo.upsertNode(node) }
        assertTrue("Node upsert should succeed: ${upsertRes.exceptionOrNull()}", upsertRes.isSuccess)

        val observed = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeNodes(uid).first { list -> list.any { it.id == nodeKey } }
        }
        assertTrue(observed.any { it.id == nodeKey && it.protocol == "vless" })
    }

    @Test
    fun saveSettingsAndRecordAiSession_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repo = CloudSyncRepository(firestore, auth)

        val settingsRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.saveSettings(
                settings = VpnSettings(dnsIp = "1.1.1.1", mtu = 1400),
                language = AppLanguage.MM,
                activeNodeId = "sg_1"
            )
        }
        assertTrue("Settings save failed: ${settingsRes.exceptionOrNull()}", settingsRes.isSuccess)

        val settingsSnap = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeSettings(uid).first { it != null }
        }
        assertNotNull(settingsSnap)
        assertEquals("mm", settingsSnap?.preferredLanguage)

        val sessionRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.recordAiSession(
                mode = "voice",
                query = "Low ping PUBG",
                summary = "Switched to SG-Reality-Test",
                recommendedProtocol = "VLESS Reality",
                recommendedDns = "1.1.1.1",
                recommendedMtu = 1400
            )
        }
        assertTrue("AI session record failed: ${sessionRes.exceptionOrNull()}", sessionRes.isSuccess)
    }

    @Test
    fun observeNodes_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = CloudSyncRepository(firestore, auth)
        val nodeKey = "alice_node_${UUID.randomUUID().toString().take(8)}"
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.upsertNode(
                VpnNode(
                    id = nodeKey,
                    name = "Alice Private Node",
                    protocol = "trojan",
                    address = "de.example.com",
                    port = 443,
                    rawLink = "trojan://secret@de.example.com:443#Alice"
                )
            ).getOrThrow()
        }

        // Sign in as Bob and attempt to read Alice's subcollection
        signInTestUser(BOB_EMAIL)
        val bobRepo = CloudSyncRepository(firestore, auth)
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                bobRepo.observeNodes(aliceUid).first()
            }
            fail("Expected cross-user read to fail with PERMISSION_DENIED")
        } catch (e: Exception) {
            val fsError = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", fsError)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsError?.code)
        }
    }

    @Test
    fun observeNodes_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        auth.signOut()
        val repo = CloudSyncRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeNodes(aliceUid).first()
            }
            fail("Expected unauthenticated observeNodes to fail with PERMISSION_DENIED")
        } catch (e: Exception) {
            val fsError = e.unwrapFirestoreException()
            assertNotNull("Expected nested FirebaseFirestoreException, got $e", fsError)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsError?.code)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice_v2ray@test.com"
        const val BOB_EMAIL = "bob_v2ray@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
