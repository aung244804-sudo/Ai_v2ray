package com.example

import com.example.model.TargetPlatform
import com.example.model.Telemetry
import com.example.model.VpnNode
import com.example.vpn.AiTunnelOrchestrator
import com.example.vpn.NodeParser
import com.example.vpn.XrayConfigFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AiTunnelOrchestratorTest {

    private val orchestrator = AiTunnelOrchestrator()

    @Test
    fun autoSelectBestNode_selectsLowestLatencyAndPriorityProtocol() {
        val node1 = VpnNode(
            id = "node-1",
            name = "JP-Tokyo-VMess",
            protocol = "vmess",
            address = "jp.v2ray.example",
            port = 443,
            rawLink = "vmess://dummy",
            region = "Japan",
            latencyMs = 120L,
            isHealthy = true
        )
        val node2 = VpnNode(
            id = "node-2",
            name = "SG-Singapore-Reality",
            protocol = "vless",
            address = "sg.v2ray.example",
            port = 443,
            rawLink = "vless://dummy",
            region = "Singapore",
            latencyMs = 38L,
            isHealthy = true
        )
        val node3 = VpnNode(
            id = "node-3",
            name = "US-Trojan-West",
            protocol = "trojan",
            address = "us.v2ray.example",
            port = 443,
            rawLink = "trojan://dummy",
            region = "United States",
            latencyMs = 210L,
            isHealthy = true
        )

        val selected = orchestrator.autoSelectBestNode(
            listOf(node1, node2, node3),
            TargetPlatform.PUBG
        )
        assertNotNull(selected)
        assertEquals("node-2", selected?.id)
    }

    @Test
    fun selfHealing_triggersOnConsecutiveFailures() {
        val activeNode = VpnNode(
            id = "active-node",
            name = "SG-Node-Primary",
            protocol = "vless",
            address = "sg.primary.example",
            port = 443,
            rawLink = "vless://dummy1",
            region = "Singapore",
            latencyMs = 38L,
            isHealthy = true
        )
        val backupNode = VpnNode(
            id = "backup-node",
            name = "JP-Node-Backup",
            protocol = "vless",
            address = "jp.backup.example",
            port = 443,
            rawLink = "vless://dummy2",
            region = "Japan",
            latencyMs = 65L,
            isHealthy = true
        )
        val pool = listOf(activeNode, backupNode)

        val noHeal = orchestrator.checkAndSelfHeal(
            activeNode = activeNode,
            currentTelemetry = Telemetry(latencyMs = 38L, lossPercent = 0.0),
            consecutiveFailures = 0,
            nodePool = pool
        )
        assertNull(noHeal)

        val healed = orchestrator.checkAndSelfHeal(
            activeNode = activeNode,
            currentTelemetry = Telemetry(latencyMs = -1L, lossPercent = 50.0),
            consecutiveFailures = 2,
            nodePool = pool
        )
        assertNotNull(healed)
        assertEquals("backup-node", healed?.id)
        assertFalse(activeNode.isHealthy)
    }

    @Test
    fun nodeParser_parsesVlessAndTrojanLinks() {
        val vless = "vless://b831381d-6324-4d53-ad4f-8cda48b30811@104.18.2.1:443?security=reality&sni=sg.example.com#SG-Cloudflare-Reality-01"
        val parsed = NodeParser.parseSingleLink(vless)
        assertNotNull(parsed)
        assertEquals("SG-Cloudflare-Reality-01", parsed?.name)
        assertEquals("vless", parsed?.protocol)
        assertEquals("104.18.2.1", parsed?.address)
        assertEquals(443, parsed?.port)
        assertEquals("reality", parsed?.security)
        assertEquals("Singapore", parsed?.region)

        val trojan = "trojan://pass123@de.example.com:443?security=tls&sni=de.example.com#DE-Frankfurt"
        val parsedTrojan = NodeParser.parseSingleLink(trojan)
        assertNotNull(parsedTrojan)
        assertEquals("trojan", parsedTrojan?.protocol)
        assertEquals("Germany", parsedTrojan?.region)
    }

    @Test
    fun xrayConfigFactory_embedsTunFdAndPhysicalInterface() {
        val outbound = """[{"tag":"proxy","protocol":"vless"}]"""
        val json = XrayConfigFactory.build(
            outboundJson = outbound,
            tunFd = 42,
            physicalInterfaceName = "wlan0",
            dnsServer = "1.1.1.1",
            mtu = 1420
        )
        assertTrue(json.contains("\"xray.tun.fd\":\"42\""))
        assertTrue(json.contains("\"interface\":\"wlan0\""))
        assertTrue(json.contains("\"mtu\":1420"))
    }

    @Test
    fun nodeParser_parsesLegacyAndSip002ShadowsocksAndVmess() {
        val legacyRaw = "aes-256-gcm:secretpass@sg.ss.example:8443"
        val legacyB64 = java.util.Base64.getEncoder().encodeToString(legacyRaw.toByteArray())
        val legacyLink = "ss://$legacyB64#🇸🇬 SG Legacy Node [VIP]"
        val legacyParsed = NodeParser.parseSingleLink(legacyLink)
        assertNotNull(legacyParsed)
        assertEquals("shadowsocks", legacyParsed?.protocol)
        assertEquals("sg.ss.example", legacyParsed?.address)
        assertEquals(8443, legacyParsed?.port)
        assertEquals("Singapore", legacyParsed?.region)

        val userInfoB64 = java.util.Base64.getEncoder().encodeToString("chacha20-ietf-poly1305:pw".toByteArray())
        val sip002Link = "ss://$userInfoB64@jp.ss.example:8388?plugin=obfs-local#JP Tokyo"
        val sip002Parsed = NodeParser.parseSingleLink(sip002Link)
        assertNotNull(sip002Parsed)
        assertEquals("jp.ss.example", sip002Parsed?.address)
        assertEquals(8388, sip002Parsed?.port)
        assertEquals("Japan", sip002Parsed?.region)

        val vmessJson = """{"v":"2","ps":"HK Gaming [Low Ping]","add":"hk.vmess.example","port":443,"id":"11111111-1111-1111-1111-111111111111","net":"ws","tls":"tls"}"""
        val vmessLink = "vmess://${java.util.Base64.getEncoder().encodeToString(vmessJson.toByteArray())}"
        val vmessParsed = NodeParser.parseSingleLink(vmessLink)
        assertNotNull(vmessParsed)
        assertEquals("vmess", vmessParsed?.protocol)
        assertEquals("hk.vmess.example", vmessParsed?.address)
        assertEquals("Hong Kong", vmessParsed?.region)

        val vlessWithSpaces = "vless://b831381d-6324-4d53-ad4f-8cda48b30811@104.18.2.9:443?security=tls&type=ws#TH Bangkok [VIP Server]"
        val vlessParsed = NodeParser.parseSingleLink(vlessWithSpaces)
        assertNotNull(vlessParsed)
        assertEquals("Thailand", vlessParsed?.region)
    }

    @Test
    fun stringsCatalog_providesBilingualStrings() {
        val en = com.example.ui.StringsCatalog.get(com.example.model.AppLanguage.EN)
        val mm = com.example.ui.StringsCatalog.get(com.example.model.AppLanguage.MM)
        assertTrue(en.connectBtn.isNotBlank())
        assertTrue(mm.connectBtn.isNotBlank())
        assertTrue(en.connectBtn != mm.connectBtn)
    }

    @Test
    fun liveLogBus_recordsAndClearsEvents() {
        com.example.telemetry.LiveLogBus.clear()
        com.example.telemetry.LiveLogBus.log(
            "AI-LEADER",
            "Testing neural routing",
            com.example.telemetry.AiLogLevel.AI
        )
        val logs = com.example.telemetry.LiveLogBus.logs.value
        assertTrue(logs.any { it.tag == "AI-LEADER" && it.message.contains("neural routing") })
    }
}
