const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DATABASE_ID = "ai-studio-android-aiv2ray-7bc8e5d0-850c-409f-b753-15b3576689c0";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function getDb(context) {
  return context.firestore({ databaseId: DATABASE_ID });
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write any user profile, nodes, settings, or ai_sessions", async () => {
  const unauth = getDb(testEnv.unauthenticatedContext());
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).collection("nodes").get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).collection("settings").get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).collection("ai_sessions").get());
});

function nowTs() {
  return new Date(Date.now() - 1000);
}

test("Authenticated user: owner can create and update valid profile; cannot list all users or inject ghost fields", async () => {
  const aliceDb = getDb(testEnv.authenticatedContext(ALICE_UID));
  const bobDb = getDb(testEnv.authenticatedContext(BOB_UID));

  const validProfile = {
    userId: ALICE_UID,
    displayName: "Victor Operator",
    email: "victor@example.com",
    createdAt: nowTs(),
    updatedAt: nowTs(),
  };

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).set(validProfile));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());

  // Listing /users must fail (prevent PII enumeration)
  await assertFails(aliceDb.collection("users").get());

  // Cross-user read & write must fail
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).update({ displayName: "Hacked" }));

  // Ghost field shadow update must fail
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      displayName: "Victor Pro",
      isAdmin: true,
      updatedAt: nowTs(),
    })
  );

  // Valid update succeeds
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      displayName: "Victor Pro",
      updatedAt: nowTs(),
    })
  );
});

test("User nodes: owner CRUD succeeds; cross-user and invalid port rejected", async () => {
  const aliceDb = getDb(testEnv.authenticatedContext(ALICE_UID));
  const bobDb = getDb(testEnv.authenticatedContext(BOB_UID));

  const validNode = {
    userId: ALICE_UID,
    nodeKey: "sg_reality_01",
    name: "SG-Cloudflare-Reality-01",
    protocol: "vless",
    address: "104.18.2.1",
    port: 443,
    rawLink: "vless://uuid@104.18.2.1:443?security=reality#SG-01",
    security: "reality",
    network: "tcp",
    sni: "sg.example.com",
    region: "Singapore",
    flag: "🇸🇬",
    latencyMs: 38,
    isHealthy: true,
    score: 96.5,
    failureCount: 0,
    createdAt: nowTs(),
    updatedAt: nowTs(),
  };

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("nodes").doc("sg_reality_01").set(validNode)
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("nodes").get()
  );

  // Invalid port (>65535) must fail
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("nodes").doc("bad_node").set({
      ...validNode,
      nodeKey: "bad_node",
      port: 70000,
    })
  );

  // Cross-user access fails
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("nodes").get()
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("nodes").doc("sg_reality_01").delete()
  );
});

test("User settings & append-only AI sessions enforce ownership, schema, and immutability", async () => {
  const aliceDb = getDb(testEnv.authenticatedContext(ALICE_UID));
  const bobDb = getDb(testEnv.authenticatedContext(BOB_UID));

  const validSettings = {
    userId: ALICE_UID,
    dnsProviderName: "Cloudflare DoH",
    dnsIp: "1.1.1.1",
    routingMode: "Bypass Myanmar LAN & Direct",
    mtu: 1280,
    ipv6LeakProtection: true,
    autoReconnectSelfHeal: true,
    preferredLanguage: "mm",
    activeNodeId: "sg_reality_01",
    createdAt: nowTs(),
    updatedAt: nowTs(),
  };

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("settings").doc("tunnel").set(validSettings)
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("settings").doc("tunnel").update({
      mtu: 9999,
      updatedAt: nowTs(),
    })
  );

  const validSession = {
    userId: ALICE_UID,
    mode: "voice",
    query: "Optimize PUBG ping",
    summary: "Recommended SG VLESS Reality node with 1.1.1.1 DNS.",
    recommendedProtocol: "VLESS Reality",
    recommendedDns: "1.1.1.1",
    recommendedMtu: 1280,
    createdAt: nowTs(),
  };

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("ai_sessions").doc("sess_1").set(validSession)
  );
  // Update on append-only ai_sessions must fail
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("ai_sessions").doc("sess_1").update({
      summary: "Tampered",
    })
  );
  // Cross-user read fails
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("ai_sessions").get()
  );
});
